// Copies the shared crypto/protocol modules into both apps (single source of truth: /shared).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
for (const app of ['parent-app', 'child-app']) {
  const dst = path.join(root, app, 'www', 'js', 'common');
  fs.mkdirSync(dst, { recursive: true });
  for (const f of ['sp-crypto.js', 'sp-protocol.js']) fs.copyFileSync(path.join(root, 'shared', f), path.join(dst, f));
  const css = path.join(root, app, 'www', 'css');
  fs.mkdirSync(css, { recursive: true });
  fs.copyFileSync(path.join(root, 'shared', 'ui', 'sp-theme.css'), path.join(css, 'sp-theme.css'));
  fs.copyFileSync(path.join(root, 'shared', 'ui', 'sp-ui.js'), path.join(dst, 'sp-ui.js'));
}
console.log('shared modules synced');
