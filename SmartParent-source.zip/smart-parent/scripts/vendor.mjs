// Copies third-party browser libraries from node_modules into www/vendor so the apps
// work fully offline (no CDN requests from the WebView).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const which = process.argv[2];
const app = path.join(root, which === 'child' ? 'child-app' : 'parent-app');
const nm = path.join(app, 'node_modules');
const out = path.join(app, 'www', 'vendor');

const common = [
  ['bootstrap/dist/css/bootstrap.min.css', 'bootstrap/bootstrap.min.css'],
  ['bootstrap/dist/js/bootstrap.bundle.min.js', 'bootstrap/bootstrap.bundle.min.js'],
  ['bootstrap-icons/font/bootstrap-icons.min.css', 'bootstrap-icons/bootstrap-icons.min.css'],
  ['bootstrap-icons/font/fonts', 'bootstrap-icons/fonts'],
  ['chart.js/dist/chart.umd.js', 'chart.js/chart.umd.js'],
];
const extra = which === 'child'
  ? [['qrcode-generator/dist/qrcode.js', 'qrcode/qrcode.js']]
  : [['leaflet/dist/leaflet.js', 'leaflet/leaflet.js'], ['leaflet/dist/leaflet.css', 'leaflet/leaflet.css'], ['leaflet/dist/images', 'leaflet/images']];

for (const [from, to] of [...common, ...extra]) {
  const src = path.join(nm, from);
  const dst = path.join(out, to);
  if (!fs.existsSync(src)) {
    // qrcode-generator moved its file between majors; fall back to package root
    const alt = path.join(nm, from.replace('/dist/', '/'));
    if (fs.existsSync(alt)) { fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.cpSync(alt, dst, { recursive: true }); continue; }
    console.error('missing', from); process.exitCode = 1; continue;
  }
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.cpSync(src, dst, { recursive: true });
}
console.log(`vendored libraries into ${path.relative(root, out)}`);
