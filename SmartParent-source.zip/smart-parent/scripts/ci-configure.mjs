// Build-time configuration used by CI (and usable locally):
//   SIGNAL_URL=wss://relay.example.com   default relay shown on the child phone's Connection screen
//   ALLOW_CLEARTEXT=true                 allow ws:// / http:// relays (LAN testing only – never for real use)
// Usage: node scripts/ci-configure.mjs <parent-app|child-app>
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const app = process.argv[2];
if (!['parent-app', 'child-app'].includes(app)) { console.error('usage: ci-configure.mjs <parent-app|child-app>'); process.exit(2); }
const dir = path.join(root, app);
const signal = (process.env.SIGNAL_URL || '').trim();
const cleartext = /^(1|true|yes)$/i.test(process.env.ALLOW_CLEARTEXT || '');

if (signal) {
  if (!/^wss?:\/\/[A-Za-z0-9.-]+(:\d+)?(\/.*)?$/.test(signal)) { console.error(`SIGNAL_URL is not a ws:// or wss:// address: ${signal}`); process.exit(1); }
  if (signal.startsWith('ws://') && !cleartext) console.warn('::warning::SIGNAL_URL uses ws:// but ALLOW_CLEARTEXT is off – Android will block it. Use wss:// or enable allow_cleartext.');
  if (app === 'child-app') {
    const f = path.join(dir, 'www/js/config.js');
    const s = fs.readFileSync(f, 'utf8').replace(/export const DEFAULT_SIGNAL_URL = '[^']*';/, `export const DEFAULT_SIGNAL_URL = '${signal}';`);
    fs.writeFileSync(f, s);
    console.log(`child default relay -> ${signal}`);
  }
}

if (cleartext) {
  const mf = path.join(dir, 'android/app/src/main/AndroidManifest.xml');
  let m = fs.readFileSync(mf, 'utf8');
  if (!m.includes('usesCleartextTraffic')) m = m.replace('<application', '<application\n        android:usesCleartextTraffic="true"');
  fs.writeFileSync(mf, m);
  if (app === 'parent-app') {
    // The parent UI is served from https://localhost; ws:// from there is "mixed content".
    const cf = path.join(dir, 'capacitor.config.json');
    const c = JSON.parse(fs.readFileSync(cf, 'utf8'));
    c.android = { ...(c.android || {}), allowMixedContent: true };
    fs.writeFileSync(cf, JSON.stringify(c, null, 2) + '\n');
  }
  console.log(`${app}: cleartext ws:// allowed (testing build)`);
}
