# Installation

## Prerequisites
- Node.js 20+ and npm
- Android Studio (Ladybug or newer) with Android SDK 36, JDK 21
- Two Android phones, Android 8.0+ (API 26). Child phone needs Google Play services for location.
- A small server for the relay (any VPS / Azure B1s) – or your PC on the same Wi-Fi for a first test

## 1. Relay (signaling) + TURN

### Local test (same Wi-Fi)
```bash
cd signaling-server
npm install
npm start                 # listens on :8080
```
Android blocks cleartext (`ws://`, `http://`) by default. For a quick test either:
- run `cloudflared tunnel --url http://localhost:8080` and use the printed `https://…` host as `wss://…`, or
- temporarily add `android:usesCleartextTraffic="true"` to the `<application>` tag of both manifests and use `ws://<PC-LAN-IP>:8080`. Remove it before real use.

**Always use `wss://` in real use.**

### Production
1. Point DNS `signal.your-domain.com` and `turn.your-domain.com` at the VM.
2. `cp .env.example deploy/.env` and set a long random `TURN_SECRET` (same value as `static-auth-secret` in `deploy/turnserver.conf`). Set `external-ip`.
3. Open ports: 80/443 TCP (Caddy), 3478 TCP+UDP, 5349 TCP, 49160–49200 UDP.
4. `cd deploy && docker compose --env-file .env up -d`
5. Check: `https://signal.your-domain.com/health` → `{"ok":true,…}` and `/ice?room=AAAAAAAAAAAAAAAAAAAAAA` lists a `turn:` server.

The relay keeps rooms in memory only and never logs message contents. TURN only forwards encrypted WebRTC packets.

## 2. Build and install the apps
```bash
cd parent-app && npm install && npm run sync     # copies shared modules + vendor libs, runs cap sync
cd ../child-app && npm install && npm run sync
```
Optionally set the default relay shown on the child phone in `child-app/www/js/config.js`.

Open each `android/` folder in Android Studio (`npm run open`) and Run, or build APKs (see BUILD_APK.md) and install with `adb install`.

## 3. Pair
On the **child phone**
1. Open *Smart Parent Child* → **Permissions** → turn on **Notifications** and **Usage access**.
2. **Connection** → enter the relay address → **Show pairing code**.

On the **parent phone**
3. Open *Smart Parent* → **Add child** → enter your name and the child's name → **Scan pairing code** (or paste the link copied on the child phone).
4. A 6-digit code appears. Check the child phone shows the same code; tap **Allow** there.

## 4. Optional features on the child phone
- **Limits**: Permissions → *Limits (accessibility service)* → read the disclosure → enable *Smart Parent limits*.
- **Location**: Permissions → *Location* → allow; then *Location while the app is closed* → *Allow all the time*.
- **Run in background**: allow ignoring battery optimisation. On Xiaomi/Oppo/Vivo/Realme/Samsung also enable *Autostart* / set battery to *Unrestricted* for the app (OEM-specific settings – see dontkillmyapp.com).

## 5. Use
Parent: Dashboard, Screen time, Applications (tap a limit button per app), Location, Device information, Parental controls (daily limit, bedtime, study time, location request, alerts, unpair PIN), Reports (CSV export), Settings (children, app lock, theme).

The child sees everything shared under **Privacy** and can pause location sharing there.
