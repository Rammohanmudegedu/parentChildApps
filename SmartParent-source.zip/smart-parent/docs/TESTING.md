# Testing

## Automated (no phone needed)
```bash
cd shared && npm test                       # 10 crypto/protocol tests
cd signaling-server && npm install && npm test   # 4 relay tests
tools/kotlin-interop.sh                     # compiles CryptoBox.kt on the JVM, 15 cross-checks vs JS
pip install playwright && python -m playwright install chromium
python3 tools/e2e/run_e2e.py                # 25 end-to-end checks
```

`run_e2e.py` drives the **real parent app** in headless Chromium against the **real relay**. The child side is `tools/e2e/child-sim.html`, a browser twin of `SyncEngine.kt` that answers with fixed test data (it is a test harness and is not part of either app). It verifies: matching pairing codes, sealed signaling, WebRTC DataChannel, sync, chunked 150 KB app list, every parent screen, settings round-trip with validation, PIN sent only as a hash, live alert push, IndexedDB containing only sealed records, reconnect after reload, dark theme, no JS errors. Screenshots go to `tools/e2e/screenshots/`.

What automation cannot cover: the Kotlin collectors, foreground service, accessibility enforcement and native WebRTC on a real phone. Use the checklist below.

## On-device checklist (child phone)

| # | Step | Expected |
|---|---|---|
| 1 | Install, open, Permissions | Notifications/Usage access show "Turn on"; granting flips to "On" after returning |
| 2 | Pair (INSTALL.md §3) | Same 6-digit code on both phones; "Sharing with <parent>" notification appears after Allow |
| 3 | Use YouTube 5 min, open parent Dashboard | Screen time and top apps reflect it (≤1 min lag) |
| 4 | Parent: Applications › YouTube › Pause | Child gets "Your parent updated your settings"; opening YouTube shows the pause screen (with limits service on) |
| 5 | Set bedtime to start in 2 min | Apps pause at that time; parent receives "Bedtime started"; Phone still opens from the pause screen |
| 6 | Daily limit below today's usage | Non-exempt apps pause; "Daily limit reached" alert arrives once |
| 7 | Turn off the accessibility service | Parent alert "Limits not enforced" within ~1 min; dashboard banner |
| 8 | Revoke Usage access | Parent alert "Usage access turned off" |
| 9 | Location: grant "all the time", open parent Location | Map with fresh fix, accuracy, battery |
| 10 | Child Privacy › Pause location | Parent alert "Location sharing paused"; Location view explains why |
| 11 | Airplane mode on child 10 min, then off | Parent shows "Child offline" + cached data; after reconnect the queued alerts arrive and "reconnected" alert fires |
| 12 | Reboot child phone | Service restarts (notification returns) without opening the app |
| 13 | Child on mobile data, parent on another network | Connects via TURN (Dashboard › Connection shows "· relay") |
| 14 | Parent: Settings › Unpair | Child shows "Smart Parent disconnected", history wiped, notification gone |
| 15 | Set unpair PIN, try child-side unpair with wrong PIN | Refused; correct PIN unpairs |
| 16 | `adb logcat -s SmartParentSync` while using | No message contents, keys or codes are ever logged |

## Compatibility matrix to run
Android 8, 10, 12, 13, 14, 15/16 · at least one Samsung and one Xiaomi/Oppo/Vivo device (aggressive battery management) · Wi-Fi ⇄ Wi-Fi, mobile ⇄ Wi-Fi, mobile ⇄ mobile (TURN).

## Security review checklist
- Tamper one byte of a relayed message (e.g. patch the relay) → receiver drops it silently.
- Replay a captured DataChannel envelope → `REPLAY`.
- Pair with a QR older than 10 min → `PAIR_DENY expired`; reuse a scanned QR → ignored.
- Send an unknown command type → `ERROR UNKNOWN_TYPE`; out-of-range settings → `ERROR SETTINGS_*`.
- `adb backup` / Auto Backup → nothing exported (`allowBackup=false`, extraction rules exclude all).
