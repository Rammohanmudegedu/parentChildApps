# Protocol

Implementations: `shared/sp-crypto.js`, `shared/sp-protocol.js` (both apps' JS) and `child-app/.../core/CryptoBox.kt`, `net/SyncEngine.kt`, `net/ProtocolRules.kt` (child native). `tools/kotlin-interop.sh` proves the two are byte-compatible.

## Primitives
ECDH P-256 (raw 65-byte public keys; secret = 32-byte X), HKDF-SHA256, AES-256-GCM (12-byte IV, 16-byte tag), HMAC-SHA256, PBKDF2-SHA256 (150 000 iterations) for PINs. Binary values are base64url without padding.

## Pairing
1. Child creates a fresh key pair, a random 16-byte **pairing room** and **one-time token** (10 min), and shows
   `smartparent://pair?d=base64url({v:1, s:relayUrl, r:room, k:childPub, t:token, e:expiry, n:deviceName})`.
2. Parent scans, creates its key pair, joins room `r`, sends `{k:"PAIR_REQ", pk, name, mac}` where
   `mac = HMAC(token, "pair-req|r|parentPub|childPub")` – proves it read the QR.
3. Both compute `shared = ECDH(...)` and, with salt `SmartParent/v1|childPub|parentPub`:
   `signalKey = HKDF(...,"signal",32)`, `roomId = HKDF(...,"room",16)`, `code = HKDF(...,"sas",4) mod 10^6`.
4. Both phones display the 6-digit code. A relay that substituted keys would produce different codes.
5. Child user taps **Allow** → `{k:"PAIR_OK", box: seal(signalKey, room, {deviceId, deviceName})}`. The parent accepts only if the box decrypts.

## Session (each connection)
Both join the long-term `roomId` (opaque to the relay). Signaling messages are `SealedChannel(signalKey)` envelopes with labels `sig-p`/`sig-c`:
`HELLO{pn}` → `HELLO_ACK{pn,cn}` → `OFFER{sdp}` → `ANSWER{sdp}` + `ICE{c}`.
Session keys: salt `SmartParent/session|pn|cn` → `p2c`, `c2p` (32 B) and `sessionId` (12 B). Sessions expire after 60 min.

## Envelope
`{"v":1,"s":seq,"ts":epochMs,"iv":"…","c":"…"}` with AAD `SP1|label|context|seq|ts`.
Receiver rejects: wrong version/shape, |now − ts| > 120 s, `seq ≤ last seq`, any GCM failure. Context binds to `sessionId` (or `roomId` for signaling), so messages can't be replayed across sessions or reflected back.
Plaintexts > 48 KiB are split into `{type:"CHUNK",id,i,n,d}` **before** sealing.

## Messages (inside the envelope)
Every request: `{type, requestId (hex), timestamp (ISO-8601), …}`; responses echo `requestId`.

| Parent → child | Body | Child → parent |
|---|---|---|
| `PING` | – | `PONG` |
| `DEVICE_STATUS_REQUEST` | – | `DEVICE_STATUS_RESPONSE{device}` |
| `SCREEN_TIME_REQUEST` | `days` 1–31 | `SCREEN_TIME_RESPONSE{days[], apps[], today[]}` |
| `APP_LIST_REQUEST` | – | `APP_LIST_RESPONSE{apps[]}` (icons as WebP data URIs) |
| `LOCATION_REQUEST` | – | `LOCATION_RESPONSE{sharing, reason?, last, history[], battery}` |
| `SYNC_REQUEST` | `sinceAlertId`, `sinceLocationTs` | `SYNC_RESPONSE{device, alerts[], locations[], days[], settings}` |
| `SETTINGS_GET` | – | `SETTINGS_RESPONSE{settings}` |
| `SETTINGS_UPDATE` | `settings` (validated field-by-field) | `SETTINGS_RESPONSE{settings, applied}` |
| `UNPAIR` | – | `SETTINGS_RESPONSE{unpaired}` then the child wipes keys + history |
| – | – | `ALERT{alert}` (pushed) · `ERROR{code}` |

Unknown types and invalid fields are refused with `ERROR`. Settings sent back to the parent never include the PIN hash.

## Relay
`{t:"join",room,role}`, `{t:"relay",d}` → peer gets `{t:"relay",d}`; server events `joined{peer}`, `peer-joined`, `peer-left`. One parent + one child per room; 64 KiB message cap; 120 msgs/10 s; no persistence; no payload logging. `GET /ice?room=` returns STUN plus coturn REST credentials (6 h).
