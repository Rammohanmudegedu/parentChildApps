# Building the APKs

## With GitHub Actions (recommended)

The workflow is `.github/workflows/build-apks.yml`. It runs the unit tests, then builds both apps in parallel and gives you two APKs.

### 1. Push the project to GitHub
The **`smart-parent` folder must be the repository root** (so `.github/` is at the top level).
```bash
cd smart-parent
git init -b main
git add -A
git commit -m "Smart Parent"
git remote add origin https://github.com/<you>/smart-parent.git
git push -u origin main
```
A private repository is fine.

### 2. One-time: create a signing key (recommended)
Without this the workflow builds **debug** APKs signed with a random key on each run, so every new build must be installed after **uninstalling** the old one, which deletes the pairing. With a key, new builds install as updates and pairing is kept.

```bash
keytool -genkeypair -v -keystore smartparent.jks -alias smartparent \
  -keyalg RSA -keysize 4096 -validity 10000
# Linux / macOS / Git Bash:
base64 -w0 smartparent.jks > smartparent.jks.b64        # macOS: base64 -i smartparent.jks > smartparent.jks.b64
# Windows PowerShell:
# [Convert]::ToBase64String([IO.File]::ReadAllBytes("smartparent.jks")) | Out-File smartparent.jks.b64 -NoNewline
```
GitHub → repository → **Settings → Secrets and variables → Actions → New repository secret**:

| Secret | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | contents of `smartparent.jks.b64` |
| `ANDROID_KEYSTORE_PASSWORD` | the keystore password you typed |
| `ANDROID_KEY_ALIAS` | `smartparent` |
| `ANDROID_KEY_PASSWORD` | the key password (same as the keystore password if you pressed Enter) |

Keep `smartparent.jks` and its password safe and **never commit it**. Losing it means future builds can't update the installed apps.

### 3. Optional: default relay address
**Settings → Secrets and variables → Actions → Variables → New repository variable**: `SIGNAL_URL` = `wss://signal.your-domain.com`.
This only pre-fills the child phone's Connection screen. You can always type it there.

### 4. Run
**Actions → Build APKs → Run workflow**. The inputs are:
- **signal_url**: overrides `SIGNAL_URL` for this build.
- **allow_cleartext**: allows `ws://` addresses, e.g. testing with the relay on your PC over Wi-Fi. Leave it off for real use.
- **publish_release**: attaches the APKs to a GitHub Release, which is the easiest way to download them on a phone.

Pushing to `main` also builds, with no release. That takes about 8–12 minutes on the first run, faster after that thanks to the Gradle cache.

### 5. Install on the phones
- Open the repository's **Releases** page in the phone's browser (signed in to GitHub if the repo is private), or download the artifacts from the run page.
- `SmartParent-1.0.N-….apk` goes on the **parent** phone. `SmartParentChild-1.0.N-….apk` goes on the **child** phone.
- Tapping the APK asks you to allow "Install unknown apps" for the browser or Files app. Allow it.
- Play Protect may warn that it doesn't recognise the developer. Choose **More details → Install anyway**. The child app gets extra scrutiny because it uses an accessibility service.
- Then follow docs/INSTALL.md §3 (pairing).

### If the build fails
Open the failed step's log and send the first `e:` (Kotlin) or `error:` lines. These projects have not been compiled before this first CI run, so a small fix may be needed. Common causes:
- `Could not find io.getstream:stream-webrtc-android:…`: set the version in `child-app/android/app/build.gradle` to the one in the README of github.com/GetStream/webrtc-android.
- SDK licence errors: rerun the job, since `setup-android` accepts licences on the first attempt.

## Locally with Android Studio
```bash
cd parent-app && npm install && npm run sync && npm run open    # then Run ▶ or Build › Build APK(s)
cd ../child-app && npm install && npm run sync && npm run open
```
Command line: `npm run apk:debug`, which outputs `android/app/build/outputs/apk/debug/app-debug.apk`.
For signed release builds locally, create `android/keystore.properties` (git-ignored) in each app:
```properties
storeFile=/absolute/path/smartparent.jks
storePassword=…
keyAlias=smartparent
keyPassword=…
```
Then run `npm run apk:release`.

Same configuration as CI: `SIGNAL_URL=wss://… ALLOW_CLEARTEXT=false node scripts/ci-configure.mjs child-app` before `npm run sync`.
