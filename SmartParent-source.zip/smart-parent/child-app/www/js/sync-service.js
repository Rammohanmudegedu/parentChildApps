// Pairing on the child phone. The cryptography and the relay connection run natively
// (net/SyncEngine.kt) so they keep working when this screen is closed; this module drives the UI.
import { call, on } from './native.js';

export async function startPairing(signalUrl) {
  return call('startPairing', { signalUrl }); // -> { uri, expiresAt }
}
export const cancelPairing = () => call('cancelPairing');
export const respondPairing = (approve) => call('respondPairing', { approve });
export const unpair = (pin) => call('unpair', { pin });

/** handler({ parentName, code }) – the person holding this phone must compare the code and decide. */
export const onPairingRequest = (handler) => on('pairingRequest', handler);
export const onPaired = (handler) => on('paired', handler);
export const onUnpaired = (handler) => on('unpaired', handler);

/** Renders the pairing URI as a QR code (qrcode-generator, offline). */
export function qrSvg(text) {
  const qr = window.qrcode(0, 'M');
  qr.addData(text, 'Byte');
  qr.make();
  return qr.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
}
