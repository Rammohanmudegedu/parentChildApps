// Connection status for the child UI.
// The child's WebRTC peer runs natively (net/PeerLink.kt via org.webrtc) inside the foreground
// service, because Android suspends a WebView's JavaScript when the app is in the background.
// This module only translates the native state for display.

export const CONNECTION_TEXT = {
  unpaired: { label: 'Not paired', pill: 'pill-off', detail: 'Pair with a parent phone to start sharing.' },
  offline: { label: 'Offline', pill: 'pill-cached', detail: 'No internet. Data is saved on this phone and sent when back online.' },
  waiting: { label: 'Ready', pill: 'pill-live', detail: 'Connected to the relay. Your parent sees updates when they open their app.' },
  connecting: { label: 'Connecting', pill: 'pill-cached', detail: 'Setting up an encrypted connection with your parent’s phone…' },
  connected: { label: 'Parent viewing', pill: 'pill-live', detail: 'Your parent’s app is connected right now.' },
};

export function describe(state) { return CONNECTION_TEXT[state] || CONNECTION_TEXT.offline; }
