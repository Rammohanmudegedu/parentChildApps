// Permission catalogue with plain-language explanations for the child.
// Each entry is requested only when the matching feature needs it.
import { call } from './native.js';
import { confirmModal } from './common/sp-ui.js';

export const PERMISSIONS = [
  {
    key: 'usageAccess', icon: 'bi-hourglass-split', title: 'Usage access',
    why: 'Measures how long each app is used. Without it, screen time and app limits cannot work.',
    required: true, action: () => call('openSettings', { target: 'usage' }),
    how: 'Settings opens: find “Smart Parent Child” and turn on “Permit usage access”.',
  },
  {
    key: 'notifications', icon: 'bi-bell', title: 'Notifications',
    why: 'Shows the always-on “Sharing with parent” notice, pairing requests and setting changes.',
    required: true, action: () => call('requestNotifications'),
  },
  {
    key: 'accessibility', icon: 'bi-pause-circle', title: 'Limits (accessibility service)',
    why: 'Pauses apps during bedtime, study time or when a time limit is reached. Reads only which app is opened.',
    required: false, action: () => accessibilityDisclosure(),
  },
  {
    key: 'location', icon: 'bi-geo-alt', title: 'Location',
    why: 'Lets your parent see where this phone is, only while location sharing is on. You can pause it in Privacy.',
    required: false, action: () => call('requestLocation'),
  },
  {
    key: 'backgroundLocation', icon: 'bi-geo', title: 'Location while the app is closed',
    why: 'Android asks for this separately. Choose “Allow all the time” on the next screen if your family agreed to location sharing.',
    required: false, action: () => call('openSettings', { target: 'app' }),
    how: 'Open Permissions → Location → “Allow all the time”.',
  },
  {
    key: 'batteryUnrestricted', icon: 'bi-battery-charging', title: 'Run in background',
    why: 'Stops Android from closing Smart Parent to save battery, so the connection to your parent stays reliable.',
    required: false, action: () => call('openSettings', { target: 'battery' }),
  },
];

// Google Play requires a prominent disclosure before an accessibility service is enabled.
export async function accessibilityDisclosure() {
  const ok = await confirmModal({
    title: 'Turn on limits?',
    body: `<p>Smart Parent uses Android's <strong>accessibility service</strong> to pause apps when your parent's rules say so
      (bedtime, study time, daily or per-app limits).</p>
      <ul class="small">
        <li><strong>Uses:</strong> only the name of the app that comes to the front.</li>
        <li><strong>Never reads:</strong> text, messages, passwords, notifications or anything on screen.</li>
        <li><strong>Never</strong> taps, types or acts for you.</li>
        <li>Calls, emergency, Settings and the keyboard are never paused.</li>
        <li>You can turn it off any time in Settings › Accessibility. Your parent is told when limits are off.</li>
      </ul>
      <p class="mb-0 small text-body-secondary">On the next screen choose <strong>Installed apps › Smart Parent limits</strong> and turn it on.</p>`,
    ok: 'Continue', cancel: 'Not now',
  });
  if (ok) await call('openSettings', { target: 'accessibility' });
}
