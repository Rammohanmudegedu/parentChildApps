// Reads the child's own status from the native layer (UsageStatsManager, BatteryManager, etc.)
// and keeps a single cached copy for the views. Refreshes on native events and every 30 s.
import { call, on, isNative } from './native.js';

let status = null;
let listeners = new Set();
let timer = null;

export function getStatus() { return status; }
export function onStatus(fn) { listeners.add(fn); return () => listeners.delete(fn); }

export async function refresh() {
  if (!isNative) return null;
  try {
    status = await call('getStatus');
    listeners.forEach((fn) => fn(status));
  } catch (e) {
    console.warn('status failed', e?.message);
  }
  return status;
}

export async function screenTime(days = 7) {
  return call('getScreenTime', { days });
}

export function start() {
  if (!isNative || timer) return;
  refresh();
  timer = setInterval(refresh, 30_000);
  for (const ev of ['connection', 'tick', 'settings', 'paired', 'unpaired', 'accessibility', 'location']) on(ev, () => refresh());
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
}
