// Default signaling relay shown on the Connection screen before pairing.
// Point this at your deployment of /signaling-server (must be wss:// in production).
export const DEFAULT_SIGNAL_URL = 'wss://signal.your-domain.com';
export const APP_VERSION = '1.0.0';
