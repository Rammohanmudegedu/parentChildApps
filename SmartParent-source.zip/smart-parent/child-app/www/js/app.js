// Smart Parent – child app UI (router + views).
import { $, $$, esc, fmtDuration, fmtBytes, fmtAgo, fmtTime, toast, applyTheme, setTheme, getTheme, chartColors, dayLabel, confirmModal } from './common/sp-ui.js';
import { isNative, call, on } from './native.js';
import * as monitor from './device-monitor.js';
import { PERMISSIONS, accessibilityDisclosure } from './permissions.js';
import * as pairing from './sync-service.js';
import { describe } from './webrtc-service.js';
import { prefs } from './local-storage.js';
import { DEFAULT_SIGNAL_URL, APP_VERSION } from './config.js';

applyTheme();
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => applyTheme());

// Child app is intentionally minimal: Connection (home) + "What's shared" (transparency).
const TITLES = { connection: 'Smart Parent', privacy: "What my parent can see" };
let current = null;
let charts = [];
let pairingTimer = null;

function destroyCharts() { charts.forEach((c) => c.destroy()); charts = []; }

function route() {
  const r = (location.hash || '#' + prefs.lastRoute).slice(1);
  const name = TITLES[r] ? r : 'connection';
  prefs.lastRoute = name;
  current = name;
  $$('.sp-bottomnav a').forEach((a) => a.classList.toggle('active', a.dataset.route === name));
  $('#page-title').textContent = TITLES[name];
  destroyCharts();
  if (name !== 'connection') clearInterval(pairingTimer);
  VIEWS[name]();
  window.scrollTo(0, 0);
}

function header(s) {
  const d = describe(s?.connection || 'unpaired');
  const pill = $('#conn-pill');
  pill.className = 'sp-pill pill-on-hero';
  pill.querySelector('span:last-child').textContent = d.label;
}

monitor.onStatus((s) => { header(s); if (['privacy', 'connection'].includes(current) && !document.querySelector('.modal.show')) VIEWS[current](true); });

// ---------------------------------------------------------------- Dashboard
function viewDashboard() {
  const s = monitor.getStatus();
  const v = $('#view');
  if (!isNative) { v.innerHTML = notNative('Your screen time, battery and connection appear here once the app is installed on this phone.'); return; }
  if (!s) { v.innerHTML = loading(); return; }
  const d = s.device || {};
  const st = s.settings || {};
  const used = d.screenTimeTodayMs || 0;
  const limit = (st.dailyLimitMinutes || 0) * 60000;
  const pct = limit ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const conn = describe(s.connection);
  const missing = PERMISSIONS.filter((p) => p.required && !s.permissions?.[p.key]);
  v.innerHTML = `
    ${!s.paired ? `<div class="sp-banner banner-info mb-3"><i class="bi bi-link-45deg"></i><div>This phone isn't paired yet. <a href="#connection">Pair with a parent phone</a>.</div></div>` : ''}
    ${missing.length ? `<div class="sp-banner banner-warn mb-3"><i class="bi bi-exclamation-triangle"></i><div>${missing.length} required permission${missing.length > 1 ? 's are' : ' is'} off. <a href="#permissions">Fix now</a></div></div>` : ''}
    <section class="sp-hero">
      <div class="d-flex justify-content-between align-items-start">
        <div><div class="label">Screen time today</div><div class="big tabular">${fmtDuration(used)}</div></div>
        <span class="sp-pill pill-on-hero"><span class="dot"></span>${esc(conn.label)}</span>
      </div>
      ${limit ? `<div class="mt-3"><div class="d-flex justify-content-between small"><span>${pct}% of daily limit</span><span>${fmtDuration(Math.max(0, limit - used))} left</span></div>
      <div class="sp-bar" style="background:rgba(255,255,255,.25)"><span style="width:${pct}%;background:#fff"></span></div></div>` : '<div class="label mt-2">No daily limit set</div>'}
    </section>
    <div class="row g-2 mt-1">
      ${stat('bi-battery-half', `${d.battery?.percent ?? '—'}%`, d.battery?.charging ? 'Charging' : 'Battery')}
      ${stat('bi-geo-alt', s.locationSharing?.effective ? 'On' : 'Off', 'Location sharing')}
      ${stat('bi-arrow-repeat', fmtAgo(s.lastSync), 'Last sync')}
      ${stat('bi-pause-circle', d.enforcementActive ? 'Active' : 'Off', 'Limits')}
    </div>
    <div class="sp-section-title">Most used today</div>
    <div class="sp-card">${topApps(d.topApps || [], used)}</div>
    <div class="sp-section-title">Your parent's rules</div>
    <div class="sp-card">${rulesSummary(st)}</div>`;
}

const stat = (icon, val, lbl) => `<div class="col-6"><div class="sp-stat"><div class="ico"><i class="bi ${icon}"></i></div><div class="val tabular">${esc(val)}</div><div class="lbl">${esc(lbl)}</div></div></div>`;

function topApps(list, total) {
  if (!list.length) return `<div class="sp-empty"><i class="bi bi-phone"></i>No app usage yet today${monitor.getStatus()?.permissions?.usageAccess ? '' : ' (Usage access is off)'}.</div>`;
  return `<ul class="sp-list">${list.map((a) => `<li><div class="sp-app-icon"><i class="bi bi-app"></i></div><div class="grow"><div class="title">${esc(a.label)}</div>
    <div class="sp-bar"><span style="width:${total ? Math.round((a.ms / total) * 100) : 0}%"></span></div></div><div class="tabular">${fmtDuration(a.ms)}</div></li>`).join('')}</ul>`;
}

function rulesSummary(st) {
  if (!st || st.dailyLimitMinutes === undefined) return '<div class="sub">No rules yet.</div>';
  const sch = (x) => (x?.enabled ? `${x.start}–${x.end}` : 'Off');
  const n = Object.keys(st.appLimits || {}).length;
  return `<ul class="sp-list">
    <li><i class="bi bi-clock"></i><div class="grow">Daily limit</div><strong>${st.dailyLimitMinutes ? fmtDuration(st.dailyLimitMinutes * 60000) : 'None'}</strong></li>
    <li><i class="bi bi-moon-stars"></i><div class="grow">Bedtime</div><strong>${sch(st.bedtime)}</strong></li>
    <li><i class="bi bi-book"></i><div class="grow">Study time</div><strong>${sch(st.studyTime)}</strong></li>
    <li><i class="bi bi-grid"></i><div class="grow">App limits</div><strong>${n || 'None'}</strong></li>
    <li><i class="bi bi-shield-check"></i><div class="grow">Limits enforced</div><strong>${st.enforcementEnabled ? 'Yes' : 'No'}</strong></li></ul>`;
}

// ---------------------------------------------------------------- Screen time
async function viewScreenTime() {
  const v = $('#view');
  if (!isNative) { v.innerHTML = notNative('Your daily and weekly screen time will be shown here.'); return; }
  v.innerHTML = loading();
  let data;
  try { data = await monitor.screenTime(7); } catch (e) { v.innerHTML = errorBox(e); return; }
  if (current !== 'screentime') return;
  const s = monitor.getStatus();
  const limits = s?.settings?.appLimits || {};
  const totals = data.days.map((d) => d.totalMs);
  const avg = totals.length ? totals.reduce((a, b) => a + b, 0) / totals.length : 0;
  v.innerHTML = `
    <div class="row g-2">${stat('bi-calendar-day', fmtDuration(totals.at(-1) || 0), 'Today')}${stat('bi-graph-up', fmtDuration(avg), 'Daily average (7 days)')}</div>
    <div class="sp-section-title">Last 7 days</div>
    <div class="sp-card"><div class="chart-box"><canvas id="weekChart" aria-label="Screen time per day"></canvas></div></div>
    <div class="sp-section-title">Apps today</div>
    <div class="sp-card">${data.today.length ? `<ul class="sp-list">${data.today.map((a) => {
      const lim = limits[a.pkg];
      return `<li><div class="sp-app-icon"><i class="bi bi-app"></i></div><div class="grow"><div class="title">${esc(a.label)}</div>
        <div class="meta">${a.launches} opens · last ${fmtAgo(a.lastUsed)}${lim !== undefined ? ` · limit ${lim === 0 ? 'paused' : fmtDuration(lim * 60000)}` : ''}</div>
        ${lim ? `<div class="sp-bar"><span style="width:${Math.min(100, Math.round((a.ms / (lim * 60000)) * 100))}%"></span></div>` : ''}</div>
        <div class="tabular">${fmtDuration(a.ms)}</div></li>`;
    }).join('')}</ul>` : '<div class="sp-empty"><i class="bi bi-hourglass"></i>No usage recorded today.</div>'}</div>`;
  const c = chartColors();
  charts.push(new window.Chart($('#weekChart'), {
    type: 'bar',
    data: { labels: data.days.map((d) => dayLabel(d.date)), datasets: [{ data: totals.map((t) => +(t / 3600000).toFixed(2)), backgroundColor: c.primary, borderRadius: 8, maxBarThickness: 28 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (x) => fmtDuration(x.raw * 3600000) } } },
      scales: { y: { ticks: { color: c.muted, callback: (x) => x + 'h' }, grid: { color: c.border } }, x: { ticks: { color: c.muted }, grid: { display: false } } } },
  }));
}

// ---------------------------------------------------------------- Permissions
function viewPermissions() {
  const v = $('#view');
  if (!isNative) { v.innerHTML = notNative('Permissions are requested on the phone itself.'); return; }
  const s = monitor.getStatus();
  if (!s) { v.innerHTML = loading(); return; }
  v.innerHTML = `<div class="sp-banner banner-info mb-3"><i class="bi bi-info-circle"></i><div>Smart Parent asks only for what its features need. Each one can be turned off later in Android Settings.</div></div>
    <div class="sp-card"><ul class="sp-list">${PERMISSIONS.map((p) => {
      const on = !!s.permissions?.[p.key];
      return `<li class="align-items-start"><div class="sp-app-icon"><i class="bi ${p.icon}"></i></div><div class="grow">
        <div class="title">${esc(p.title)} ${p.required ? '<span class="badge text-bg-light border ms-1">Needed</span>' : ''}</div>
        <div class="meta">${esc(p.why)}</div>${!on && p.how ? `<div class="meta mt-1"><i class="bi bi-lightbulb"></i> ${esc(p.how)}</div>` : ''}</div>
        ${on ? '<span class="sp-pill pill-live mt-1"><i class="bi bi-check2"></i>On</span>' : `<button class="btn btn-sm btn-primary" data-perm="${p.key}">Turn on</button>`}</li>`;
    }).join('')}</ul></div>
    ${s.permissions && !s.permissions.locationServicesOn ? `<div class="sp-banner banner-warn mt-3"><i class="bi bi-geo"></i><div>Location is switched off for the whole phone. <a href="#" data-loc-settings>Open location settings</a></div></div>` : ''}`;
  $$('[data-perm]').forEach((b) => b.addEventListener('click', async () => {
    const p = PERMISSIONS.find((x) => x.key === b.dataset.perm);
    try { await p.action(); } catch (e) { toast(e.message); }
    setTimeout(monitor.refresh, 800);
  }));
  $('[data-loc-settings]')?.addEventListener('click', (e) => { e.preventDefault(); call('openSettings', { target: 'location' }); });
}

// ---------------------------------------------------------------- Connection / pairing
// The special accesses Android will not let any app bundle into the one-tap grant.
const SPECIAL_PERMS = [
  { key: 'usageAccess', icon: 'bi-hourglass-split', title: 'Usage access', target: 'usage', why: 'Needed to measure screen time.' },
  { key: 'accessibility', icon: 'bi-pause-circle', title: 'Limits (pause apps)', special: 'a11y', why: 'Lets your parent pause apps during bedtime or limits.' },
  { key: 'batteryUnrestricted', icon: 'bi-battery-charging', title: 'Run in background', target: 'battery', why: 'Keeps the connection reliable.' },
];

function permissionSection(s) {
  const p = s.permissions || {};
  const oneTap = [['notifications', 'Notifications'], ['location', 'Location'], ['contacts', 'Contacts']];
  const oneTapDone = oneTap.every(([k]) => p[k]);
  const rows = (list) => list.map(([k, label]) => `<li><div class="grow">${label}</div><span class="sp-pill ${p[k] ? 'pill-live' : 'pill-off'}">${p[k] ? 'On' : 'Off'}</span></li>`).join('');
  return `
    <div class="sp-section-title">Access</div>
    <div class="sp-card">
      <p class="sub mb-2">One tap grants notifications, location and contacts together. Android asks for each in turn — allow them all.</p>
      <button id="grant-all" class="btn ${oneTapDone ? 'btn-light' : 'btn-primary'} w-100 mb-2">
        <i class="bi bi-check2-circle me-1"></i>${oneTapDone ? 'Notifications, location, contacts granted' : 'Grant access'}</button>
      <ul class="sp-list mb-0">${rows(oneTap)}</ul>
    </div>
    <div class="sp-card">
      <p class="sub mb-2">Android requires these two to be turned on individually — they can't be bundled.</p>
      <ul class="sp-list mb-0">${SPECIAL_PERMS.map((sp) => `<li><div class="sp-app-icon"><i class="bi ${sp.icon}"></i></div>
        <div class="grow"><div class="title">${sp.title}</div><div class="meta">${esc(sp.why)}</div></div>
        ${p[sp.key] ? '<span class="sp-pill pill-live"><i class="bi bi-check2"></i>On</span>' : `<button class="btn btn-sm btn-primary" data-special="${sp.key}">Turn on</button>`}</li>`).join('')}</ul>
    </div>`;
}

function bindPermissionSection() {
  $('#grant-all')?.addEventListener('click', async () => {
    try { await call('requestAll'); } catch (e) { toast(e.message); }
    setTimeout(monitor.refresh, 600);
  });
  $$('[data-special]').forEach((b) => b.addEventListener('click', async () => {
    const sp = SPECIAL_PERMS.find((x) => x.key === b.dataset.special);
    try { if (sp.special === 'a11y') await accessibilityDisclosure(); else await call('openSettings', { target: sp.target }); }
    catch (e) { toast(e.message); }
    setTimeout(monitor.refresh, 800);
  }));
}

function viewConnection(fromStatus) {
  const v = $('#view');
  if (!isNative) { v.innerHTML = notNative('Pairing shows a QR code here for the parent phone to scan.'); return; }
  const s = monitor.getStatus();
  if (!s) { v.innerHTML = loading(); return; }
  if (fromStatus && $('#pair-qr')) return; // don't wipe a QR that is being shown
  const d = describe(s.connection);
  let main;
  if (s.paired) {
    main = `
      <div class="sp-card text-center py-4"><i class="bi bi-person-check fs-1 text-primary"></i>
        <h2 class="mt-2">Paired with ${esc(s.parentName)}</h2><div class="sub">Since ${fmtTime(s.pairedAt)}</div>
        <div class="mt-3"><span class="sp-pill ${d.pill}"><span class="dot"></span>${esc(d.label)}</span></div>
        <p class="sub mt-2 mb-0">${esc(d.detail)}</p>
        <a href="#privacy" class="btn btn-light mt-3"><i class="bi bi-eye me-1"></i>See what my parent can see</a></div>
      <div class="sp-card"><ul class="sp-list">
        <li><i class="bi bi-arrow-repeat"></i><div class="grow">Last sync</div><strong>${fmtAgo(s.lastSync)}</strong></li>
        <li><i class="bi bi-hdd-network"></i><div class="grow">Network</div><strong>${esc(s.device?.network?.type || '—')}${s.device?.network?.internet ? '' : ' (no internet)'}</strong></li>
        <li><i class="bi bi-lock"></i><div class="grow">Encryption</div><strong>End-to-end (AES-256-GCM)</strong></li></ul></div>`;
  } else {
    const url = prefs.draftSignalUrl || s.signalUrl || DEFAULT_SIGNAL_URL;
    main = `
      <div class="sp-card"><h2>Pair with a parent phone</h2>
        <ol class="sub ps-3 mb-3"><li>Open Smart Parent on the parent phone and tap <strong>Add child</strong>.</li>
        <li>Tap <strong>Show pairing code</strong> below and let them scan it.</li>
        <li>Check the 6-digit code matches on both phones, then decide here.</li></ol>
        <label class="form-label small text-body-secondary" for="sig">Relay address</label>
        <input id="sig" class="form-control mb-3" inputmode="url" autocomplete="off" spellcheck="false" value="${esc(url)}">
        <button id="pair-start" class="btn btn-primary w-100"><i class="bi bi-qr-code me-1"></i> Show pairing code</button></div>
      <div id="pair-area"></div>`;
  }
  v.innerHTML = main + permissionSection(s);
  bindPermissionSection();
  $('#sig')?.addEventListener('input', (e) => { prefs.draftSignalUrl = e.target.value.trim(); });
  $('#pair-start')?.addEventListener('click', startPairingUi);
}

async function startPairingUi() {
  const url = $('#sig').value.trim();
  const area = $('#pair-area');
  try {
    const { uri, expiresAt } = await pairing.startPairing(url);
    area.innerHTML = `<div class="sp-card text-center">
      <div id="pair-qr" class="sp-qr">${pairing.qrSvg(uri)}</div>
      <div class="sub mt-2">Valid for <span id="pair-left" class="tabular"></span> · single use</div>
      <div class="d-flex gap-2 justify-content-center mt-3"><button id="pair-copy" class="btn btn-light"><i class="bi bi-clipboard me-1"></i>Copy link</button>
      <button id="pair-cancel" class="btn btn-light">Cancel</button></div></div>`;
    $('#pair-copy').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(uri); toast('Pairing link copied – paste it in the parent app'); } catch { toast('Copy not available'); }
    });
    $('#pair-cancel').addEventListener('click', () => { pairing.cancelPairing(); clearInterval(pairingTimer); area.innerHTML = ''; });
    clearInterval(pairingTimer);
    const tickLeft = () => {
      const left = Math.max(0, expiresAt - Date.now());
      const el = $('#pair-left');
      if (!el) { clearInterval(pairingTimer); return; }
      el.textContent = `${Math.floor(left / 60000)}:${String(Math.floor((left % 60000) / 1000)).padStart(2, '0')}`;
      if (!left) { clearInterval(pairingTimer); area.innerHTML = '<div class="sp-banner banner-warn"><i class="bi bi-clock"></i><div>Code expired. Show a new one.</div></div>'; }
    };
    tickLeft(); pairingTimer = setInterval(tickLeft, 1000);
  } catch (e) { toast(e.message || 'Could not start pairing'); }
}

pairing.onPairingRequest(async ({ parentName, code }) => {
  const ok = await confirmModal({
    title: `${parentName} wants to connect`,
    body: `<p class="mb-2">Check that this code is shown on <strong>their</strong> phone:</p>
      <div class="code-digits text-center my-3">${esc(code)}</div>
      <p class="small text-body-secondary mb-0">If you allow it, they will see your screen time, apps, battery and device info, your saved contacts, and location while location sharing is on.
      You can always see exactly what's shared on the "What's shared" tab. If the code doesn't match, tap Deny.</p>`,
    ok: 'Allow', cancel: 'Deny',
  });
  try {
    const r = await pairing.respondPairing(!!ok);
    toast(r.paired ? `Paired with ${parentName}` : 'Pairing declined');
  } catch (e) { toast(e.message); }
  clearInterval(pairingTimer);
  await monitor.refresh();
  if (current === 'connection') viewConnection();
});
pairing.onUnpaired(({ reason }) => { toast(reason); monitor.refresh(); });

// ---------------------------------------------------------------- Privacy
function viewPrivacy() {
  const v = $('#view');
  if (!isNative) { v.innerHTML = notNative('This screen lists exactly what is shared with your parent.'); return; }
  const s = monitor.getStatus();
  if (!s) { v.innerHTML = loading(); return; }
  const loc = s.locationSharing || {};
  const shared = [
    ['bi-hourglass-split', 'Screen time and app usage', 'Minutes per app, number of opens, last used time', s.paired],
    ['bi-grid', 'Installed apps you can open', 'App names and icons', s.paired],
    ['bi-battery-half', 'Battery and device info', 'Battery level, charging, storage, Android version, network type', s.paired],
    ['bi-person-lines-fill', 'Contacts', s.permissions?.contacts ? 'The names and numbers you have saved' : 'Not shared (contacts permission is off)', s.paired && s.permissions?.contacts],
    ['bi-geo-alt', 'Location', loc.effective ? 'Shared now' : loc.pausedByChild ? 'Paused by you' : !loc.requestedByParent ? 'Not requested by your parent' : 'Off (permission not given)', loc.effective],
    ['bi-bell', 'Alerts', 'Limit reached, bedtime started, battery low, sharing turned off', s.paired],
  ];
  const never = ['Message, chat or email contents', 'Notification contents', 'Keystrokes or passwords', 'Camera or microphone', 'Your photos and files', 'Browsing history or live screen contents'];
  v.innerHTML = `
    <div class="sp-card"><h2>Shared with ${esc(s.parentName || 'your parent')}</h2>
      <ul class="sp-list">${shared.map(([i, t, d, on]) => `<li><div class="sp-app-icon"><i class="bi ${i}"></i></div><div class="grow"><div class="title">${t}</div><div class="meta">${esc(d)}</div></div>
      <span class="sp-pill ${on ? 'pill-live' : 'pill-off'}">${on ? 'Shared' : 'Not shared'}</span></li>`).join('')}</ul></div>
    <div class="sp-card"><div class="form-check form-switch d-flex align-items-center gap-3 ps-0">
      <div class="grow flex-grow-1"><h2 class="mb-1">Pause location sharing</h2><div class="sub">Your parent is told that you paused it.</div></div>
      <input class="form-check-input ms-auto" type="checkbox" role="switch" id="locpause" ${loc.pausedByChild ? 'checked' : ''} ${s.paired ? '' : 'disabled'}></div></div>
    <div class="sp-card"><h2>Never collected</h2><ul class="sub mb-0 ps-3">${never.map((n) => `<li>${n}</li>`).join('')}</ul></div>
    <div class="sp-section-title">Recent alerts sent to your parent</div>
    <div class="sp-card">${(s.alerts || []).length ? `<ul class="sp-list">${s.alerts.slice().reverse().map((a) => `<li><i class="bi bi-bell"></i><div class="grow"><div class="title">${esc(a.title)}</div><div class="meta">${esc(a.detail)} · ${fmtAgo(a.ts)}</div></div></li>`).join('')}</ul>` : '<div class="sp-empty"><i class="bi bi-bell-slash"></i>No alerts.</div>'}</div>
    ${s.paired ? `<div class="sp-card"><h2>Stop sharing</h2><p class="sub">Unpairing removes the connection and deletes the history stored on this phone.${s.settings?.unpairPinSet ? ' Your parent set a PIN for this.' : ''}</p>
      <button id="unpair" class="btn btn-outline-danger w-100">Unpair this phone</button></div>` : ''}`;
  $('#locpause')?.addEventListener('change', async (e) => {
    try { await call('setLocationPaused', { paused: e.target.checked }); toast(e.target.checked ? 'Location sharing paused' : 'Location sharing resumed'); }
    catch (err) { toast(err.message); e.target.checked = !e.target.checked; }
    monitor.refresh();
  });
  $('#unpair')?.addEventListener('click', async () => {
    const needPin = !!s.settings?.unpairPinSet;
    const el = await confirmModal({
      title: 'Unpair this phone?',
      body: `<p>${esc(s.parentName)} will no longer see this phone, and the history saved here is deleted.</p>${needPin ? '<input type="password" inputmode="numeric" class="form-control" id="unpin" placeholder="Parent PIN" autocomplete="off">' : ''}`,
      ok: 'Unpair', danger: true,
    });
    if (!el) return;
    try { await pairing.unpair(needPin ? el.querySelector('#unpin').value : ''); toast('Unpaired'); }
    catch (e) { toast(e.message || 'Could not unpair'); }
    monitor.refresh();
  });
}

// ---------------------------------------------------------------- Settings
function viewSettings() {
  const v = $('#view');
  const s = monitor.getStatus();
  const theme = getTheme();
  v.innerHTML = `
    <div class="sp-card"><h2>Appearance</h2>
      <div class="btn-group w-100 mt-2" role="group">${['system', 'light', 'dark'].map((t) => `<input type="radio" class="btn-check" name="theme" id="th-${t}" value="${t}" ${t === theme ? 'checked' : ''}><label class="btn btn-outline-primary" for="th-${t}">${t[0].toUpperCase() + t.slice(1)}</label>`).join('')}</div></div>
    <div class="sp-card"><h2>Limits</h2><p class="sub">Rules are set by your parent. Limits need the accessibility service to pause apps.</p>
      <button id="a11y" class="btn btn-light w-100">${s?.permissions?.accessibility ? 'Limits service is on – manage' : 'Turn on limits'}</button></div>
    <div class="sp-card"><h2>About</h2><ul class="sp-list">
      <li><div class="grow">Version</div><strong>${APP_VERSION}</strong></li>
      <li><div class="grow">Device</div><strong>${esc(s?.device ? `${s.device.manufacturer} ${s.device.model}` : '—')}</strong></li>
      <li><div class="grow">Android</div><strong>${esc(s?.device?.androidVersion || '—')}</strong></li>
      <li><div class="grow">Storage free</div><strong>${fmtBytes(s?.device?.storage?.freeBytes)}</strong></li></ul></div>`;
  $$('input[name=theme]').forEach((r) => r.addEventListener('change', () => { setTheme(r.value); }));
  $('#a11y').addEventListener('click', () => (isNative ? (s?.permissions?.accessibility ? call('openSettings', { target: 'accessibility' }) : accessibilityDisclosure()) : toast('Only available in the Android app')));
}

// ---------------------------------------------------------------- helpers
const loading = () => '<div class="sp-empty"><div class="spinner-border text-primary" role="status"></div></div>';
const notNative = (msg) => `<div class="sp-empty"><i class="bi bi-phone"></i><div class="fw-semibold mb-1">Open the Android app</div>${esc(msg)}</div>`;
const errorBox = (e) => `<div class="sp-banner banner-bad"><i class="bi bi-x-circle"></i><div>${esc(e?.message || 'Something went wrong')}</div></div>`;

const VIEWS = { connection: viewConnection, privacy: viewPrivacy };

window.addEventListener('hashchange', route);
window.addEventListener('sp-route', (e) => { location.hash = '#' + e.detail; });
if (!isNative) $('#preview-banner').classList.remove('d-none');
monitor.start();
if (isNative) call('getLaunchRoute').then((r) => { if (r?.route) location.hash = '#' + r.route; }).catch(() => {});
route();
