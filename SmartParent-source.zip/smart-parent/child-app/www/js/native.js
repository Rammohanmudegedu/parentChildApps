// Thin wrapper over the native SmartParent Capacitor plugin (Kotlin: plugin/SmartParentPlugin.kt).
// Outside the Android app there is no plugin: callers get `isNative === false` and must show
// an honest "not available" state – never invented data.

const cap = window.Capacitor;
export const plugin = cap?.Plugins?.SmartParent;
export const isNative = !!(cap?.isNativePlatform?.() && plugin);

export class NotNativeError extends Error {
  constructor() { super('Only available in the installed Android app'); this.code = 'NOT_NATIVE'; }
}

export async function call(method, args = {}) {
  if (!isNative) throw new NotNativeError();
  return plugin[method](args);
}

export function on(event, handler) {
  if (!isNative) return () => {};
  const h = plugin.addListener(event, handler);
  return () => Promise.resolve(h).then((x) => x.remove());
}
