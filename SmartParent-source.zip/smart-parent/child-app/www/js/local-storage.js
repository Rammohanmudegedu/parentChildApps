// UI-only preferences for the child app (theme, last tab).
// Monitoring data is NOT stored here: it lives in the native SQLite database (data/MonitorDb.kt),
// with location rows and pairing keys encrypted by an Android Keystore key (core/KeyVault.kt).
import { safeGet, safeSet } from './common/sp-ui.js';

export const prefs = {
  get lastRoute() { return safeGet('sp.child.route') || 'dashboard'; },
  set lastRoute(v) { safeSet('sp.child.route', v); },
  get draftSignalUrl() { return safeGet('sp.child.signal') || ''; },
  set draftSignalUrl(v) { safeSet('sp.child.signal', v); },
};
