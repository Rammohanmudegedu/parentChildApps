package com.smartparent.child.service

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.smartparent.child.collect.DeviceCollector
import com.smartparent.child.core.ChildRuntime
import com.smartparent.child.net.SyncEngine
import com.smartparent.child.policy.PolicyEngine
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Foreground service: keeps collection, enforcement checks and the WebRTC link alive while the
 * app UI is closed. Runs only while paired, and always with the visible "Sharing with parent"
 * notification. Type: specialUse (parental controls) + location while location sharing is on.
 */
class MonitorService : Service() {
    private lateinit var thread: HandlerThread
    internal lateinit var handler: Handler
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        ChildRuntime.init(this)
        Notifier.channels(this)
        goForeground()
        thread = HandlerThread("sp-monitor").also { it.start() }
        handler = Handler(thread.looper)
        engine(this).start()
        val cm = getSystemService(ConnectivityManager::class.java)
        netCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { engine(this@MonitorService).networkAvailable() }
        }.also { cm.registerDefaultNetworkCallback(it) }
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (ChildRuntime.pairing() == null) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_APPLY) { goForeground(); handler.post { applyLocation() } }
        return START_STICKY
    }

    internal fun goForeground() {
        var types = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        val wantLocation = ChildRuntime.locationSharingEffective() && ChildRuntime.location.hasBackgroundPermission()
        if (wantLocation && Build.VERSION.SDK_INT >= 29) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        try {
            ServiceCompat.startForeground(this, Notifier.ID_ONGOING, Notifier.ongoing(this), types)
        } catch (e: Exception) {
            // e.g. location type not allowed right now (started from background without background location)
            ServiceCompat.startForeground(this, Notifier.ID_ONGOING, Notifier.ongoing(this),
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            runCatching { evaluate() }
            handler.postDelayed(this, TICK_MS)
        }
    }

    internal fun applyLocation() {
        val rt = ChildRuntime
        if (rt.locationSharingEffective()) rt.location.start(rt.settings().locationIntervalMinutes) else rt.location.stop()
    }

    /** Runs every minute: refresh usage, raise alerts once, keep location in the requested state. */
    private fun evaluate() {
        val rt = ChildRuntime
        if (rt.pairing() == null) { stopSelf(); return }
        val s = rt.settings()
        val today = LocalDate.now().toString()
        val rows = rt.refreshUsage(force = true)
        val total = rows.sumOf { it.fgMs }
        val now = LocalDateTime.now()

        if (s.dailyLimitMinutes > 0 && total >= s.dailyLimitMinutes * 60_000L)
            rt.alert("DAILY_LIMIT_REACHED", "Daily screen-time limit reached", "Used ${PolicyEngine.fmt((total / 60_000).toInt())} today (limit ${PolicyEngine.fmt(s.dailyLimitMinutes)}).", "daily:$today")
        for ((pkg, lim) in s.appLimits) {
            if (lim <= 0) continue
            val used = rows.firstOrNull { it.pkg == pkg } ?: continue
            if (used.fgMs >= lim * 60_000L)
                rt.alert("APP_LIMIT_REACHED", "${used.label} limit reached", "Used ${PolicyEngine.fmt((used.fgMs / 60_000).toInt())} of ${PolicyEngine.fmt(lim)}.", "app:$pkg:$today")
        }
        if (s.bedtime.isActive(now)) rt.alert("BEDTIME_STARTED", "Bedtime started", "Bedtime ${s.bedtime.start}–${s.bedtime.end}.", "bed:${if (now.toLocalTime() < s.bedtime.end && s.bedtime.start > s.bedtime.end) LocalDate.now().minusDays(1) else LocalDate.now()}")
        if (s.studyTime.isActive(now)) rt.alert("STUDY_TIME_STARTED", "Study time started", "Study time ${s.studyTime.start}–${s.studyTime.end}.", "study:$today")

        val bat = DeviceCollector.battery(this)
        if (bat.charging || bat.percent > s.lowBatteryPercent + 5) rt.db.kvPut("once:batlow", null)
        else if (bat.percent <= s.lowBatteryPercent) rt.alert("BATTERY_LOW", "Battery low", "Battery at ${bat.percent}%.", "batlow")

        stateAlert("usage", rt.usage.hasAccess(), "USAGE_ACCESS_REVOKED", "Usage access turned off", "Screen time can't be measured until Usage access is turned back on.")
        if (s.locationSharingRequested) {
            stateAlert("locperm", rt.location.hasForegroundPermission(), "LOCATION_PERMISSION_REVOKED", "Location permission off", "The location permission was removed on the child phone.")
            stateAlert("locpause", !rt.locationPaused(), "LOCATION_SHARING_DISABLED", "Location sharing paused", "Location sharing was paused on the child phone.")
        }
        if (s.enforcementEnabled) stateAlert("a11y", rt.accessibilityRunning, "ENFORCEMENT_DISABLED", "Limits not enforced", "Smart Parent's accessibility service is off, so limits can't block apps right now.")

        applyLocation()
        if (rt.db.kvGet("pruned") != today) { rt.db.prune(); rt.db.kvPut("pruned", today) }
        Notifier.updateOngoing(this)
        rt.emit("tick")
    }

    /** Alert on the transition from OK to not-OK only (not every minute). */
    private fun stateAlert(key: String, ok: Boolean, kind: String, title: String, detail: String) {
        val rt = ChildRuntime
        val prev = rt.db.kvGet("state:$key")
        rt.db.kvPut("state:$key", if (ok) "ok" else "bad")
        if (!ok && prev == "ok") rt.alert(kind, title, detail)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        netCallback?.let { runCatching { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } }
        handler.removeCallbacksAndMessages(null)
        thread.quitSafely()
        ChildRuntime.location.stop()
        super.onDestroy()
    }

    companion object {
        private const val TICK_MS = 60_000L
        private const val ACTION_APPLY = "com.smartparent.child.APPLY"
        @Volatile private var engineRef: SyncEngine? = null
        @Volatile private var instance: MonitorService? = null

        @Synchronized fun engine(ctx: Context): SyncEngine {
            ChildRuntime.init(ctx)
            return engineRef ?: SyncEngine(ctx.applicationContext).also { engineRef = it }
        }

        fun start(ctx: Context) {
            ChildRuntime.init(ctx)
            if (ChildRuntime.pairing() == null) return
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java))
            } catch (e: Exception) {
                // Android 12+ refuses FGS starts from the background; the next app open or reboot starts it.
                android.util.Log.w("SmartParent", "service start deferred: ${e.javaClass.simpleName}")
            }
        }

        /** Re-applies settings (location on/off, notification text). Uses the running service when there is one. */
        fun applySettings(ctx: Context) {
            val svc = instance
            if (svc != null) {
                svc.handler.post { runCatching { svc.goForeground(); svc.applyLocation() } }
                return
            }
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java).setAction(ACTION_APPLY))
            } catch (e: Exception) {
                android.util.Log.w("SmartParent", "apply deferred: ${e.javaClass.simpleName}")
            }
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, MonitorService::class.java)) }
    }
}

/** Restarts monitoring after reboot / app update, only if the phone is paired. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> runCatching { MonitorService.start(ctx) }
        }
    }
}
