package com.smartparent.child.plugin

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import androidx.core.app.NotificationManagerCompat
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import com.smartparent.child.core.ChildRuntime
import com.smartparent.child.core.CryptoBox
import com.smartparent.child.enforce.GuardAccessibilityService
import com.smartparent.child.service.MonitorService
import com.smartparent.child.service.Notifier
import org.json.JSONObject
import java.time.LocalDate
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Bridge between the child web UI (www/js) and the native layer.
 * JS: Capacitor.Plugins.SmartParent.<method>()
 */
@CapacitorPlugin(
    name = "SmartParent",
    permissions = [
        Permission(alias = "location", strings = [Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION]),
        Permission(alias = "notifications", strings = [Manifest.permission.POST_NOTIFICATIONS]),
    ],
)
class SmartParentPlugin : Plugin() {
    private val rt = ChildRuntime
    private val listener: (String, JSONObject) -> Unit = { event, data -> notifyListeners(event, JSObject.fromJSONObject(data)) }

    override fun load() {
        rt.init(context)
        Notifier.channels(context)
        rt.addListener(listener)
        if (rt.pairing() != null) MonitorService.start(context)
    }

    override fun handleOnDestroy() { rt.removeListener(listener) }

    private fun engine() = MonitorService.engine(context)

    // ---------------- status ----------------
    @PluginMethod
    fun getStatus(call: PluginCall) {
        Thread {
            val p = rt.pairing()
            val res = JSObject()
            res.put("paired", p != null)
            res.put("parentName", p?.parentName)
            res.put("pairedAt", p?.pairedAt ?: 0L)
            res.put("connection", rt.connection)
            res.put("lastSync", rt.lastSyncAt)
            res.put("signalUrl", rt.signalUrl())
            res.put("permissions", permissionsJson())
            res.put("locationSharing", JSObject()
                .put("requestedByParent", rt.settings().locationSharingRequested)
                .put("pausedByChild", rt.locationPaused())
                .put("effective", rt.locationSharingEffective())
                .put("last", rt.db.lastLocation()?.optLong("ts") ?: 0L))
            res.put("settings", JSObject.fromJSONObject(rt.settings().toPublicJson()))
            if (p != null) res.put("device", JSObject.fromJSONObject(engine().deviceStatus()))
            else res.put("device", JSObject.fromJSONObject(com.smartparent.child.collect.DeviceCollector.snapshot(context)))
            res.put("alerts", JSArray(rt.db.alertsSince(0, 500).let { a -> (maxOf(0, a.length() - 20) until a.length()).map { a.get(it) } }))
            call.resolve(res)
        }.start()
    }

    private fun permissionsJson(): JSObject = JSObject()
        .put("usageAccess", rt.usage.hasAccess())
        .put("location", rt.location.hasForegroundPermission())
        .put("backgroundLocation", rt.location.hasBackgroundPermission())
        .put("locationServicesOn", rt.location.isLocationEnabled())
        .put("notifications", NotificationManagerCompat.from(context).areNotificationsEnabled())
        .put("accessibility", isAccessibilityEnabled())
        .put("batteryUnrestricted", (context.getSystemService(PowerManager::class.java)).isIgnoringBatteryOptimizations(context.packageName))

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(context, GuardAccessibilityService::class.java).flattenToString()
        val split = TextUtils.SimpleStringSplitter(':').apply { setString(enabled) }
        return split.any { it.equals(me, ignoreCase = true) }
    }

    @PluginMethod
    fun getScreenTime(call: PluginCall) {
        val days = (call.getInt("days") ?: 7).coerceIn(1, 31)
        Thread {
            rt.refreshUsage(force = true)
            val from = LocalDate.now().minusDays(days.toLong() - 1).toString()
            val res = JSObject()
            res.put("days", JSArray(rt.db.screenDays(from).let { a -> (0 until a.length()).map { a.get(it) } }))
            res.put("today", JSArray(rt.todayRows.map { JSObject().put("pkg", it.pkg).put("label", it.label).put("ms", it.fgMs).put("launches", it.launches).put("lastUsed", it.lastUsed) }))
            call.resolve(res)
        }.start()
    }

    // ---------------- permissions ----------------
    @PluginMethod
    fun requestLocation(call: PluginCall) {
        if (getPermissionState("location") == PermissionState.GRANTED) { afterPermission(call); return }
        requestPermissionForAlias("location", call, "permCallback")
    }

    @PluginMethod
    fun requestNotifications(call: PluginCall) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED) { afterPermission(call); return }
        requestPermissionForAlias("notifications", call, "permCallback")
    }

    @PermissionCallback
    private fun permCallback(call: PluginCall) = afterPermission(call)

    private fun afterPermission(call: PluginCall) {
        if (rt.pairing() != null) MonitorService.applySettings(context)
        call.resolve(JSObject().put("permissions", permissionsJson()))
    }

    /** target: usage | accessibility | app | battery | notifications | location */
    @PluginMethod
    fun openSettings(call: PluginCall) {
        val pkgUri = Uri.parse("package:${context.packageName}")
        val intent = when (call.getString("target")) {
            "usage" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                if (Build.VERSION.SDK_INT >= 29) data = pkgUri
            }
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "battery" -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri)
            "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(intent) } catch (e: Exception) {
            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        call.resolve()
    }

    // ---------------- pairing ----------------
    @PluginMethod
    fun startPairing(call: PluginCall) {
        val url = call.getString("signalUrl")?.trim().orEmpty()
        if (!Regex("^wss?://[A-Za-z0-9.-]+(:\\d+)?(/.*)?$").matches(url)) { call.reject("Enter a valid ws:// or wss:// signaling address"); return }
        if (rt.pairing() != null) { call.reject("Already paired. Unpair first."); return }
        rt.setSignalUrl(url)
        engine().startPairing(url) { uri, exp -> call.resolve(JSObject().put("uri", uri).put("expiresAt", exp)) }
    }

    @PluginMethod
    fun cancelPairing(call: PluginCall) { engine().cancelPairing(); call.resolve() }

    @PluginMethod
    fun respondPairing(call: PluginCall) {
        val approve = call.getBoolean("approve") ?: false
        engine().respondPairing(approve) { ok ->
            if (ok) MonitorService.start(context)
            call.resolve(JSObject().put("paired", ok))
        }
    }

    /** Child-initiated unpair. If the parent set an unpair PIN, it must be entered here. */
    @PluginMethod
    fun unpair(call: PluginCall) {
        val s = rt.settings()
        if (s.unpairPinHash != null && s.unpairPinSalt != null) {
            val pin = call.getString("pin").orEmpty()
            val spec = PBEKeySpec(pin.toCharArray(), CryptoBox.unb64u(s.unpairPinSalt), 150_000, 256)
            val hash = CryptoBox.b64u(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded)
            if (!CryptoBox.ctEquals(hash.toByteArray(), s.unpairPinHash.toByteArray())) { call.reject("Incorrect parent PIN", "BAD_PIN"); return }
        }
        engine().unpair("This phone was unpaired on the child phone.")
        call.resolve()
    }

    // ---------------- privacy controls ----------------
    @PluginMethod
    fun setLocationPaused(call: PluginCall) {
        rt.setLocationPaused(call.getBoolean("paused") ?: false)
        if (rt.pairing() != null) MonitorService.applySettings(context)
        Notifier.updateOngoing(context)
        call.resolve(JSObject().put("effective", rt.locationSharingEffective()))
    }

    @PluginMethod
    fun setSignalUrl(call: PluginCall) {
        val url = call.getString("url")?.trim().orEmpty()
        if (!Regex("^wss?://[A-Za-z0-9.-]+(:\\d+)?(/.*)?$").matches(url)) { call.reject("Invalid address"); return }
        rt.setSignalUrl(url); call.resolve()
    }

    @PluginMethod
    fun getLaunchRoute(call: PluginCall) {
        val route = activity?.intent?.getStringExtra("route")
        activity?.intent?.removeExtra("route")
        call.resolve(JSObject().put("route", route))
    }
}
