package com.smartparent.child.policy

import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.LocalTime

/** Weekly window, e.g. bedtime 21:30–06:30. days use ISO numbering 1=Monday … 7=Sunday. */
data class Schedule(val enabled: Boolean, val start: LocalTime, val end: LocalTime, val days: Set<Int>) {
    fun isActive(now: LocalDateTime): Boolean {
        if (!enabled || days.isEmpty()) return false
        val t = now.toLocalTime()
        val today = now.dayOfWeek.value
        val yesterday = now.minusDays(1).dayOfWeek.value
        return if (start <= end) {
            today in days && t >= start && t < end
        } else { // crosses midnight
            (today in days && t >= start) || (yesterday in days && t < end)
        }
    }

    fun toJson(): JSONObject = JSONObject().put("enabled", enabled).put("start", hhmm(start)).put("end", hhmm(end))
        .put("days", JSONArray(days.sorted()))

    companion object {
        private fun hhmm(t: LocalTime) = "%02d:%02d".format(t.hour, t.minute)
        fun fromJson(o: JSONObject): Schedule {
            val d = o.getJSONArray("days")
            return Schedule(o.getBoolean("enabled"), LocalTime.parse(o.getString("start")), LocalTime.parse(o.getString("end")),
                (0 until d.length()).map { d.getInt(it) }.toSet())
        }
    }
}

data class ParentalSettings(
    val dailyLimitMinutes: Int,
    val bedtime: Schedule,
    val studyTime: Schedule,
    val studyAllowedPackages: Set<String>,
    val locationSharingRequested: Boolean,
    val locationIntervalMinutes: Int,
    val appLimits: Map<String, Int>,
    val lowBatteryPercent: Int,
    val enforcementEnabled: Boolean,
    val unpairPinHash: String?,
    val unpairPinSalt: String?,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("dailyLimitMinutes", dailyLimitMinutes)
        .put("bedtime", bedtime.toJson())
        .put("studyTime", studyTime.toJson())
        .put("studyAllowedPackages", JSONArray(studyAllowedPackages.sorted()))
        .put("locationSharingRequested", locationSharingRequested)
        .put("locationIntervalMinutes", locationIntervalMinutes)
        .put("appLimits", JSONObject(appLimits as Map<*, *>))
        .put("lowBatteryPercent", lowBatteryPercent)
        .put("enforcementEnabled", enforcementEnabled)
        .put("unpairPinHash", unpairPinHash ?: JSONObject.NULL)
        .put("unpairPinSalt", unpairPinSalt ?: JSONObject.NULL)

    /** Version shared with the parent / shown to the child: never includes the PIN hash. */
    fun toPublicJson(): JSONObject = toJson().apply {
        remove("unpairPinHash"); remove("unpairPinSalt")
        put("unpairPinSet", unpairPinHash != null)
    }

    companion object {
        val DEFAULT = ParentalSettings(
            dailyLimitMinutes = 180,
            bedtime = Schedule(true, LocalTime.of(21, 30), LocalTime.of(6, 30), (1..7).toSet()),
            studyTime = Schedule(false, LocalTime.of(17, 0), LocalTime.of(19, 0), (1..5).toSet()),
            studyAllowedPackages = emptySet(),
            locationSharingRequested = true,
            locationIntervalMinutes = 15,
            appLimits = emptyMap(),
            lowBatteryPercent = 15,
            enforcementEnabled = true,
            unpairPinHash = null,
            unpairPinSalt = null,
        )

        /** Parses settings that already passed ProtocolRules.validateSettings. */
        fun fromJson(o: JSONObject): ParentalSettings {
            val allowed = o.getJSONArray("studyAllowedPackages")
            val limits = o.getJSONObject("appLimits")
            return ParentalSettings(
                dailyLimitMinutes = o.getInt("dailyLimitMinutes"),
                bedtime = Schedule.fromJson(o.getJSONObject("bedtime")),
                studyTime = Schedule.fromJson(o.getJSONObject("studyTime")),
                studyAllowedPackages = (0 until allowed.length()).map { allowed.getString(it) }.toSet(),
                locationSharingRequested = o.getBoolean("locationSharingRequested"),
                locationIntervalMinutes = o.getInt("locationIntervalMinutes"),
                appLimits = limits.keys().asSequence().associateWith { limits.getInt(it) },
                lowBatteryPercent = o.getInt("lowBatteryPercent"),
                enforcementEnabled = o.getBoolean("enforcementEnabled"),
                unpairPinHash = o.optString("unpairPinHash").takeIf { o.has("unpairPinHash") && !o.isNull("unpairPinHash") && it.isNotEmpty() },
                unpairPinSalt = o.optString("unpairPinSalt").takeIf { o.has("unpairPinSalt") && !o.isNull("unpairPinSalt") && it.isNotEmpty() },
            )
        }

        val DAY_NAMES = DayOfWeek.values().map { it.name.take(3) }
    }
}
