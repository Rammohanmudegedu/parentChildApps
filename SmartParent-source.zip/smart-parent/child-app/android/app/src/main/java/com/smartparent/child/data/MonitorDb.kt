package com.smartparent.child.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.smartparent.child.core.KeyVault
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local SQLite store on the child phone. This is the only place monitoring history lives.
 *  - usage_daily / screen_daily : aggregated per-day usage (app-private storage)
 *  - location                   : each fix sealed with the Keystore-backed KeyVault (encrypted at rest)
 *  - alerts                     : queued for delivery to the parent; delivered when connected
 *  - kv                         : small state flags; secret values go through KeyVault
 */
class MonitorDb(context: Context, private val vault: KeyVault) :
    SQLiteOpenHelper(context, "smartparent.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE usage_daily(day TEXT NOT NULL, pkg TEXT NOT NULL, label TEXT NOT NULL,
            fg_ms INTEGER NOT NULL, launches INTEGER NOT NULL, last_used INTEGER NOT NULL, PRIMARY KEY(day,pkg))""")
        db.execSQL("CREATE TABLE screen_daily(day TEXT PRIMARY KEY, total_ms INTEGER NOT NULL, summary TEXT NOT NULL)")
        db.execSQL("CREATE TABLE location(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, sealed TEXT NOT NULL)")
        db.execSQL("CREATE INDEX location_ts ON location(ts)")
        db.execSQL("""CREATE TABLE alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, kind TEXT NOT NULL,
            title TEXT NOT NULL, detail TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("""CREATE TABLE device_info(id INTEGER PRIMARY KEY CHECK(id=1), device_id TEXT, device_name TEXT,
            android_version TEXT, manufacturer TEXT, model TEXT, battery INTEGER, last_updated INTEGER)""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { /* v1 */ }

    // ---------- usage ----------
    data class AppDay(val pkg: String, val label: String, val fgMs: Long, val launches: Int, val lastUsed: Long)

    @Synchronized fun putUsageDay(day: String, apps: List<AppDay>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("usage_daily", "day=?", arrayOf(day))
            var total = 0L
            for (a in apps) {
                total += a.fgMs
                db.insert("usage_daily", null, ContentValues().apply {
                    put("day", day); put("pkg", a.pkg); put("label", a.label); put("fg_ms", a.fgMs)
                    put("launches", a.launches); put("last_used", a.lastUsed)
                })
            }
            val top = JSONArray()
            apps.sortedByDescending { it.fgMs }.take(5).forEach {
                top.put(JSONObject().put("pkg", it.pkg).put("label", it.label).put("ms", it.fgMs))
            }
            db.insertWithOnConflict("screen_daily", null, ContentValues().apply {
                put("day", day); put("total_ms", total); put("summary", top.toString())
            }, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun hasDay(day: String): Boolean =
        readableDatabase.rawQuery("SELECT 1 FROM screen_daily WHERE day=?", arrayOf(day)).use { it.moveToFirst() }

    fun usageForDay(day: String): List<AppDay> =
        readableDatabase.rawQuery(
            "SELECT pkg,label,fg_ms,launches,last_used FROM usage_daily WHERE day=? ORDER BY fg_ms DESC", arrayOf(day)
        ).use { c ->
            buildList { while (c.moveToNext()) add(AppDay(c.getString(0), c.getString(1), c.getLong(2), c.getInt(3), c.getLong(4))) }
        }

    fun screenDays(fromDay: String): JSONArray = JSONArray().also { arr ->
        readableDatabase.rawQuery("SELECT day,total_ms,summary FROM screen_daily WHERE day>=? ORDER BY day", arrayOf(fromDay)).use { c ->
            while (c.moveToNext()) arr.put(JSONObject().put("date", c.getString(0)).put("totalMs", c.getLong(1)).put("top", JSONArray(c.getString(2))))
        }
    }

    fun appTotalsSince(fromDay: String): JSONArray = JSONArray().also { arr ->
        readableDatabase.rawQuery(
            "SELECT pkg, MAX(label), SUM(fg_ms), SUM(launches), MAX(last_used) FROM usage_daily WHERE day>=? GROUP BY pkg ORDER BY 3 DESC LIMIT 100",
            arrayOf(fromDay)
        ).use { c ->
            while (c.moveToNext()) arr.put(JSONObject().put("pkg", c.getString(0)).put("label", c.getString(1))
                .put("ms", c.getLong(2)).put("launches", c.getInt(3)).put("lastUsed", c.getLong(4)))
        }
    }

    // ---------- device info (spec DeviceInformation) ----------
    fun putDeviceInfo(deviceId: String, name: String, android: String, manufacturer: String, model: String, battery: Int) {
        writableDatabase.insertWithOnConflict("device_info", null, ContentValues().apply {
            put("id", 1); put("device_id", deviceId); put("device_name", name); put("android_version", android)
            put("manufacturer", manufacturer); put("model", model); put("battery", battery); put("last_updated", System.currentTimeMillis())
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ---------- location (encrypted at rest) ----------
    fun addLocation(ts: Long, lat: Double, lon: Double, acc: Float, battery: Int) {
        val sealed = vault.encrypt(JSONObject().put("lat", lat).put("lon", lon).put("acc", acc.toDouble()).put("bat", battery).toString().toByteArray())
        writableDatabase.insert("location", null, ContentValues().apply { put("ts", ts); put("sealed", sealed) })
    }

    fun locationsSince(ts: Long, limit: Int = 500): JSONArray = JSONArray().also { arr ->
        readableDatabase.rawQuery("SELECT ts,sealed FROM location WHERE ts>? ORDER BY ts DESC LIMIT $limit", arrayOf(ts.toString())).use { c ->
            while (c.moveToNext()) {
                try {
                    val o = JSONObject(String(vault.decrypt(c.getString(1))))
                    arr.put(o.put("ts", c.getLong(0)))
                } catch (e: Exception) { /* unreadable row (key reset) – skip */ }
            }
        }
    }

    fun lastLocation(): JSONObject? = locationsSince(0, 1).optJSONObject(0)

    // ---------- alerts ----------
    fun addAlert(kind: String, title: String, detail: String): Long =
        writableDatabase.insert("alerts", null, ContentValues().apply {
            put("ts", System.currentTimeMillis()); put("kind", kind); put("title", title); put("detail", detail)
        })

    fun alertsSince(id: Long, limit: Int = 200): JSONArray = JSONArray().also { arr ->
        readableDatabase.rawQuery("SELECT id,ts,kind,title,detail FROM alerts WHERE id>? ORDER BY id LIMIT $limit", arrayOf(id.toString())).use { c ->
            while (c.moveToNext()) arr.put(alertJson(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4)))
        }
    }

    fun undeliveredAlerts(): JSONArray = JSONArray().also { arr ->
        readableDatabase.rawQuery("SELECT id,ts,kind,title,detail FROM alerts WHERE delivered=0 ORDER BY id LIMIT 200", null).use { c ->
            while (c.moveToNext()) arr.put(alertJson(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4)))
        }
    }

    fun markDelivered(ids: List<Long>) {
        if (ids.isEmpty()) return
        writableDatabase.execSQL("UPDATE alerts SET delivered=1 WHERE id IN (${ids.joinToString(",")})")
    }

    private fun alertJson(id: Long, ts: Long, kind: String, title: String, detail: String) =
        JSONObject().put("id", id).put("ts", ts).put("kind", kind).put("title", title).put("detail", detail)

    // ---------- kv ----------
    fun kvGet(k: String): String? = readableDatabase.rawQuery("SELECT v FROM kv WHERE k=?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else null }
    fun kvPut(k: String, v: String?) {
        if (v == null) writableDatabase.delete("kv", "k=?", arrayOf(k))
        else writableDatabase.insertWithOnConflict("kv", null, ContentValues().apply { put("k", k); put("v", v) }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ---------- retention ----------
    fun prune(now: Long = System.currentTimeMillis()) {
        val day = 86_400_000L
        val db = writableDatabase
        db.delete("location", "ts<?", arrayOf((now - 30 * day).toString()))
        db.delete("alerts", "ts<?", arrayOf((now - 60 * day).toString()))
        val cutoff = java.time.LocalDate.now().minusDays(92).toString()
        db.delete("usage_daily", "day<?", arrayOf(cutoff))
        db.delete("screen_daily", "day<?", arrayOf(cutoff))
    }

    /** Called on unpair: monitoring history is wiped with the pairing. */
    fun wipe() {
        val db = writableDatabase
        for (t in listOf("usage_daily", "screen_daily", "location", "alerts", "kv", "device_info")) db.delete(t, null, null)
    }
}
