package com.smartparent.child.core

// Kotlin twin of shared/sp-crypto.js. Pure JVM (no Android imports) so it can be
// unit-tested on the JVM against shared/test/vectors.json. Keep byte-compatible.

import java.math.BigInteger
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.interfaces.ECPrivateKey
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPrivateKeySpec
import java.security.spec.ECPublicKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object CryptoBox {
    const val PROTOCOL_VERSION = 1
    const val MAX_CLOCK_SKEW_MS = 120_000L
    private val rng = SecureRandom()

    // ---------- encoding ----------
    fun b64u(b: ByteArray): String = Base64.getUrlEncoder().withoutPadding().encodeToString(b)
    fun unb64u(s: String): ByteArray {
        require(Regex("^[A-Za-z0-9_-]*$").matches(s)) { "BAD_B64" }
        return Base64.getUrlDecoder().decode(s)
    }
    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
    fun random(n: Int): ByteArray = ByteArray(n).also { rng.nextBytes(it) }
    fun ctEquals(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)

    // ---------- EC P-256 ----------
    private val params: ECParameterSpec by lazy {
        val ap = AlgorithmParameters.getInstance("EC")
        ap.init(ECGenParameterSpec("secp256r1"))
        ap.getParameterSpec(ECParameterSpec::class.java)
    }

    data class KeyPairB64(val publicKey: String, val privateD: String)

    fun generateKeyPair(): KeyPairB64 {
        val g = KeyPairGenerator.getInstance("EC")
        g.initialize(ECGenParameterSpec("secp256r1"), rng)
        val kp = g.generateKeyPair()
        val pub = kp.public as ECPublicKey
        val priv = kp.private as ECPrivateKey
        return KeyPairB64(b64u(encodePoint(pub.w)), b64u(to32(priv.s)))
    }

    private fun to32(v: BigInteger): ByteArray {
        val raw = v.toByteArray()
        return when {
            raw.size == 32 -> raw
            raw.size > 32 -> raw.copyOfRange(raw.size - 32, raw.size)
            else -> ByteArray(32 - raw.size) + raw
        }
    }

    private fun encodePoint(p: ECPoint): ByteArray = byteArrayOf(0x04) + to32(p.affineX) + to32(p.affineY)

    fun publicFromRaw(b64: String): ECPublicKey {
        val raw = unb64u(b64)
        require(raw.size == 65 && raw[0] == 0x04.toByte()) { "BAD_PUBLIC_KEY" }
        val x = BigInteger(1, raw.copyOfRange(1, 33))
        val y = BigInteger(1, raw.copyOfRange(33, 65))
        return KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(ECPoint(x, y), params)) as ECPublicKey
    }

    fun privateFromD(b64: String): ECPrivateKey =
        KeyFactory.getInstance("EC").generatePrivate(ECPrivateKeySpec(BigInteger(1, unb64u(b64)), params)) as ECPrivateKey

    fun ecdh(privateD: String, peerPublic: String): ByteArray {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(privateFromD(privateD))
        ka.doPhase(publicFromRaw(peerPublic), true)
        return ka.generateSecret() // 32-byte X coordinate, same as WebCrypto deriveBits(256)
    }

    // ---------- HMAC / HKDF ----------
    fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    fun hkdf(ikm: ByteArray, salt: String, info: String, length: Int): ByteArray {
        val prk = hmac(salt.toByteArray(Charsets.UTF_8), ikm)
        val out = java.io.ByteArrayOutputStream()
        var t = ByteArray(0)
        var i = 1
        while (out.size() < length) {
            t = hmac(prk, t + info.toByteArray(Charsets.UTF_8) + byteArrayOf(i.toByte()))
            out.write(t); i++
        }
        return out.toByteArray().copyOf(length)
    }

    // ---------- AES-GCM ----------
    fun aesSeal(key: ByteArray, plain: ByteArray, aad: ByteArray, iv: ByteArray = random(12)): Pair<ByteArray, ByteArray> {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        return iv to c.doFinal(plain)
    }

    fun aesOpen(key: ByteArray, iv: ByteArray, ct: ByteArray, aad: ByteArray): ByteArray = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        c.doFinal(ct)
    } catch (e: Exception) {
        throw SecurityException("DECRYPT_FAILED")
    }

    // ---------- key schedule ----------
    data class PairingKeys(val signalKey: String, val roomId: String, val sas: String)
    data class SessionKeys(val p2c: String, val c2p: String, val sessionId: String)

    fun derivePairingKeys(shared: ByteArray, childPub: String, parentPub: String): PairingKeys {
        val salt = "SmartParent/v1|$childPub|$parentPub"
        val sasRaw = hkdf(shared, salt, "sas", 4)
        val n = ((sasRaw[0].toLong() and 0xff) shl 24) or ((sasRaw[1].toLong() and 0xff) shl 16) or
            ((sasRaw[2].toLong() and 0xff) shl 8) or (sasRaw[3].toLong() and 0xff)
        return PairingKeys(
            signalKey = b64u(hkdf(shared, salt, "signal", 32)),
            roomId = b64u(hkdf(shared, salt, "room", 16)),
            sas = (n % 1_000_000).toString().padStart(6, '0'),
        )
    }

    fun deriveSessionKeys(shared: ByteArray, parentNonce: String, childNonce: String): SessionKeys {
        val salt = "SmartParent/session|$parentNonce|$childNonce"
        return SessionKeys(
            p2c = b64u(hkdf(shared, salt, "p2c", 32)),
            c2p = b64u(hkdf(shared, salt, "c2p", 32)),
            sessionId = b64u(hkdf(shared, salt, "sid", 12)),
        )
    }

    fun pairRequestMac(otp: String, room: String, parentPub: String, childPub: String): String =
        b64u(hmac(unb64u(otp), "pair-req|$room|$parentPub|$childPub".toByteArray(Charsets.UTF_8)))
}

/**
 * Sealed envelope with replay protection. Wire format and AAD identical to SealedChannel in sp-crypto.js:
 *   {"v":1,"s":seq,"ts":epochMs,"iv":b64u,"c":b64u}   AAD = "SP1|label|context|seq|ts"
 * JSON is built by hand to keep this class free of Android's org.json for JVM tests.
 */
class SealedChannel(
    sendKey: String, recvKey: String,
    private val sendLabel: String, private val recvLabel: String,
    private val context: String,
    private val now: () -> Long = { System.currentTimeMillis() },
) {
    private val sKey = CryptoBox.unb64u(sendKey)
    private val rKey = CryptoBox.unb64u(recvKey)
    private var seq = 0L
    private var lastRecv = -1L

    @Synchronized
    fun seal(plaintext: String): String {
        val s = seq++
        val ts = now()
        val aad = "SP1|$sendLabel|$context|$s|$ts".toByteArray(Charsets.UTF_8)
        val (iv, ct) = CryptoBox.aesSeal(sKey, plaintext.toByteArray(Charsets.UTF_8), aad)
        return "{\"v\":1,\"s\":$s,\"ts\":$ts,\"iv\":\"${CryptoBox.b64u(iv)}\",\"c\":\"${CryptoBox.b64u(ct)}\"}"
    }

    @Synchronized
    fun open(wire: String): String {
        val v = num(wire, "v"); val s = num(wire, "s"); val ts = num(wire, "ts")
        val iv = str(wire, "iv"); val c = str(wire, "c")
        if (v != CryptoBox.PROTOCOL_VERSION.toLong() || s == null || ts == null || iv == null || c == null) {
            throw SecurityException("BAD_ENVELOPE")
        }
        if (kotlin.math.abs(now() - ts) > CryptoBox.MAX_CLOCK_SKEW_MS) throw SecurityException("STALE_MESSAGE")
        if (s <= lastRecv) throw SecurityException("REPLAY")
        val aad = "SP1|$recvLabel|$context|$s|$ts".toByteArray(Charsets.UTF_8)
        val pt = CryptoBox.aesOpen(rKey, CryptoBox.unb64u(iv), CryptoBox.unb64u(c), aad)
        lastRecv = s
        return String(pt, Charsets.UTF_8)
    }

    private fun num(j: String, k: String): Long? =
        Regex("\"$k\"\\s*:\\s*(-?\\d+)").find(j)?.groupValues?.get(1)?.toLongOrNull()
    private fun str(j: String, k: String): String? =
        Regex("\"$k\"\\s*:\\s*\"([A-Za-z0-9_-]*)\"").find(j)?.groupValues?.get(1)

    companion object {
        fun signal(signalKey: String, roomId: String, role: String): SealedChannel =
            if (role == "parent") SealedChannel(signalKey, signalKey, "sig-p", "sig-c", roomId)
            else SealedChannel(signalKey, signalKey, "sig-c", "sig-p", roomId)

        fun forChild(k: CryptoBox.SessionKeys) = SealedChannel(k.c2p, k.p2c, "c2p", "p2c", k.sessionId)
        fun forParent(k: CryptoBox.SessionKeys) = SealedChannel(k.p2c, k.c2p, "p2c", "c2p", k.sessionId)
    }
}
