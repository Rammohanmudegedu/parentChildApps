package com.smartparent.child.net

import org.json.JSONObject

/**
 * Validation of inbound parent commands. Mirrors validateCommand/validateSettings in shared/sp-protocol.js.
 * Every command must pass this before the child acts on it; anything unknown is refused.
 */
object ProtocolRules {
    val PARENT_COMMANDS = setOf(
        "DEVICE_STATUS_REQUEST", "SCREEN_TIME_REQUEST", "APP_LIST_REQUEST", "LOCATION_REQUEST",
        "SYNC_REQUEST", "SETTINGS_GET", "SETTINGS_UPDATE", "UNPAIR", "PING",
        "CONTACTS_REQUEST", "GALLERY_LIST_REQUEST", "GALLERY_IMAGE_REQUEST", "SCREEN_START", "SCREEN_STOP",
    )
    private val HHMM = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")
    private val PKG = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
    private val REQ = Regex("^[a-f0-9]{8,64}$")
    private val IMG_ID = Regex("^[0-9]{1,18}$")

    private fun intIn(o: JSONObject, k: String, min: Long, max: Long): Boolean {
        val v = o.opt(k)
        if (v !is Int && v !is Long) return false
        val n = (v as Number).toLong()
        return n in min..max
    }

    private fun schedule(o: JSONObject?): Boolean {
        if (o == null) return false
        if (o.opt("enabled") !is Boolean) return false
        if (!HHMM.matches(o.optString("start")) || !HHMM.matches(o.optString("end"))) return false
        val d = o.optJSONArray("days") ?: return false
        for (i in 0 until d.length()) { val v = d.opt(i); if (v !is Int || v !in 1..7) return false }
        return true
    }

    fun validateSettings(s: JSONObject?): String? {
        if (s == null) return "SETTINGS_OBJECT"
        if (!intIn(s, "dailyLimitMinutes", 0, 1440)) return "DAILY_LIMIT"
        if (!schedule(s.optJSONObject("bedtime"))) return "BEDTIME"
        if (!schedule(s.optJSONObject("studyTime"))) return "STUDY_TIME"
        val allowed = s.optJSONArray("studyAllowedPackages") ?: return "STUDY_ALLOWED"
        if (allowed.length() > 200) return "STUDY_ALLOWED"
        for (i in 0 until allowed.length()) if (!PKG.matches(allowed.optString(i, ""))) return "STUDY_ALLOWED"
        if (s.opt("locationSharingRequested") !is Boolean) return "LOCATION_SHARING"
        if (!intIn(s, "locationIntervalMinutes", 5, 240)) return "LOCATION_INTERVAL"
        val limits = s.optJSONObject("appLimits") ?: return "APP_LIMITS"
        if (limits.length() > 300) return "APP_LIMITS"
        for (k in limits.keys()) if (!PKG.matches(k) || !intIn(limits, k, 0, 1440)) return "APP_LIMIT_ENTRY"
        if (!intIn(s, "lowBatteryPercent", 5, 50)) return "LOW_BATTERY"
        if (s.opt("enforcementEnabled") !is Boolean) return "ENFORCEMENT"
        for (k in listOf("unpairPinHash", "unpairPinSalt")) {
            if (s.has(k) && !s.isNull(k) && s.opt(k) !is String) return "UNPAIR_PIN"
        }
        return null
    }

    fun validateCommand(m: JSONObject): String? {
        val type = m.optString("type")
        if (type !in PARENT_COMMANDS) return "UNKNOWN_TYPE"
        if (!REQ.matches(m.optString("requestId"))) return "REQUEST_ID"
        if (m.optString("timestamp").isEmpty()) return "TIMESTAMP"
        try { java.time.Instant.parse(m.getString("timestamp")) } catch (e: Exception) { return "TIMESTAMP" }
        when (type) {
            "SCREEN_TIME_REQUEST" -> if (!intIn(m, "days", 1, 31)) return "DAYS"
            "SYNC_REQUEST" -> {
                if (m.has("sinceAlertId") && !intIn(m, "sinceAlertId", 0, Long.MAX_VALUE)) return "SINCE_ALERT"
                if (m.has("sinceLocationTs") && !intIn(m, "sinceLocationTs", 0, Long.MAX_VALUE)) return "SINCE_LOCATION"
            }
            "SETTINGS_UPDATE" -> validateSettings(m.optJSONObject("settings"))?.let { return "SETTINGS_$it" }
            "GALLERY_LIST_REQUEST" -> {
                if (m.has("offset") && !intIn(m, "offset", 0, 1_000_000)) return "OFFSET"
                if (m.has("limit") && !intIn(m, "limit", 1, 120)) return "LIMIT"
            }
            "GALLERY_IMAGE_REQUEST" -> if (!IMG_ID.matches(m.optString("id"))) return "IMAGE_ID"
            "SCREEN_START" -> if (m.has("fps") && !intIn(m, "fps", 1, 30)) return "FPS"
        }
        return null
    }
}
