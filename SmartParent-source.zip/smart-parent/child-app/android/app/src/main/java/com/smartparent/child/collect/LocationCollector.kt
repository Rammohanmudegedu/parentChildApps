package com.smartparent.child.collect

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.CurrentLocationRequest
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/**
 * Location via the Fused Location Provider, only while sharing is effectively on:
 * parent requested it AND the child has not paused it AND Android permission is granted.
 * The ongoing notification states that location is being shared whenever this runs.
 */
class LocationCollector(private val ctx: Context, private val onFix: (Location) -> Unit) {
    private val client = LocationServices.getFusedLocationProviderClient(ctx)
    private var running = false
    private var intervalMin = 0

    private val callback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.lastLocation?.let(onFix) }
    }

    fun hasForegroundPermission() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackgroundPermission() =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun isLocationEnabled(): Boolean {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return androidx.core.location.LocationManagerCompat.isLocationEnabled(lm)
    }

    @SuppressLint("MissingPermission")
    fun start(intervalMinutes: Int) {
        if (!hasForegroundPermission()) { stop(); return }
        if (running && intervalMin == intervalMinutes) return
        stop()
        val req = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, intervalMinutes * 60_000L)
            .setMinUpdateIntervalMillis(intervalMinutes * 30_000L)
            .setMinUpdateDistanceMeters(25f)
            .build()
        client.requestLocationUpdates(req, callback, Looper.getMainLooper())
        running = true; intervalMin = intervalMinutes
    }

    fun stop() {
        if (running) client.removeLocationUpdates(callback)
        running = false
    }

    /** One fresh fix for an on-demand parent request. */
    @SuppressLint("MissingPermission")
    fun requestFresh(done: (Location?) -> Unit) {
        if (!hasForegroundPermission()) { done(null); return }
        val req = CurrentLocationRequest.Builder()
            .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
            .setMaxUpdateAgeMillis(60_000)
            .setDurationMillis(20_000)
            .build()
        client.getCurrentLocation(req, null)
            .addOnSuccessListener { loc -> loc?.let(onFix); done(loc) }
            .addOnFailureListener { done(null) }
    }
}
