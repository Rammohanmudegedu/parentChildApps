package com.smartparent.child.net

import android.content.Context
import com.smartparent.child.collect.AppCatalog
import com.smartparent.child.collect.DeviceCollector
import com.smartparent.child.core.ChildRuntime
import com.smartparent.child.core.CryptoBox
import com.smartparent.child.core.Pairing
import com.smartparent.child.core.SealedChannel
import com.smartparent.child.policy.ParentalSettings
import com.smartparent.child.service.Notifier
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.util.concurrent.Executors

/**
 * Owns the child's side of both protocols:
 *
 *  Pairing (QR room, pre-shared one-time token)
 *    parent -> {k:PAIR_REQ, pk, name, mac=HMAC(otp, room|parentPub|childPub)}
 *    child verifies the MAC, derives keys, shows the 6-digit code + parent name on THIS phone
 *    child user taps Allow -> {k:PAIR_OK, box: seal(signalKey, {deviceId, deviceName})}
 *
 *  Session (long-term room derived from the pairing secret; relay sees ciphertext only)
 *    parent -> HELLO{pn}         child -> HELLO_ACK{pn,cn}       (fresh session keys from both nonces)
 *    parent -> OFFER{sdp}        child -> ANSWER{sdp}            ICE both ways
 *    then sealed JSON messages over the "sp" DataChannel, chunked before sealing.
 */
class SyncEngine(private val ctx: Context) {
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "sp-sync").apply { isDaemon = true } }
    private val rt = ChildRuntime

    // ---- connected-mode state ----
    private var signal: SignalingClient? = null
    private var sig: SealedChannel? = null
    private var peer: PeerLink? = null
    private var session: SealedChannel? = null
    private var sessionStartedAt = 0L
    private var parentNonce: String? = null
    private val assembler = ChunkAssembler()

    // ---- pairing state ----
    private data class PendingPair(
        val signalUrl: String, val room: String, val otp: String, val expires: Long,
        val childPriv: String, val childPub: String,
        var parentPub: String? = null, var parentName: String? = null, var keys: CryptoBox.PairingKeys? = null, var shared: ByteArray? = null,
    )
    private var pending: PendingPair? = null
    private var pairSignal: SignalingClient? = null

    fun post(block: () -> Unit) = exec.execute { runCatching(block).onFailure { android.util.Log.w(TAG, "task failed: ${it.javaClass.simpleName}") } }

    // ======================================================================
    // Pairing
    // ======================================================================

    /** Starts a 10-minute pairing window and returns the QR URI. */
    fun startPairing(signalUrl: String, done: (String, Long) -> Unit) = post {
        cancelPairingInternal()
        val kp = CryptoBox.generateKeyPair()
        val room = CryptoBox.b64u(CryptoBox.random(16))
        val otp = CryptoBox.b64u(CryptoBox.random(16))
        val exp = System.currentTimeMillis() + 10 * 60_000
        val p = PendingPair(signalUrl, room, otp, exp, kp.privateD, kp.publicKey)
        pending = p
        val payload = JSONObject().put("v", 1).put("s", signalUrl).put("r", room).put("k", kp.publicKey)
            .put("t", otp).put("e", exp).put("n", DeviceCollector.deviceName(ctx))
        val uri = "smartparent://pair?d=" + CryptoBox.b64u(payload.toString().toByteArray(Charsets.UTF_8))
        pairSignal = SignalingClient(signalUrl, room, object : SignalingClient.Listener {
            override fun onJoined(peerPresent: Boolean) {}
            override fun onPeerJoined() {}
            override fun onPeerLeft() {}
            override fun onDisconnected() {}
            override fun onRelay(data: String) = post { onPairingMessage(data) }
        }).also { it.connect() }
        done(uri, exp)
    }

    private fun onPairingMessage(data: String) {
        val p = pending ?: return
        val m = runCatching { JSONObject(data) }.getOrNull() ?: return
        if (m.optString("k") != "PAIR_REQ") return
        if (System.currentTimeMillis() > p.expires) { pairSignal?.send(JSONObject().put("k", "PAIR_DENY").put("why", "expired").toString()); return }
        if (p.parentPub != null) return // one request per QR code
        val pk = m.optString("pk"); val name = m.optString("name").take(40).ifBlank { "Parent" }
        val expected = CryptoBox.pairRequestMac(p.otp, p.room, pk, p.childPub)
        if (!CryptoBox.ctEquals(expected.toByteArray(), m.optString("mac").toByteArray())) {
            pairSignal?.send(JSONObject().put("k", "PAIR_DENY").put("why", "bad-code").toString()); return
        }
        val shared = try { CryptoBox.ecdh(p.childPriv, pk) } catch (e: Exception) { return }
        p.parentPub = pk; p.parentName = name; p.shared = shared
        p.keys = CryptoBox.derivePairingKeys(shared, p.childPub, pk)
        // Ask the person holding THIS phone. Nothing is shared until they tap Allow.
        rt.emit("pairingRequest", JSONObject().put("parentName", name).put("code", p.keys!!.sas))
        Notifier.pairingRequest(ctx, name, p.keys!!.sas)
    }

    fun respondPairing(approve: Boolean, done: (Boolean) -> Unit) = post {
        val p = pending
        val keys = p?.keys
        if (p == null || keys == null || p.shared == null) { done(false); return@post }
        if (!approve) {
            pairSignal?.send(JSONObject().put("k", "PAIR_DENY").put("why", "declined").toString())
            cancelPairingInternal(); done(false); return@post
        }
        val pairing = Pairing(p.childPriv, p.childPub, p.parentPub!!, p.parentName!!, CryptoBox.b64u(p.shared!!),
            keys.signalKey, keys.roomId, p.signalUrl, System.currentTimeMillis())
        rt.savePairing(pairing)
        rt.setSignalUrl(p.signalUrl)
        if (rt.vault.get("settings") == null) rt.saveSettings(ParentalSettings.DEFAULT)
        val box = SealedChannel.signal(keys.signalKey, p.room, "child")
            .seal(JSONObject().put("deviceId", rt.deviceId()).put("deviceName", DeviceCollector.deviceName(ctx)).toString())
        pairSignal?.send(JSONObject().put("k", "PAIR_OK").put("box", box).toString())
        // give the relay a moment to deliver before leaving the pairing room
        Thread.sleep(800)
        cancelPairingInternal()
        Notifier.cancelPairing(ctx)
        rt.emit("paired", JSONObject().put("parentName", pairing.parentName))
        startInternal()
        done(true)
    }

    fun cancelPairing() = post { cancelPairingInternal() }

    private fun cancelPairingInternal() {
        pairSignal?.close(); pairSignal = null; pending = null
    }

    // ======================================================================
    // Connected mode
    // ======================================================================

    fun start() = post { startInternal() }

    private fun startInternal() {
        val p = rt.pairing() ?: run { rt.updateConnection("unpaired"); return }
        if (signal != null) return
        rt.updateConnection("connecting")
        rt.onAlert = { post { pushPendingAlerts() } }
        signal = SignalingClient(p.signalUrl, p.roomId, object : SignalingClient.Listener {
            override fun onJoined(peerPresent: Boolean) = post { rt.updateConnection("waiting") }
            override fun onPeerJoined() = post { resetSession("parent-rejoined") }
            override fun onPeerLeft() = post { resetSession("parent-left") }
            override fun onDisconnected() = post { if (peer?.isOpen != true) rt.updateConnection("offline") }
            override fun onRelay(data: String) = post { onSignal(data) }
        }).also { it.connect() }
    }

    fun stop() = post { stopInternal() }

    private fun stopInternal() {
        resetSession("stop")
        signal?.close(); signal = null
        rt.updateConnection(if (rt.pairing() == null) "unpaired" else "offline")
    }

    fun networkAvailable() = post { signal?.nudge() }

    private fun resetSession(reason: String) {
        peer?.close(reason); peer = null
        session = null; sig = null; parentNonce = null
        if (signal?.connected == true) rt.updateConnection("waiting")
    }

    private fun onSignal(data: String) {
        val p = rt.pairing() ?: return
        // A new HELLO starts a fresh signaling channel (parent counters restart at 0).
        val ch = sig ?: SealedChannel.signal(p.signalKey, p.roomId, "child").also { sig = it }
        val plain = try { ch.open(data) } catch (e: SecurityException) {
            // Could be a fresh parent connection; retry once with a new channel before rejecting.
            val fresh = SealedChannel.signal(p.signalKey, p.roomId, "child")
            try { fresh.open(data).also { sig = fresh } } catch (e2: SecurityException) { return }
        }
        val m = JSONObject(plain)
        when (m.optString("k")) {
            "HELLO" -> {
                resetSessionKeepSig()
                val pn = m.getString("pn"); val cn = CryptoBox.b64u(CryptoBox.random(16))
                parentNonce = pn
                val keys = CryptoBox.deriveSessionKeys(CryptoBox.unb64u(p.shared), pn, cn)
                session = SealedChannel.forChild(keys)
                sessionStartedAt = System.currentTimeMillis()
                rt.updateConnection("connecting")
                val ice = SignalingClient.fetchIceServers(p.signalUrl, p.roomId)
                peer = PeerLink(ctx, ice, exec, peerEvents)
                sendSignal(JSONObject().put("k", "HELLO_ACK").put("pn", pn).put("cn", cn))
            }
            "OFFER" -> peer?.onRemoteOffer(m.getString("sdp")) { sdp -> sendSignal(JSONObject().put("k", "ANSWER").put("sdp", sdp)) }
            "ICE" -> peer?.onRemoteIce(m.getJSONObject("c"))
            "BYE" -> resetSession("bye")
        }
    }

    private fun resetSessionKeepSig() { peer?.close("new-hello"); peer = null; session = null }

    private fun sendSignal(o: JSONObject) {
        val ch = sig ?: return
        signal?.send(ch.seal(o.toString()))
    }

    private val peerEvents = object : PeerLink.Events {
        override fun onLocalIce(c: JSONObject) = sendSignal(JSONObject().put("k", "ICE").put("c", c))
        override fun onChannelOpen() {
            rt.updateConnection("connected")
            Notifier.updateOngoing(ctx)
            pushPendingAlerts()
        }
        override fun onChannelMessage(text: String) = handleChannel(text)
        override fun onClosed(reason: String) {
            if (peer != null) { peer = null; session = null }
            rt.updateConnection(if (signal?.connected == true) "waiting" else "offline")
            Notifier.updateOngoing(ctx)
        }
    }

    // ---------- secure message layer ----------
    private fun sendMessage(o: JSONObject) {
        val s = session ?: return
        val p = peer ?: return
        for (part in chunk(o.toString())) {
            if (!p.send(s.seal(part))) return
        }
    }

    private fun handleChannel(wire: String) {
        val s = session ?: return
        if (System.currentTimeMillis() - sessionStartedAt > SESSION_MAX_MS) { resetSession("session-expired"); return }
        val plain = try { s.open(wire) } catch (e: SecurityException) {
            android.util.Log.w(TAG, "rejected message: ${e.message}")  // never log contents
            return
        }
        val full: String = try { assembler.push(plain) } catch (e: Exception) { null } ?: return
        val msg = runCatching { JSONObject(full) }.getOrNull() ?: return
        val err = ProtocolRules.validateCommand(msg)
        if (err != null) { sendMessage(reply(msg, "ERROR").put("code", err)); return }
        try { dispatch(msg) } catch (e: Exception) {
            sendMessage(reply(msg, "ERROR").put("code", "INTERNAL"))
        }
        rt.markSynced()
    }

    private fun reply(req: JSONObject, type: String) = JSONObject()
        .put("type", type).put("requestId", req.optString("requestId")).put("timestamp", Instant.now().toString())

    private fun dispatch(m: JSONObject) {
        when (m.getString("type")) {
            "PING" -> sendMessage(reply(m, "PONG"))
            "DEVICE_STATUS_REQUEST" -> sendMessage(reply(m, "DEVICE_STATUS_RESPONSE").put("device", deviceStatus()))
            "SCREEN_TIME_REQUEST" -> {
                rt.refreshUsage(force = true)
                val from = LocalDate.now().minusDays(m.getInt("days").toLong() - 1).toString()
                sendMessage(reply(m, "SCREEN_TIME_RESPONSE")
                    .put("days", rt.db.screenDays(from))
                    .put("apps", rt.db.appTotalsSince(from))
                    .put("today", JSONArray().also { a -> rt.todayRows.forEach { r ->
                        a.put(JSONObject().put("pkg", r.pkg).put("label", r.label).put("ms", r.fgMs).put("launches", r.launches).put("lastUsed", r.lastUsed)) } }))
            }
            "APP_LIST_REQUEST" -> {
                val today = rt.refreshUsage(force = true).associateBy { it.pkg }
                sendMessage(reply(m, "APP_LIST_RESPONSE").put("apps", AppCatalog.listWithUsage(ctx, today, rt.settings().appLimits)))
            }
            "LOCATION_REQUEST" -> {
                if (!rt.locationSharingEffective()) {
                    sendMessage(reply(m, "LOCATION_RESPONSE").put("sharing", false).put("reason", locationOffReason())
                        .put("last", rt.db.lastLocation() ?: JSONObject.NULL))
                } else {
                    rt.location.requestFresh { _ ->
                        post {
                            sendMessage(reply(m, "LOCATION_RESPONSE").put("sharing", true)
                                .put("last", rt.db.lastLocation() ?: JSONObject.NULL)
                                .put("history", rt.db.locationsSince(System.currentTimeMillis() - 86_400_000L, 200))
                                .put("battery", DeviceCollector.battery(ctx).percent))
                        }
                    }
                }
            }
            "SYNC_REQUEST" -> {
                val sinceAlert = m.optLong("sinceAlertId", 0)
                val sinceLoc = m.optLong("sinceLocationTs", 0)
                rt.refreshUsage(force = true)
                val alerts = rt.db.alertsSince(sinceAlert)
                sendMessage(reply(m, "SYNC_RESPONSE")
                    .put("device", deviceStatus())
                    .put("alerts", alerts)
                    .put("locations", if (rt.locationSharingEffective()) rt.db.locationsSince(sinceLoc) else JSONArray())
                    .put("days", rt.db.screenDays(LocalDate.now().minusDays(30).toString()))
                    .put("settings", rt.settings().toPublicJson()))
                val ids = (0 until alerts.length()).map { alerts.getJSONObject(it).getLong("id") }
                rt.db.markDelivered(ids)
            }
            "CONTACTS_REQUEST" -> {
                if (!com.smartparent.child.collect.ContactsCollector.hasPermission(ctx))
                    sendMessage(reply(m, "ERROR").put("code", "PERMISSION_CONTACTS"))
                else
                    sendMessage(reply(m, "CONTACTS_RESPONSE").put("contacts", com.smartparent.child.collect.ContactsCollector.read(ctx)))
            }
            "SETTINGS_GET" -> sendMessage(reply(m, "SETTINGS_RESPONSE").put("settings", rt.settings().toPublicJson()))
            "SETTINGS_UPDATE" -> {
                val incoming = m.getJSONObject("settings")
                val old = rt.settings()
                // Keep the existing unpair PIN unless the parent sends a new one.
                if (!incoming.has("unpairPinHash") || incoming.isNull("unpairPinHash")) {
                    incoming.put("unpairPinHash", old.unpairPinHash ?: JSONObject.NULL)
                    incoming.put("unpairPinSalt", old.unpairPinSalt ?: JSONObject.NULL)
                }
                val s = ParentalSettings.fromJson(incoming)
                rt.saveSettings(s)
                Notifier.settingsChanged(ctx, describeChanges(old, s))
                com.smartparent.child.service.MonitorService.applySettings(ctx)
                sendMessage(reply(m, "SETTINGS_RESPONSE").put("settings", s.toPublicJson()).put("applied", true))
            }
            "UNPAIR" -> {
                sendMessage(reply(m, "SETTINGS_RESPONSE").put("unpaired", true))
                Thread.sleep(300)
                unpairInternal("Your parent removed this phone from Smart Parent.")
            }
        }
    }

    fun unpair(reason: String) = post { unpairInternal(reason) }

    private fun unpairInternal(reason: String) {
        stopInternal()
        rt.savePairing(null)
        rt.vault.remove("settings")
        rt.db.wipe()
        rt.location.stop()
        rt.updateConnection("unpaired")
        Notifier.notice(ctx, "Smart Parent disconnected", reason)
        rt.emit("unpaired", JSONObject().put("reason", reason))
        com.smartparent.child.service.MonitorService.stop(ctx)
    }

    private fun pushPendingAlerts() {
        if (peer?.isOpen != true) return
        val alerts = rt.db.undeliveredAlerts()
        if (alerts.length() == 0) return
        for (i in 0 until alerts.length()) {
            sendMessage(JSONObject().put("type", "ALERT").put("requestId", CryptoBox.hex(CryptoBox.random(8)))
                .put("timestamp", Instant.now().toString()).put("alert", alerts.getJSONObject(i)))
        }
        rt.db.markDelivered((0 until alerts.length()).map { alerts.getJSONObject(it).getLong("id") })
    }

    fun deviceStatus(): JSONObject {
        val snap = DeviceCollector.snapshot(ctx)
        val bat = snap.getJSONObject("battery")
        rt.db.putDeviceInfo(rt.deviceId(), snap.getString("deviceName"), snap.getString("androidVersion"),
            snap.getString("manufacturer"), snap.getString("model"), bat.getInt("percent"))
        val rows = rt.refreshUsage()
        return snap
            .put("deviceId", rt.deviceId())
            .put("screenTimeTodayMs", rows.sumOf { it.fgMs })
            .put("topApps", JSONArray().also { a -> rows.take(5).forEach { a.put(JSONObject().put("pkg", it.pkg).put("label", it.label).put("ms", it.fgMs)) } })
            .put("usageAccess", rt.usage.hasAccess())
            .put("locationSharing", rt.locationSharingEffective())
            .put("locationPausedByChild", rt.locationPaused())
            .put("enforcementActive", rt.accessibilityRunning && rt.settings().enforcementEnabled)
            .put("accessibilityEnabled", rt.accessibilityRunning)
            .put("lastSync", rt.lastSyncAt)
    }

    private fun locationOffReason(): String = when {
        !rt.settings().locationSharingRequested -> "disabled_by_parent"
        rt.locationPaused() -> "paused_by_child"
        !rt.location.hasForegroundPermission() -> "permission_missing"
        else -> "unavailable"
    }

    private fun describeChanges(a: ParentalSettings, b: ParentalSettings): String {
        val out = ArrayList<String>()
        if (a.dailyLimitMinutes != b.dailyLimitMinutes) out += "daily limit ${if (b.dailyLimitMinutes == 0) "off" else com.smartparent.child.policy.PolicyEngine.fmt(b.dailyLimitMinutes)}"
        if (a.bedtime != b.bedtime) out += "bedtime ${if (b.bedtime.enabled) "${b.bedtime.start}–${b.bedtime.end}" else "off"}"
        if (a.studyTime != b.studyTime) out += "study time ${if (b.studyTime.enabled) "${b.studyTime.start}–${b.studyTime.end}" else "off"}"
        if (a.appLimits != b.appLimits) out += "app limits (${b.appLimits.size})"
        if (a.locationSharingRequested != b.locationSharingRequested) out += "location sharing ${if (b.locationSharingRequested) "requested" else "off"}"
        if (a.enforcementEnabled != b.enforcementEnabled) out += "limits ${if (b.enforcementEnabled) "enforced" else "not enforced"}"
        return if (out.isEmpty()) "Settings were reviewed (no changes)." else "Changed: " + out.joinToString(", ")
    }

    // ---------- chunking (mirrors chunkPlaintext / ChunkAssembler in sp-protocol.js) ----------
    private fun chunk(text: String): List<String> {
        if (text.length <= CHUNK) return listOf(text)
        val id = CryptoBox.hex(CryptoBox.random(12))
        val n = (text.length + CHUNK - 1) / CHUNK
        return (0 until n).map { i ->
            JSONObject().put("type", "CHUNK").put("id", id).put("i", i).put("n", n)
                .put("d", text.substring(i * CHUNK, minOf(text.length, (i + 1) * CHUNK))).toString()
        }
    }

    private class ChunkAssembler {
        private val buf = HashMap<String, Array<String?>>()
        fun push(text: String): String? {
            if (!text.contains("\"CHUNK\"")) return text
            val m = JSONObject(text)
            if (m.optString("type") != "CHUNK") return text
            val n = m.getInt("n"); val i = m.getInt("i")
            require(n in 1..512 && i in 0 until n)
            if (buf.size > 8) buf.clear()
            val parts = buf.getOrPut(m.getString("id")) { arrayOfNulls(n) }
            require(parts.size == n)
            parts[i] = m.getString("d")
            if (parts.any { it == null }) return null
            buf.remove(m.getString("id"))
            return parts.joinToString("")
        }
    }

    companion object {
        private const val TAG = "SmartParentSync"
        private const val CHUNK = 48 * 1024
        const val SESSION_MAX_MS = 60 * 60_000L
    }
}
