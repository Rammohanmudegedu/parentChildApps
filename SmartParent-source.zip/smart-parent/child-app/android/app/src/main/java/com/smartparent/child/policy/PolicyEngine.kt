package com.smartparent.child.policy

import android.content.Context
import android.content.Intent
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager
import java.time.LocalDateTime

/**
 * Decides whether opening an app is allowed right now. Pure decision logic; the
 * AccessibilityService only reports which app came to the foreground and shows the block screen.
 * Phone, emergency dialer, launcher, keyboard, Settings and this app are never blocked,
 * so the child can always call for help and can always see/revoke what this app does.
 */
class PolicyEngine(private val ctx: Context) {

    enum class Reason(val title: String) {
        BEDTIME("It's bedtime"),
        STUDY("Study time"),
        DAILY_LIMIT("Daily screen time is used up"),
        APP_LIMIT("Time limit for this app is reached"),
        APP_BLOCKED("This app is paused by your parent"),
    }

    data class Decision(val reason: Reason, val detail: String)

    private var exemptCache: Set<String>? = null
    private var exemptAt = 0L

    fun exempt(): Set<String> {
        val now = System.currentTimeMillis()
        exemptCache?.let { if (now - exemptAt < 300_000) return it }
        val pm = ctx.packageManager
        val set = HashSet<String>()
        set += ctx.packageName
        set += listOf("com.android.systemui", "com.android.settings", "com.android.phone", "com.android.emergency",
            "com.google.android.dialer", "com.android.dialer", "com.android.server.telecom", "com.google.android.permissioncontroller",
            "com.android.permissioncontroller", "android")
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0).forEach { set += it.activityInfo.packageName }
        (ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager)?.defaultDialerPackage?.let { set += it }
        (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.enabledInputMethodList?.forEach { set += it.packageName }
        exemptCache = set; exemptAt = now
        return set
    }

    /**
     * @param todayTotalMs total screen time today
     * @param appTodayMs   foreground time today for [pkg]
     */
    fun decide(pkg: String, s: ParentalSettings, todayTotalMs: Long, appTodayMs: Long, now: LocalDateTime = LocalDateTime.now()): Decision? {
        if (!s.enforcementEnabled || pkg in exempt()) return null
        if (s.bedtime.isActive(now)) return Decision(Reason.BEDTIME, "Apps are paused until ${s.bedtime.end}.")
        if (s.studyTime.isActive(now) && pkg !in s.studyAllowedPackages) return Decision(Reason.STUDY, "Only study apps are available until ${s.studyTime.end}.")
        val appLimit = s.appLimits[pkg]
        if (appLimit != null && appLimit == 0) return Decision(Reason.APP_BLOCKED, "Ask your parent if you need this app.")
        if (s.dailyLimitMinutes > 0 && todayTotalMs >= s.dailyLimitMinutes * 60_000L)
            return Decision(Reason.DAILY_LIMIT, "Today's limit is ${fmt(s.dailyLimitMinutes)}. It resets at midnight.")
        if (appLimit != null && appTodayMs >= appLimit * 60_000L)
            return Decision(Reason.APP_LIMIT, "This app's limit is ${fmt(appLimit)} per day.")
        return null
    }

    companion object {
        fun fmt(min: Int) = if (min >= 60) "${min / 60}h ${min % 60}m" else "${min}m"
    }
}
