package com.smartparent.child.core

import android.content.Context
import com.smartparent.child.collect.LocationCollector
import com.smartparent.child.collect.UsageCollector
import com.smartparent.child.data.MonitorDb
import com.smartparent.child.policy.ParentalSettings
import com.smartparent.child.policy.PolicyEngine
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArraySet

/** Paired-parent record. Stored only inside the KeyVault (encrypted with a Keystore key). */
data class Pairing(
    val childPriv: String, val childPub: String, val parentPub: String, val parentName: String,
    val shared: String, val signalKey: String, val roomId: String, val signalUrl: String, val pairedAt: Long,
) {
    fun toJson(): String = JSONObject().put("childPriv", childPriv).put("childPub", childPub).put("parentPub", parentPub)
        .put("parentName", parentName).put("shared", shared).put("signalKey", signalKey).put("roomId", roomId)
        .put("signalUrl", signalUrl).put("pairedAt", pairedAt).toString()

    companion object {
        fun fromJson(s: String): Pairing = JSONObject(s).let {
            Pairing(it.getString("childPriv"), it.getString("childPub"), it.getString("parentPub"), it.getString("parentName"),
                it.getString("shared"), it.getString("signalKey"), it.getString("roomId"), it.getString("signalUrl"), it.getLong("pairedAt"))
        }
    }
}

/** Process-wide state shared by the foreground service, accessibility service and Capacitor plugin. */
object ChildRuntime {
    lateinit var app: Context; private set
    lateinit var vault: KeyVault; private set
    lateinit var db: MonitorDb; private set
    lateinit var usage: UsageCollector; private set
    lateinit var policy: PolicyEngine; private set
    lateinit var location: LocationCollector; private set

    @Volatile var todayRows: List<MonitorDb.AppDay> = emptyList()
    @Volatile var todayUpdatedAt = 0L
    @Volatile var connection = "unpaired"   // unpaired | offline | waiting | connecting | connected
    @Volatile var lastSyncAt = 0L
    @Volatile var foregroundPkg: String? = null
    @Volatile var accessibilityRunning = false

    private val listeners = CopyOnWriteArraySet<(String, JSONObject) -> Unit>()
    private var initialized = false

    @Synchronized fun init(ctx: Context) {
        if (initialized) return
        app = ctx.applicationContext
        vault = KeyVault(app)
        db = MonitorDb(app, vault)
        usage = UsageCollector(app, db)
        policy = PolicyEngine(app)
        location = LocationCollector(app) { loc ->
            val bat = com.smartparent.child.collect.DeviceCollector.battery(app).percent
            db.addLocation(loc.time, loc.latitude, loc.longitude, loc.accuracy, bat)
            emit("location", JSONObject().put("ts", loc.time))
        }
        lastSyncAt = db.kvGet("last_sync")?.toLongOrNull() ?: 0L
        connection = if (pairing() != null) "offline" else "unpaired"
        initialized = true
    }

    // ---------- identity ----------
    fun deviceId(): String = vault.get("device_id") ?: CryptoBox.b64u(CryptoBox.random(16)).also { vault.put("device_id", it) }

    // ---------- pairing ----------
    fun pairing(): Pairing? = vault.get("pairing")?.let { runCatching { Pairing.fromJson(it) }.getOrNull() }
    fun savePairing(p: Pairing?) { vault.put("pairing", p?.toJson()) }

    fun signalUrl(): String = db.kvGet("signal_url") ?: ""
    fun setSignalUrl(url: String) { db.kvPut("signal_url", url) }

    // ---------- settings ----------
    fun settings(): ParentalSettings = vault.get("settings")?.let {
        runCatching { ParentalSettings.fromJson(JSONObject(it)) }.getOrNull()
    } ?: ParentalSettings.DEFAULT

    fun saveSettings(s: ParentalSettings) { vault.put("settings", s.toJson().toString()); emit("settings", s.toPublicJson()) }

    fun locationPaused(): Boolean = db.kvGet("loc_paused") == "1"
    fun setLocationPaused(p: Boolean) { db.kvPut("loc_paused", if (p) "1" else "0") }

    fun locationSharingEffective(): Boolean =
        pairing() != null && settings().locationSharingRequested && !locationPaused() && location.hasForegroundPermission()

    // ---------- usage cache ----------
    fun refreshUsage(force: Boolean = false): List<MonitorDb.AppDay> {
        val now = System.currentTimeMillis()
        if (force || now - todayUpdatedAt > 30_000) {
            todayRows = runCatching { usage.refresh() }.getOrDefault(todayRows)
            todayUpdatedAt = now
        }
        return todayRows
    }
    fun todayTotalMs() = todayRows.sumOf { it.fgMs }
    fun appTodayMs(pkg: String) = todayRows.firstOrNull { it.pkg == pkg }?.fgMs ?: 0L

    fun markSynced() { lastSyncAt = System.currentTimeMillis(); db.kvPut("last_sync", lastSyncAt.toString()) }

    // ---------- alerts / events ----------
    var onAlert: (() -> Unit)? = null

    /** Records an alert once per [onceKey] (e.g. per day) and asks the sync engine to deliver it. */
    fun alert(kind: String, title: String, detail: String, onceKey: String? = null) {
        if (onceKey != null) {
            if (db.kvGet("once:$onceKey") != null) return
            db.kvPut("once:$onceKey", "1")
        }
        db.addAlert(kind, title, detail)
        onAlert?.invoke()
    }

    fun addListener(l: (String, JSONObject) -> Unit) { listeners += l }
    fun removeListener(l: (String, JSONObject) -> Unit) { listeners -= l }
    fun emit(event: String, data: JSONObject = JSONObject()) { listeners.forEach { runCatching { it(event, data) } } }

    fun setConnection(state: String) {
        if (connection != state) { connection = state; emit("connection", JSONObject().put("state", state)) }
    }
}
