package com.smartparent.child.net

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * WebSocket client for the relay. Joins one room as "child" and reconnects with backoff.
 * Only transports strings; anything sensitive is already sealed by the caller.
 */
class SignalingClient(
    private val url: String,
    private val room: String,
    private val listener: Listener,
) {
    interface Listener {
        fun onJoined(peerPresent: Boolean)
        fun onPeerJoined()
        fun onPeerLeft()
        fun onRelay(data: String)
        fun onDisconnected()
    }

    private val http = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    private var ws: WebSocket? = null
    @Volatile private var closedByUser = false
    @Volatile var connected = false; private set
    private var backoffMs = 2_000L
    private val timer = java.util.Timer("sp-signal", true)

    init {
        // App-level keep-alive every 4 min. Free hosts (e.g. Render) sleep after 15 min without
        // inbound messages; WebSocket control pings may not count, a relay "ping" message does.
        timer.schedule(object : java.util.TimerTask() {
            override fun run() {
                if (connected) ws?.send("{\"t\":\"ping\"}")
            }
        }, KEEPALIVE_MS, KEEPALIVE_MS)
    }

    fun connect() {
        closedByUser = false
        if (ws != null) return
        val req = Request.Builder().url(url).build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                connected = true; backoffMs = 2_000L
                webSocket.send(JSONObject().put("t", "join").put("room", room).put("role", "child").toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                val m = runCatching { JSONObject(text) }.getOrNull() ?: return
                when (m.optString("t")) {
                    "joined" -> listener.onJoined(m.optBoolean("peer"))
                    "peer-joined" -> listener.onPeerJoined()
                    "peer-left" -> listener.onPeerLeft()
                    "relay" -> listener.onRelay(m.optString("d"))
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = dropped(code)
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) = dropped(-1)
        })
    }

    private fun dropped(code: Int) {
        connected = false; ws = null
        listener.onDisconnected()
        if (closedByUser || code == 4009) return // 4009 = replaced by a newer connection from this device
        val delay = backoffMs
        backoffMs = minOf(backoffMs * 2, 60_000L)
        timer.schedule(object : java.util.TimerTask() { override fun run() { if (!closedByUser) connect() } }, delay)
    }

    /** Called when the network comes back: skip the remaining backoff. */
    fun nudge() { backoffMs = 2_000L; if (ws == null && !closedByUser) connect() }

    fun send(data: String): Boolean = ws?.send(JSONObject().put("t", "relay").put("d", data).toString()) ?: false

    fun close() {
        closedByUser = true
        ws?.close(1000, "bye"); ws = null
        timer.cancel()
    }

    companion object {
        private const val KEEPALIVE_MS = 4 * 60_000L

        /** Fetches STUN/TURN servers (with short-lived TURN credentials) from the relay's /ice endpoint. */
        fun fetchIceServers(signalUrl: String, room: String): JSONArray {
            val base = signalUrl.replaceFirst("wss://", "https://").replaceFirst("ws://", "http://").trimEnd('/')
            val fallback = JSONArray().put(JSONObject().put("urls", JSONArray().put("stun:stun.l.google.com:19302")))
            return try {
                OkHttpClient.Builder().callTimeout(8, TimeUnit.SECONDS).build()
                    .newCall(Request.Builder().url("$base/ice?room=$room").build()).execute().use { r ->
                        if (!r.isSuccessful) fallback else JSONObject(r.body!!.string()).getJSONArray("iceServers")
                    }
            } catch (e: Exception) { fallback }
        }
    }
}
