package com.smartparent.child.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypted key/value store for secrets (pairing keys, parental settings, location rows).
 * Values are AES-256-GCM encrypted with a non-exportable key held in the Android Keystore,
 * so they cannot be read from a copied app data folder or a backup.
 */
class KeyVault(context: Context) {
    private val prefs = context.getSharedPreferences("sp_vault", Context.MODE_PRIVATE)
    private val alias = "smartparent_vault_v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(alias, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: ByteArray): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        return CryptoBox.b64u(c.iv + c.doFinal(plain))
    }

    fun decrypt(blob: String): ByteArray {
        val raw = CryptoBox.unb64u(blob)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        return c.doFinal(raw.copyOfRange(12, raw.size))
    }

    @Synchronized fun put(name: String, value: String?) {
        if (value == null) prefs.edit().remove(name).apply()
        else prefs.edit().putString(name, encrypt(value.toByteArray(Charsets.UTF_8))).apply()
    }

    @Synchronized fun get(name: String): String? = prefs.getString(name, null)?.let {
        try { String(decrypt(it), Charsets.UTF_8) } catch (e: Exception) { null }
    }

    @Synchronized fun remove(name: String) { prefs.edit().remove(name).apply() }
}
