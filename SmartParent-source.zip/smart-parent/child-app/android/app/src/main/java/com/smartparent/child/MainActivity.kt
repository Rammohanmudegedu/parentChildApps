package com.smartparent.child

import android.content.Intent
import android.os.Bundle
import com.getcapacitor.BridgeActivity
import com.smartparent.child.plugin.SmartParentPlugin

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(SmartParentPlugin::class.java)
        super.onCreate(savedInstanceState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra("route")?.let { route ->
            bridge?.eval("window.dispatchEvent(new CustomEvent('sp-route',{detail:${org.json.JSONObject.quote(route)}}))") {}
        }
    }
}
