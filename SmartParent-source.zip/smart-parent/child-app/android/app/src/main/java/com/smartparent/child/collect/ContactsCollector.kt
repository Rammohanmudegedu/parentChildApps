package com.smartparent.child.collect

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reads the child's saved contacts (name + phone numbers) via READ_CONTACTS.
 * Transparent: the parent requests it, the child granted the permission, and it is listed on
 * the child's "What my parent can see" screen. No message content is read.
 */
object ContactsCollector {

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    /** One entry per contact with its numbers de-duplicated; capped so a large address book stays sendable. */
    fun read(ctx: Context, limit: Int = 2000): JSONArray {
        val out = JSONArray()
        if (!hasPermission(ctx)) return out
        val names = LinkedHashMap<String, String>()
        val numbers = LinkedHashMap<String, LinkedHashSet<String>>()
        val proj = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
        )
        val sort = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
        try {
            ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null, sort)?.use { c ->
                val idIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (c.moveToNext() && names.size <= limit) {
                    val id = c.getString(idIdx) ?: continue
                    val name = c.getString(nameIdx)?.trim().takeUnless { it.isNullOrEmpty() } ?: "(no name)"
                    val num = c.getString(numIdx)?.trim() ?: continue
                    names.putIfAbsent(id, name)
                    numbers.getOrPut(id) { LinkedHashSet() }.add(num)
                }
            }
        } catch (e: Exception) {
            return out
        }
        for ((id, name) in names) {
            out.put(JSONObject().put("name", name).put("numbers", JSONArray(numbers[id]?.toList() ?: emptyList<String>())))
        }
        return out
    }

    fun count(ctx: Context): Int {
        if (!hasPermission(ctx)) return 0
        return try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts._ID), null, null, null,
            )?.use { it.count } ?: 0
        } catch (e: Exception) { 0 }
    }
}
