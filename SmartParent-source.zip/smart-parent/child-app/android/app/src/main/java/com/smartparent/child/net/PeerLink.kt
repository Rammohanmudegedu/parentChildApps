package com.smartparent.child.net

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.nio.ByteBuffer
import java.util.concurrent.Executor

/**
 * Native WebRTC peer (answerer). The parent creates the offer and the "sp" DataChannel; this side answers.
 * No audio/video tracks are ever created – the DataChannel is the only stream.
 * All callbacks are re-posted onto [exec] (the SyncEngine's single thread).
 */
class PeerLink(
    ctx: Context,
    iceServers: JSONArray,
    private val exec: Executor,
    private val events: Events,
) {
    interface Events {
        fun onLocalIce(c: JSONObject)
        fun onChannelOpen()
        fun onChannelMessage(text: String)
        fun onClosed(reason: String)
    }

    private val pc: PeerConnection
    private var channel: DataChannel? = null
    private var closed = false
    private val pendingRemoteIce = ArrayList<IceCandidate>()
    private var remoteSet = false

    init {
        ensureFactory(ctx)
        val servers = ArrayList<PeerConnection.IceServer>()
        for (i in 0 until iceServers.length()) {
            val s = iceServers.getJSONObject(i)
            val urls = s.opt("urls").let { u -> if (u is JSONArray) (0 until u.length()).map { u.getString(it) } else listOf(u.toString()) }
            val b = PeerConnection.IceServer.builder(urls)
            if (s.has("username")) b.setUsername(s.getString("username")).setPassword(s.getString("credential"))
            servers += b.createIceServer()
        }
        val cfg = PeerConnection.RTCConfiguration(servers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
        }
        pc = factory!!.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED || s == PeerConnection.IceConnectionState.CLOSED) exec.execute { close("ice-$s") }
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate) {
                exec.execute { events.onLocalIce(JSONObject().put("candidate", c.sdp).put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)) }
            }
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(dc: DataChannel) { exec.execute { attach(dc) } }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
        }) ?: throw IllegalStateException("createPeerConnection failed")
    }

    private fun attach(dc: DataChannel) {
        if (dc.label() != "sp") { dc.close(); return }
        channel = dc
        dc.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previous: Long) {}
            override fun onStateChange() {
                val st = dc.state()
                exec.execute {
                    if (st == DataChannel.State.OPEN) events.onChannelOpen()
                    else if (st == DataChannel.State.CLOSED) close("channel-closed")
                }
            }
            override fun onMessage(buffer: DataChannel.Buffer) {
                if (buffer.binary) return
                val bytes = ByteArray(buffer.data.remaining()).also { buffer.data.get(it) }
                val text = String(bytes, Charsets.UTF_8)
                exec.execute { events.onChannelMessage(text) }
            }
        })
        if (dc.state() == DataChannel.State.OPEN) events.onChannelOpen()
    }

    fun onRemoteOffer(sdp: String, sendAnswer: (String) -> Unit) {
        pc.setRemoteDescription(object : SimpleSdp() {
            override fun onSetSuccess() = exec.execute {
                remoteSet = true
                pendingRemoteIce.forEach { pc.addIceCandidate(it) }; pendingRemoteIce.clear()
                pc.createAnswer(object : SimpleSdp() {
                    override fun onCreateSuccess(desc: SessionDescription) = exec.execute {
                        pc.setLocalDescription(object : SimpleSdp() {
                            override fun onSetSuccess() = exec.execute { sendAnswer(desc.description) }
                        }, desc)
                    }
                }, MediaConstraints())
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    fun onRemoteIce(c: JSONObject) {
        val ice = IceCandidate(c.optString("sdpMid"), c.optInt("sdpMLineIndex"), c.getString("candidate"))
        if (remoteSet) pc.addIceCandidate(ice) else pendingRemoteIce += ice
    }

    fun send(text: String): Boolean {
        val ch = channel ?: return false
        if (ch.state() != DataChannel.State.OPEN) return false
        // Back-pressure: don't let the SCTP buffer grow without bound on slow links.
        if (ch.bufferedAmount() > 4L * 1024 * 1024) return false
        return ch.send(DataChannel.Buffer(ByteBuffer.wrap(text.toByteArray(Charsets.UTF_8)), false))
    }

    val isOpen get() = channel?.state() == DataChannel.State.OPEN

    fun close(reason: String) {
        if (closed) return
        closed = true
        runCatching { channel?.unregisterObserver(); channel?.close() }
        runCatching { pc.close(); pc.dispose() }
        events.onClosed(reason)
    }

    private open class SimpleSdp : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }

    companion object {
        @Volatile private var factory: PeerConnectionFactory? = null
        @Synchronized fun ensureFactory(ctx: Context) {
            if (factory != null) return
            PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext).createInitializationOptions())
            factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
        }
    }
}
