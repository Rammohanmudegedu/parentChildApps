package com.smartparent.child.enforce

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.smartparent.child.core.ChildRuntime

/**
 * Enforces time limits, bedtime and study time.
 *
 * Scope is deliberately minimal (see res/xml/accessibility_guard.xml):
 *  - listens ONLY to TYPE_WINDOW_STATE_CHANGED and reads ONLY event.packageName
 *  - canRetrieveWindowContent=false: it cannot read text, messages, passwords or screen content
 *  - performs no gestures/clicks; it only opens Smart Parent's own block screen
 * The child is told this in a prominent disclosure before enabling it, and turning it off is
 * always possible in Settings (the parent then gets an "ENFORCEMENT_DISABLED" alert).
 */
class GuardAccessibilityService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private var lastBlockAt = 0L
    private var lastBlockedPkg: String? = null

    override fun onServiceConnected() {
        ChildRuntime.init(this)
        ChildRuntime.accessibilityRunning = true
        ChildRuntime.emit("accessibility")
        main.postDelayed(recheck, RECHECK_MS)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        ChildRuntime.foregroundPkg = pkg
        evaluateApp(pkg)
    }

    /** Re-checks the current app every 30s so a limit reached *while* using an app takes effect. */
    private val recheck = object : Runnable {
        override fun run() {
            ChildRuntime.foregroundPkg?.let { evaluateApp(it) }
            main.postDelayed(this, RECHECK_MS)
        }
    }

    private fun evaluateApp(pkg: String) {
        val rt = ChildRuntime
        if (rt.pairing() == null || pkg == packageName) return
        rt.refreshUsage() // cached ≤30s
        val d = rt.policy.decide(pkg, rt.settings(), rt.todayTotalMs(), rt.appTodayMs(pkg)) ?: return
        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockAt < 1500) return
        lastBlockAt = now; lastBlockedPkg = pkg
        startActivity(Intent(this, BlockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            .putExtra(BlockActivity.EXTRA_TITLE, d.reason.title)
            .putExtra(BlockActivity.EXTRA_DETAIL, d.detail)
            .putExtra(BlockActivity.EXTRA_APP, rt.usage.label(pkg)))
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        ChildRuntime.accessibilityRunning = false
        ChildRuntime.emit("accessibility")
        main.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ChildRuntime.accessibilityRunning = false
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object { private const val RECHECK_MS = 30_000L }
}
