package com.smartparent.child.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.smartparent.child.MainActivity
import com.smartparent.child.R
import com.smartparent.child.core.ChildRuntime

/**
 * Child-side notifications. The ongoing one is the transparency guarantee: while monitoring runs,
 * it always says what is being shared and opens the Privacy screen.
 */
object Notifier {
    const val CH_MONITOR = "monitor"
    const val CH_NOTICE = "notices"
    const val ID_ONGOING = 1001
    private const val ID_PAIR = 1002
    private const val ID_NOTICE = 1003

    fun channels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MONITOR, "Sharing with parent", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Shown whenever Smart Parent is sharing information with your parent"
            setShowBadge(false)
        })
        nm.createNotificationChannel(NotificationChannel(CH_NOTICE, "Parent changes & limits", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Pairing requests, settings your parent changed, and limits"
        })
    }

    private fun openApp(ctx: Context, route: String): PendingIntent =
        PendingIntent.getActivity(ctx, route.hashCode(),
            Intent(ctx, MainActivity::class.java).putExtra("route", route).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun ongoing(ctx: Context): Notification {
        val rt = ChildRuntime
        val shared = mutableListOf("screen time", "apps", "battery", "device info")
        if (rt.locationSharingEffective()) shared += "location"
        val status = when (rt.connection) {
            "connected" -> "Parent connected now"
            "waiting", "connecting" -> "Ready – parent not viewing"
            else -> "Offline – saved on this phone"
        }
        val parent = rt.pairing()?.parentName ?: "your parent"
        return NotificationCompat.Builder(ctx, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle("Sharing with $parent")
            .setContentText("$status · ${shared.joinToString(", ")}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$status\nShared: ${shared.joinToString(", ")}.\nTap to see exactly what is shared and to pause location."))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openApp(ctx, "privacy"))
            .build()
    }

    fun updateOngoing(ctx: Context) {
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return
        runCatching { NotificationManagerCompat.from(ctx).notify(ID_ONGOING, ongoing(ctx)) }
    }

    fun pairingRequest(ctx: Context, parent: String, code: String) = post(ctx, ID_PAIR,
        NotificationCompat.Builder(ctx, CH_NOTICE).setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle("$parent wants to connect")
            .setContentText("Check the code $code matches their phone, then open the app to allow or deny.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).setContentIntent(openApp(ctx, "connection")).build())

    fun cancelPairing(ctx: Context) = NotificationManagerCompat.from(ctx).cancel(ID_PAIR)

    fun settingsChanged(ctx: Context, what: String) = notice(ctx, "Your parent updated your settings", what, "settings")

    fun notice(ctx: Context, title: String, text: String, route: String = "dashboard") = post(ctx, ID_NOTICE + (title.hashCode() and 0xff),
        NotificationCompat.Builder(ctx, CH_NOTICE).setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true).setContentIntent(openApp(ctx, route)).build())

    private fun post(ctx: Context, id: Int, n: Notification) {
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { /* POST_NOTIFICATIONS not granted */ }
    }
}
