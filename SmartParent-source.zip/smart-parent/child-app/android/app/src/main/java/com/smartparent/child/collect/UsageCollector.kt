package com.smartparent.child.collect

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Process
import com.smartparent.child.data.MonitorDb
import java.time.LocalDate
import java.time.ZoneId

/**
 * Screen-time from UsageStatsManager.queryEvents. Requires the user to grant
 * "Usage access" in Settings (PACKAGE_USAGE_STATS cannot be granted by a dialog).
 *
 * Foreground time is rebuilt from RESUMED/PAUSED events, which is more accurate than
 * queryUsageStats buckets. Android keeps raw events for only a few days, so each day's
 * aggregate is persisted in MonitorDb for weekly/monthly reports.
 */
class UsageCollector(private val ctx: Context, private val db: MonitorDb) {
    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private val pm = ctx.packageManager
    private val zone = ZoneId.systemDefault()
    private val labelCache = HashMap<String, String>()

    fun hasAccess(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (android.os.Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            legacyCheckOp(ops)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    private fun legacyCheckOp(ops: AppOpsManager): Int =
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)

    fun label(pkg: String): String = labelCache.getOrPut(pkg) {
        try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: PackageManager.NameNotFoundException) { pkg }
    }

    private fun launcherPackages(): Set<String> =
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .map { it.activityInfo.packageName }.toSet()

    /** Aggregates one calendar day. Returns per-app rows (excluding launchers and this app). */
    fun computeDay(day: LocalDate, until: Long = System.currentTimeMillis()): List<MonitorDb.AppDay> {
        val start = day.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = minOf(day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(), until)
        if (end <= start) return emptyList()
        val fg = HashMap<String, Long>()
        val launches = HashMap<String, Int>()
        val last = HashMap<String, Long>()
        // Look back 3h so an app already open at midnight is counted from midnight.
        val events = usm.queryEvents(start - 3 * 3_600_000L, end)
        val e = UsageEvents.Event()
        var current: String? = null
        var since = 0L
        fun close(at: Long) {
            val c = current ?: return
            val from = maxOf(since, start)
            if (at > from) fg[c] = (fg[c] ?: 0L) + (at - from)
            last[c] = maxOf(last[c] ?: 0L, at)
            current = null
        }
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val ts = e.timeStamp
            when (e.eventType) {
                EV_RESUMED -> {
                    val p = e.packageName
                    if (current != p) {
                        close(ts)
                        current = p; since = ts
                        if (ts >= start) launches[p] = (launches[p] ?: 0) + 1
                    }
                    if (ts >= start) last[p] = maxOf(last[p] ?: 0L, ts)
                }
                EV_PAUSED, EV_STOPPED -> if (current == e.packageName) close(ts)
                EV_SCREEN_OFF, EV_SHUTDOWN -> close(ts)
            }
        }
        if (current != null) close(end)
        val skip = launcherPackages() + ctx.packageName + "com.android.systemui"
        return fg.filterKeys { it !in skip }.filterValues { it >= 1000 }.map { (pkg, ms) ->
            MonitorDb.AppDay(pkg, label(pkg), ms, launches[pkg] ?: 0, last[pkg] ?: 0L)
        }.sortedByDescending { it.fgMs }
    }

    /** Refresh today (and yesterday until it is final). Backfills missing recent days once. */
    fun refresh(): List<MonitorDb.AppDay> {
        if (!hasAccess()) return emptyList()
        val today = LocalDate.now(zone)
        for (back in 7 downTo 2) {
            val d = today.minusDays(back.toLong())
            if (!db.hasDay(d.toString())) db.putUsageDay(d.toString(), computeDay(d))
        }
        db.putUsageDay(today.minusDays(1).toString(), computeDay(today.minusDays(1)))
        val rows = computeDay(today)
        db.putUsageDay(today.toString(), rows)
        return rows
    }

    companion object {
        // Raw values so minSdk 26 works (named constants for some were added in API 28/29; values are stable).
        private const val EV_RESUMED = 1     // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
        private const val EV_PAUSED = 2      // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
        private const val EV_SCREEN_OFF = 16 // SCREEN_NON_INTERACTIVE
        private const val EV_STOPPED = 23    // ACTIVITY_STOPPED
        private const val EV_SHUTDOWN = 26   // DEVICE_SHUTDOWN
    }

    fun todayTotalMs(rows: List<MonitorDb.AppDay>) = rows.sumOf { it.fgMs }
}
