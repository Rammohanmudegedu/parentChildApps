package com.smartparent.child.collect

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Launchable apps (what the child can actually open). Uses an intent query for MAIN/LAUNCHER,
 * which is visible under Android 11 package-visibility rules via the <queries> element in the
 * manifest – no QUERY_ALL_PACKAGES needed.
 */
object AppCatalog {
    private val iconCache = HashMap<String, String>()

    fun launchable(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != ctx.packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    fun iconPngBase64(ctx: Context, pkg: String, sizePx: Int = 64): String? = iconCache.getOrPut(pkg) {
        try {
            val d = ctx.packageManager.getApplicationIcon(pkg)
            val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            d.setBounds(0, 0, sizePx, sizePx); d.draw(c)
            val out = ByteArrayOutputStream()
            @Suppress("DEPRECATION")
            bmp.compress(if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP, 80, out)
            "data:image/webp;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) { return null }
    }

    fun isSystem(ctx: Context, pkg: String): Boolean = try {
        (ctx.packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
    } catch (e: Exception) { false }

    fun installTime(ctx: Context, pkg: String): Long = try {
        ctx.packageManager.getPackageInfo(pkg, 0).firstInstallTime
    } catch (e: Exception) { 0L }

    /** Full list with today's usage merged in. Large (icons) – the channel chunks it. */
    fun listWithUsage(ctx: Context, today: Map<String, com.smartparent.child.data.MonitorDb.AppDay>, limits: Map<String, Int>): JSONArray {
        val arr = JSONArray()
        for ((pkg, label) in launchable(ctx)) {
            val u = today[pkg]
            arr.put(JSONObject()
                .put("pkg", pkg).put("label", label)
                .put("icon", iconPngBase64(ctx, pkg) ?: JSONObject.NULL)
                .put("system", isSystem(ctx, pkg))
                .put("installedAt", installTime(ctx, pkg))
                .put("todayMs", u?.fgMs ?: 0L)
                .put("launches", u?.launches ?: 0)
                .put("lastUsed", u?.lastUsed ?: 0L)
                .put("limitMinutes", limits[pkg] ?: JSONObject.NULL))
        }
        return arr
    }
}
