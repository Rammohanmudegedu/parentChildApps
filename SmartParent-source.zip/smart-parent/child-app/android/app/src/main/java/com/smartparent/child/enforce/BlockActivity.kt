package com.smartparent.child.enforce

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import com.smartparent.child.MainActivity

/** Friendly full-screen pause screen. Always offers Home, Phone (emergency) and "See my limits". */
class BlockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Paused"
        val detail = intent.getStringExtra(EXTRA_DETAIL) ?: ""
        val app = intent.getStringExtra(EXTRA_APP) ?: "This app"
        fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#1A56DB"), Color.parseColor("#0B2A6F")))
        }
        root.addView(TextView(this).apply {
            text = "⏸"; textSize = 56f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = title; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(6))
        })
        root.addView(TextView(this).apply {
            text = "$app is paused.\n$detail"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#DCE6FF"))
            setPadding(0, 0, 0, dp(24))
        })
        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 16f
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        root.addView(button("Go to Home screen") { goHome() })
        root.addView(button("Phone (calls are always allowed)") {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); finish()
        })
        root.addView(button("See my limits") {
            startActivity(Intent(this, MainActivity::class.java).putExtra("route", "screentime").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); finish()
        })
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() = goHome() })
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_DETAIL = "detail"
        const val EXTRA_APP = "app"
    }
}
