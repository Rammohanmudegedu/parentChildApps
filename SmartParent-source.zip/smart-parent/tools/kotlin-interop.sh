#!/usr/bin/env bash
# Cross-language crypto check: compiles the child's CryptoBox.kt on the plain JVM (via Gradle's
# embedded Kotlin, no Android SDK needed) and verifies it against vectors produced by sp-crypto.js.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d)"
SRC="$ROOT/child-app/android/app/src/main/java/com/smartparent/child/core/CryptoBox.kt"
node "$ROOT/shared/test/gen-vectors.mjs" > "$WORK/vectors.json"
{ grep '^import ' "$SRC"; grep -v -e '^import ' -e '^package ' "$SRC"; cat "$ROOT/tools/interop-checks.kts.txt"; } > "$WORK/build.gradle.kts"
echo 'rootProject.name="interop"' > "$WORK/settings.gradle.kts"
(cd "$WORK" && gradle -q --offline interop -Dvectors="$WORK/vectors.json")
node "$ROOT/tools/interop-reverse.mjs" "$WORK/vectors.json" "$WORK/kotlin-out.json"
rm -rf "$WORK"
