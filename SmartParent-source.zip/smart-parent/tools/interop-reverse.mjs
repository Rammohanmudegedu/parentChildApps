// Second half of the interop check: JS must open what Kotlin sealed, and accept Kotlin public keys.
import fs from 'node:fs';
import * as C from '../shared/sp-crypto.js';
const v = JSON.parse(fs.readFileSync(process.argv[2]));
const k = JSON.parse(fs.readFileSync(process.argv[3]));
const ok1 = (await C.sessionChannel(v.session, 'parent').open(k.sealed)) === 'from kotlin';
const s = await C.ecdhSharedSecret((await C.generateKeyPair()).privateJwk, k.childPub);
console.log(ok1 ? 'PASS JS opens Kotlin envelope' : 'FAIL JS opens Kotlin envelope');
console.log(s.length === 32 ? 'PASS JS ECDH with Kotlin public key' : 'FAIL JS ECDH with Kotlin public key');
if (!ok1 || s.length !== 32) process.exit(1);
