"""
End-to-end test of the REAL parent app (parent-app/www) against the real signaling server,
with the child side played by tools/e2e/child-sim.html (protocol twin of SyncEngine.kt).

Covers: QR-link pairing + matching 6-digit codes, sealed signaling, WebRTC DataChannel,
SYNC, chunked APP_LIST, screen time, location, device info, settings update with validation,
live ALERT push, encrypted IndexedDB cache (no plaintext secrets), every parent screen rendering.

Run: python3 tools/e2e/run_e2e.py   (needs: node, python playwright + chromium)
"""
import os, subprocess, sys, time, json, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parents[2]
SIG_PORT, WEB_PORT = 8787, 8790
SIGNAL = f"ws://127.0.0.1:{SIG_PORT}"
WEB = f"http://127.0.0.1:{WEB_PORT}"
SHOTS = pathlib.Path(os.environ.get("E2E_SHOTS", ROOT / "tools/e2e/screenshots"))
SHOTS.mkdir(parents=True, exist_ok=True)

passed, failed = [], []
def check(name, cond, detail=""):
    (passed if cond else failed).append(name)
    print(("PASS " if cond else "FAIL ") + name + (f"  ({detail})" if detail and not cond else ""))

procs = [
    subprocess.Popen(["node", str(ROOT / "signaling-server/server.js")], env={**os.environ, "PORT": str(SIG_PORT)}, stdout=subprocess.DEVNULL),
    subprocess.Popen(["node", str(ROOT / "tools/e2e/static-server.mjs"), str(ROOT), str(WEB_PORT)], stdout=subprocess.DEVNULL),
]
time.sleep(1.2)
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--disable-features=WebRtcHideLocalIpsWithMdns"])
        child = browser.new_page()
        console_errors = []
        child.on("console", lambda m: print("  [child]", m.text) if "rejected" in m.text or "dropped" in m.text else None)
        child.goto(f"{WEB}/tools/e2e/child-sim.html?signal={SIGNAL}")
        child.wait_for_function("window.pairUri", timeout=10000)
        uri = child.evaluate("window.pairUri")

        ctx = browser.new_context(viewport={"width": 412, "height": 915}, device_scale_factor=2)
        parent = ctx.new_page()
        parent.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
        parent.on("pageerror", lambda e: console_errors.append(str(e)))
        parent.goto(f"{WEB}/parent-app/www/index.html#dashboard")
        parent.wait_for_selector("text=Add your child's phone", timeout=10000)
        parent.screenshot(path=str(SHOTS / "00-empty.png"))
        check("parent app boots with no child", True)

        # ---- pairing ----
        parent.goto(f"{WEB}/parent-app/www/index.html#pair")
        parent.fill("#pname", "Ram")
        parent.fill("#kname", "Anu")
        parent.click("summary")
        parent.fill("#link", uri)
        parent.click("#usel")
        parent.wait_for_selector(".code-digits", timeout=10000)
        parent_code = parent.inner_text(".code-digits").strip()
        child.wait_for_function("window.sas", timeout=10000)
        child_code = child.evaluate("window.sas")
        check("both phones show the same 6-digit code", parent_code == child_code and len(parent_code) == 6, f"{parent_code} vs {child_code}")
        check("child sees parent's name", child.evaluate("window.parentName") == "Ram")
        parent.screenshot(path=str(SHOTS / "01-pair-code.png"))
        child.evaluate("window.approve()")
        parent.wait_for_url('**#dashboard', timeout=10000)
        check("pairing completes after child approval", True)

        # ---- live connection + sync ----
        child.wait_for_function("window.linkOpen === true", timeout=20000)
        check("WebRTC DataChannel opened", True)
        parent.wait_for_selector("text=Online", timeout=20000)
        parent.wait_for_selector(".sp-hero .big:has-text('3h 19m')", timeout=15000)
        check("dashboard shows synced screen time", True)
        types = [c["type"] for c in child.evaluate("window.received")]
        check("parent sent SYNC_REQUEST", "SYNC_REQUEST" in types, str(types))
        parent.wait_for_timeout(600)
        parent.screenshot(path=str(SHOTS / "02-dashboard.png"), full_page=True)
        check("dashboard shows battery", parent.locator(".sp-stat .val", has_text="63%").count() == 1)
        check("dashboard shows live badge", parent.locator(".pill-live").count() >= 1)

        # ---- screens ----
        def visit(route, wait, shot, label):
            parent.goto(f"{WEB}/parent-app/www/index.html#{route}")
            try:
                parent.wait_for_selector(wait, timeout=15000)
                parent.wait_for_timeout(700)
                parent.screenshot(path=str(SHOTS / shot), full_page=True)
                check(label, True)
            except Exception as e:
                parent.screenshot(path=str(SHOTS / shot), full_page=True)
                check(label, False, str(e)[:200])

        parent.wait_for_selector("text=Online", timeout=15000)
        visit("screentime", "#appsChart", "03-screen-time.png", "screen time view renders charts")
        visit("apps", "text=Example App 79", "04-apps.png", "chunked 80-app list (~150 KB) received")
        visit("location", ".leaflet-container", "05-location.png", "location view renders map")
        visit("device", "text=SM-A146B", "06-device.png", "device information view")
        visit("reports", "#monthChart", "07-reports.png", "reports view")
        visit("controls", "#ctl", "08-controls.png", "parental controls form")

        # ---- settings round-trip ----
        parent.evaluate("document.querySelector('#dl').value = 120; document.querySelector('#dl').dispatchEvent(new Event('input'))")
        parent.fill("#upin", "4321")
        parent.click("#ctl button[type=submit]")
        child.wait_for_function("window.lastSettings && window.lastSettings.dailyLimitMinutes === 120", timeout=15000)
        s = child.evaluate("window.lastSettings")
        check("SETTINGS_UPDATE delivered and validated", s["dailyLimitMinutes"] == 120)
        check("unpair PIN sent only as PBKDF2 hash", bool(s.get("unpairPinHash")) and "4321" not in json.dumps(s))

        # ---- per-app limit from Applications ----
        visit("apps", "text=YouTube", "04b-apps.png", "apps view after settings")
        try:
            parent.locator("li:has-text('YouTube') [data-limit]").first.click(timeout=15000)
        except Exception:
            parent.screenshot(path=str(SHOTS / "debug-apps.png"), full_page=True)
            print(parent.inner_text("#view")[:600]); raise
        parent.wait_for_selector(".modal.show")
        parent.check("input[name=lm][value=pause]")
        parent.click(".modal.show [data-r='1']")
        child.wait_for_function("window.lastSettings.appLimits['com.google.android.youtube'] === 0", timeout=15000)
        check("app pause limit delivered", True)

        # ---- live alert push ----
        parent.goto(f"{WEB}/parent-app/www/index.html#dashboard")
        parent.wait_for_selector("text=Online", timeout=15000)
        child.evaluate("window.pushAlert({id: 2, ts: Date.now(), kind: 'DAILY_LIMIT_REACHED', title: 'Daily screen-time limit reached', detail: 'Used 2h 0m today (limit 2h 0m).'})")
        parent.wait_for_selector(".sp-list >> text=Daily screen-time limit reached", timeout=10000)
        check("live ALERT shown on parent", True)

        # ---- encrypted storage ----
        raw = parent.evaluate("""() => new Promise(r => { const q = indexedDB.open('smartparent-parent'); q.onsuccess = () => {
            const t = q.result.transaction('records'); const all = t.objectStore('records').getAll(); all.onsuccess = () => r(JSON.stringify(all.result)); }; })""")
        check("IndexedDB holds only sealed records", '"iv"' in raw and "Test Child Phone" not in raw and "signalKey" not in raw and "SM-A146B" not in raw)

        # ---- dark theme ----
        parent.evaluate("localStorage.setItem('sp.theme','dark')")
        parent.reload()  # full reload: re-opens encrypted store and reconnects via the long-term room
        parent.wait_for_selector("text=Online", timeout=20000)
        parent.wait_for_selector(".sp-hero .big:has-text('3h 19m')", timeout=15000)
        parent.wait_for_timeout(800)
        parent.screenshot(path=str(SHOTS / "09-dashboard-dark.png"), full_page=True)
        check("dark theme renders", parent.evaluate("document.documentElement.dataset.bsTheme") == "dark")

        # ---- reconnect after reload uses the long-term room (no re-pairing) ----
        check("reload reconnected without re-pairing", parent.locator("text=Online").count() >= 1)

        # ---- child app UI in browser preview (no native layer) ----
        cpage = ctx.new_page()
        cpage.on("pageerror", lambda e: console_errors.append("child-ui: " + str(e)))
        cpage.goto(f"{WEB}/child-app/www/index.html#privacy")
        cpage.wait_for_selector("text=Browser preview", timeout=10000)
        cpage.screenshot(path=str(SHOTS / "10-child-preview.png"), full_page=True)
        check("child UI shows honest preview state outside Android", True)

        relevant = [e for e in console_errors if "tile.openstreetmap" not in e and "ERR_NAME_NOT_RESOLVED" not in e and "Failed to load resource" not in e]
        check("no JS errors in parent/child UI", not relevant, "; ".join(relevant)[:400])
        browser.close()
finally:
    for pr in procs: pr.terminate()

print(f"\n{len(passed)} passed, {len(failed)} failed")
sys.exit(1 if failed else 0)
