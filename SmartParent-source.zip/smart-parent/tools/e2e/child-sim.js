// TEST HARNESS ONLY – not shipped in any app.
// A browser implementation of the child's protocol (mirrors net/SyncEngine.kt) so the real parent
// app can be exercised end-to-end (relay + pairing + WebRTC + sealed protocol) in a headless browser.
// All device values below are fixed test fixtures.
import * as C from '../../shared/sp-crypto.js';
import { validateCommand, defaultSettings, chunkPlaintext, ChunkAssembler } from '../../shared/sp-protocol.js';

const params = new URLSearchParams(location.search);
const SIGNAL = params.get('signal');
const log = (...a) => { console.log('[child-sim]', ...a); document.getElementById('log').textContent += a.join(' ') + '\n'; };
window.received = [];
let settings = defaultSettings();
const alerts = [{ id: 1, ts: Date.now() - 3600_000, kind: 'BATTERY_LOW', title: 'Battery low', detail: 'Battery at 14%.' }];

function ws(room, onMsg) {
  const s = new WebSocket(SIGNAL);
  s.onopen = () => s.send(JSON.stringify({ t: 'join', room, role: 'child' }));
  s.onmessage = (e) => onMsg(JSON.parse(e.data));
  return s;
}

// ---------------- pairing ----------------
const kp = await C.generateKeyPair();
const pairRoom = C.b64u(C.randomBytes(16));
const otp = C.b64u(C.randomBytes(16));
const payload = { v: 1, s: SIGNAL, r: pairRoom, k: kp.publicKey, t: otp, e: Date.now() + 600_000, n: 'Test Child Phone' };
window.pairUri = 'smartparent://pair?d=' + C.b64u(C.utf8(JSON.stringify(payload)));
let pairing = null;
let pend = null;
const ps = ws(pairRoom, async (m) => {
  if (m.t !== 'relay') return;
  const r = JSON.parse(m.d);
  if (r.k !== 'PAIR_REQ') return;
  const expect = await C.pairRequestMac(otp, pairRoom, r.pk, kp.publicKey);
  if (expect !== r.mac) { ps.send(JSON.stringify({ t: 'relay', d: JSON.stringify({ k: 'PAIR_DENY', why: 'bad-code' }) })); return; }
  const shared = await C.ecdhSharedSecret(kp.privateJwk, r.pk);
  const keys = await C.derivePairingKeys(shared, kp.publicKey, r.pk);
  pend = { shared, keys, parentName: r.name };
  window.sas = keys.sas; window.parentName = r.name;
  log('pair request from', r.name, 'code', keys.sas);
});
window.approve = async () => {
  const box = await C.signalChannel(pend.keys.signalKey, pairRoom, 'child').seal(JSON.stringify({ deviceId: 'sim-device-0001', deviceName: 'Test Child Phone' }));
  ps.send(JSON.stringify({ t: 'relay', d: JSON.stringify({ k: 'PAIR_OK', box }) }));
  pairing = { shared: pend.shared, ...pend.keys };
  setTimeout(() => { ps.close(); connected(); }, 500);
  window.paired = true;
};

// ---------------- connected mode ----------------
function connected() {
  let sig = null; let session = null; let pc = null; let dc = null; const asm = new ChunkAssembler();
  const s = ws(pairing.roomId, async (m) => {
    if (m.t === 'peer-joined') { sig = null; }
    if (m.t !== 'relay') return;
    let plain;
    const tryOpen = async (ch) => { try { return await ch.open(m.d); } catch { return null; } };
    if (sig) plain = await tryOpen(sig);
    if (plain == null) { const f = C.signalChannel(pairing.signalKey, pairing.roomId, 'child'); plain = await tryOpen(f); if (plain != null) sig = f; }
    if (plain == null) { log('dropped signal'); return; }
    const msg = JSON.parse(plain);
    const send = async (o) => s.send(JSON.stringify({ t: 'relay', d: await sig.seal(JSON.stringify(o)) }));
    if (msg.k === 'HELLO') {
      const cn = C.b64u(C.randomBytes(16));
      session = C.sessionChannel(await C.deriveSessionKeys(pairing.shared, msg.pn, cn), 'child');
      const ice = await fetch(SIGNAL.replace('ws:', 'http:') + '/ice?room=' + pairing.roomId).then((r) => r.json());
      pc = new RTCPeerConnection({ iceServers: ice.iceServers.filter((x) => !String(x.urls).includes('stun:stun')) });
      pc.onicecandidate = (e) => { if (e.candidate) send({ k: 'ICE', c: { candidate: e.candidate.candidate, sdpMid: e.candidate.sdpMid, sdpMLineIndex: e.candidate.sdpMLineIndex } }); };
      pc.ondatachannel = (e) => {
        dc = e.channel;
        dc.onopen = () => { log('datachannel open'); window.linkOpen = true; };
        dc.onmessage = async (ev) => {
          let p; try { p = await session.open(ev.data); } catch (err) { log('rejected', err.message); return; }
          const full = asm.push(p); if (full == null) return;
          const cmd = JSON.parse(full);
          window.received.push(cmd);
          const err = validateCommand(cmd);
          const reply = async (type, body) => { for (const part of chunkPlaintext(JSON.stringify({ type, requestId: cmd.requestId, timestamp: new Date().toISOString(), ...body }))) dc.send(await session.seal(part)); };
          if (err) return reply('ERROR', { code: err });
          await respond(cmd, reply);
        };
      };
      await send({ k: 'HELLO_ACK', pn: msg.pn, cn });
    } else if (msg.k === 'OFFER') {
      await pc.setRemoteDescription({ type: 'offer', sdp: msg.sdp });
      const ans = await pc.createAnswer(); await pc.setLocalDescription(ans);
      await send({ k: 'ANSWER', sdp: ans.sdp });
    } else if (msg.k === 'ICE') { await pc?.addIceCandidate(msg.c).catch(() => {}); }
  });
  window.pushAlert = async (a) => {
    alerts.push(a);
    const part = JSON.stringify({ type: 'ALERT', requestId: 'abcdef012345', timestamp: new Date().toISOString(), alert: a });
    dc.send(await session.seal(part));
  };
}

// fixture data
const day = (n) => new Date(Date.now() - n * 86400000).toLocaleDateString('en-CA');
const APPS = [['com.google.android.youtube', 'YouTube', 74], ['com.whatsapp', 'WhatsApp', 41], ['org.khanacademy.android', 'Khan Academy', 33], ['com.android.chrome', 'Chrome', 22], ['com.spotify.music', 'Spotify', 15], ['com.mojang.minecraftpe', 'Minecraft', 12], ['com.google.android.calculator', 'Calculator', 2]];
const today = APPS.map(([pkg, label, m], i) => ({ pkg, label, ms: m * 60000, launches: 3 + i, lastUsed: Date.now() - i * 900000 }));
const days = Array.from({ length: 30 }, (_, i) => ({ date: day(29 - i), totalMs: (i === 29 ? 199 : 120 + ((i * 37) % 110)) * 60000, top: today.slice(0, 3).map((a) => ({ pkg: a.pkg, label: a.label, ms: a.ms })) }));
const device = () => ({
  deviceName: 'Test Child Phone', manufacturer: 'samsung', model: 'SM-A146B', androidVersion: '14', sdk: 34,
  battery: { percent: 63, charging: false, plugged: 'none', health: 'good', temperatureC: 31.4, voltageMv: 3912 },
  storage: { totalBytes: 64e9, freeBytes: 21.5e9 }, ram: { totalBytes: 4e9, availBytes: 1.6e9, lowMemory: false },
  network: { type: 'wifi', internet: true, metered: false }, ts: Date.now(), deviceId: 'sim-device-0001',
  screenTimeTodayMs: 199 * 60000, topApps: today.slice(0, 5).map((a) => ({ pkg: a.pkg, label: a.label, ms: a.ms })),
  usageAccess: true, locationSharing: true, locationPausedByChild: false, enforcementActive: true, accessibilityEnabled: true, lastSync: Date.now(),
});
const loc = { lat: 17.385, lon: 78.4867, acc: 18, bat: 63, ts: Date.now() - 120000 };
const pub = () => { const s = structuredClone(settings); delete s.unpairPinHash; delete s.unpairPinSalt; s.unpairPinSet = !!settings.unpairPinHash; return s; };

async function respond(cmd, reply) {
  switch (cmd.type) {
    case 'PING': return reply('PONG', {});
    case 'DEVICE_STATUS_REQUEST': return reply('DEVICE_STATUS_RESPONSE', { device: device() });
    case 'SYNC_REQUEST': return reply('SYNC_RESPONSE', { device: device(), alerts: alerts.filter((a) => a.id > (cmd.sinceAlertId || 0)), locations: [loc], days, settings: pub() });
    case 'SCREEN_TIME_REQUEST': return reply('SCREEN_TIME_RESPONSE', { days: days.slice(-cmd.days), apps: today.map((a) => ({ ...a, ms: a.ms * 18 })), today });
    case 'APP_LIST_REQUEST': {
      // ~150 KB of icons to exercise chunking
      const icon = 'data:image/webp;base64,' + 'A'.repeat(1800);
      const apps = Array.from({ length: 80 }, (_, i) => { const t = today[i % today.length]; return { pkg: i < today.length ? t.pkg : `com.example.app${i}`, label: i < today.length ? t.label : `Example App ${i}`, icon, system: false, installedAt: 0, todayMs: i < today.length ? t.ms : 0, launches: i < today.length ? t.launches : 0, lastUsed: i < today.length ? t.lastUsed : 0, limitMinutes: settings.appLimits[t.pkg] ?? null }; });
      return reply('APP_LIST_RESPONSE', { apps });
    }
    case 'LOCATION_REQUEST': return reply('LOCATION_RESPONSE', { sharing: true, last: loc, history: [loc, { ...loc, lat: 17.39, lon: 78.48, ts: loc.ts - 1800000 }], battery: 63 });
    case 'CONTACTS_REQUEST': return reply('CONTACTS_RESPONSE', { contacts: [
      { name: 'Amma', numbers: ['+91 90000 11111'] },
      { name: 'Class Teacher', numbers: ['+91 90000 22222'] },
      { name: 'Ravi (friend)', numbers: ['+91 90000 33333', '+91 90000 44444'] },
    ] });
    case 'SETTINGS_GET': return reply('SETTINGS_RESPONSE', { settings: pub() });
    case 'SETTINGS_UPDATE': {
      const inc = cmd.settings;
      if (inc.unpairPinHash == null) { inc.unpairPinHash = settings.unpairPinHash; inc.unpairPinSalt = settings.unpairPinSalt; }
      settings = inc; window.lastSettings = inc;
      return reply('SETTINGS_RESPONSE', { settings: pub(), applied: true });
    }
    case 'UNPAIR': window.unpaired = true; return reply('SETTINGS_RESPONSE', { unpaired: true });
  }
}
log('ready');
