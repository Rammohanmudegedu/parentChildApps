# Smart Parent

Two Android apps – **Smart Parent** (parent) and **Smart Parent Child** (child) – that let a parent see a child's screen time, apps, battery, device info and (optionally) location, and set screen-time rules, over an end-to-end encrypted WebRTC link. **No cloud database**: monitoring history lives on the child's phone; the parent phone keeps an encrypted cache.

The child app is transparent by design: a permanent "Sharing with parent" notification, a Privacy screen listing exactly what is shared, on-phone approval of pairing, and a child-controlled pause for location. It never reads messages, notification contents, keystrokes, the camera or microphone.

```
 Parent phone (Capacitor WebView)                       Child phone
 ┌───────────────────────────────┐                      ┌───────────────────────────────────────┐
 │ Bootstrap UI · Chart.js       │                      │ Bootstrap UI (status, privacy, pairing)│
 │ webrtc-service.js (JS WebRTC) │◄── DataChannel ─────►│ Kotlin foreground service              │
 │ IndexedDB (AES-GCM sealed)    │   DTLS + AES-GCM     │  ├ PeerLink (native org.webrtc)        │
 └──────────────┬────────────────┘   app-layer E2E      │  ├ SyncEngine (protocol, pairing)      │
                │ sealed signaling                      │  ├ UsageStats / Battery / Fused loc.   │
        ┌───────▼─────────┐  STUN / TURN (coturn)       │  ├ SQLite (+ Keystore-encrypted rows)  │
        │ Node WS relay   │◄─────────────────────────────┤  └ AccessibilityService (limits)       │
        │ stores nothing  │                             └───────────────────────────────────────┘
        └─────────────────┘
```

## Repository layout

| Path | What |
|---|---|
| `shared/` | Crypto (`sp-crypto.js`), protocol (`sp-protocol.js`), UI theme + helpers. Single source of truth, copied into both apps by `scripts/sync-shared.mjs`. Unit tests in `shared/test`. |
| `signaling-server/` | Stateless Node.js WebSocket relay + `/ice` TURN-credential endpoint. Docker, coturn and Caddy configs in `deploy/`. |
| `parent-app/` | Capacitor app: `www/` (UI, WebRTC, encrypted store), `android/` (generated project + plugins). |
| `child-app/` | Capacitor app: `www/` (UI) and `android/app/src/main/java/com/smartparent/child/` – the native Kotlin layer. |
| `tools/` | `kotlin-interop.sh` (Kotlin ⇄ JS crypto check), `e2e/` (headless end-to-end test of the parent app). |
| `docs/` | Install, APK build, testing, protocol and the feature matrix. |

### Child native layer (Kotlin)

| File | Role |
|---|---|
| `core/CryptoBox.kt` | ECDH P-256, HKDF, AES-GCM, sealed envelopes – byte-compatible with `sp-crypto.js` (verified). |
| `core/KeyVault.kt` | Android-Keystore-backed encryption for pairing keys, settings and location rows. |
| `core/ChildRuntime.kt` | Shared process state. |
| `data/MonitorDb.kt` | SQLite: daily usage, screen time, encrypted location history, alert queue, device info. |
| `collect/*` | `UsageStatsManager`, `BatteryManager`, `StatFs`, `ConnectivityManager`, Fused Location, launcher-app catalogue. |
| `net/SignalingClient.kt`, `PeerLink.kt`, `SyncEngine.kt`, `ProtocolRules.kt` | Relay client, native WebRTC answerer, pairing + request handling, command validation. |
| `policy/*` | Parent settings model and the block/allow decision. |
| `enforce/GuardAccessibilityService.kt`, `BlockActivity.kt` | App-limit / bedtime / study-time enforcement (package name only). |
| `service/MonitorService.kt`, `Notifier.kt` | Foreground service, minute tick, alerts, boot restart, notifications. |
| `plugin/SmartParentPlugin.kt` | Capacitor bridge for the child UI. |

## Build the APKs with GitHub Actions
Push this folder as a repo, then **Actions → Build APKs → Run workflow**. Details and the one-time signing-key setup: [docs/BUILD_APK.md](docs/BUILD_APK.md).

## Quick start (local)

```bash
# 1. Relay (local test)
cd signaling-server && npm install && npm start            # ws://<your-LAN-IP>:8080

# 2. Apps
cd ../parent-app && npm install && npm run sync && npm run open   # Android Studio → Run
cd ../child-app  && npm install && npm run sync && npm run open
```

On the child phone: Connection → enter the relay address → **Show pairing code**. On the parent phone: **Add child** → scan → compare the 6-digit code → tap **Allow** on the child phone. Then grant Usage access (and optionally Location, Limits) on the child phone.

Full steps: [docs/INSTALL.md](docs/INSTALL.md) · APKs: [docs/BUILD_APK.md](docs/BUILD_APK.md) · Tests: [docs/TESTING.md](docs/TESTING.md) · What needs what: [docs/FEATURE_MATRIX.md](docs/FEATURE_MATRIX.md) · Wire format: [docs/PROTOCOL.md](docs/PROTOCOL.md)

## Verification status

| Check | Status |
|---|---|
| Shared crypto/protocol unit tests (10) | ✅ pass (`npm test` in `shared/`) |
| Signaling relay tests (5) | ✅ pass (`npm test` in `signaling-server/`) |
| GitHub Actions workflow | ✅ passes `actionlint`; every step before Gradle was rehearsed on a clean clone |
| Kotlin `CryptoBox` ⇄ JS interop (15 checks, both directions) | ✅ pass (`tools/kotlin-interop.sh`) |
| Parent app end-to-end in Chromium against the real relay + a protocol-twin child (25 checks) | ✅ pass (`python3 tools/e2e/run_e2e.py`) |
| Android Gradle build of both APKs | ⚠️ **first compile happens in your CI run** – the authoring environment had no Android SDK / Maven access. See BUILD_APK.md › If the build fails. |
| On-device testing of the child native layer | ⚠️ **not run** – follow the device checklist in TESTING.md. |
