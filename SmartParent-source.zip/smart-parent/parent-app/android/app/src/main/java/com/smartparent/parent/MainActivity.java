package com.smartparent.parent;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
