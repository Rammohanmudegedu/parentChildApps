// Installed (launchable) apps on the child phone with today's usage and per-app limits.
import { esc, fmtDuration, fmtAgo, toast } from './common/sp-ui.js';
import * as devices from './device-service.js';
import { freshness, appIcon, tryLive, empty, loading } from './ui-common.js';
import { defaultSettings } from './common/sp-protocol.js';

let query = '';
let sort = 'usage';

export async function render(el) {
  if (!devices.active()) { el.innerHTML = empty('bi-phone', 'Add a child phone first.'); return; }
  const ch = devices.cache();
  if (!ch.apps) el.innerHTML = devices.isLive() ? loading() : empty('bi-wifi-off', 'The app list loads the first time the child phone is online.');
  else draw(el);
  if (devices.isLive() && Date.now() - ch.appsAt > 60_000) {
    const banner = document.createElement('div');
    const ok = await tryLive(() => devices.refreshApps(), banner);
    if (ok) draw(el); else el.prepend(banner);
  }
}

function draw(el) {
  const ch = devices.cache();
  const settings = ch.pendingSettings || ch.settings || defaultSettings();
  const limits = settings.appLimits || {};
  let apps = (ch.apps || []).slice();
  if (query) apps = apps.filter((a) => (a.label + ' ' + a.pkg).toLowerCase().includes(query));
  apps.sort(sort === 'name' ? (a, b) => a.label.localeCompare(b.label) : sort === 'recent' ? (a, b) => b.lastUsed - a.lastUsed : (a, b) => b.todayMs - a.todayMs);
  el.innerHTML = `
    <div class="d-flex gap-2 mb-2 align-items-center">
      <input id="appq" class="form-control" type="search" placeholder="Search apps" value="${esc(query)}">
      <select id="apps" class="form-select w-auto"><option value="usage">Most used</option><option value="recent">Recent</option><option value="name">A–Z</option></select>
    </div>
    <div class="d-flex justify-content-between align-items-center mb-2"><span class="sub">${ch.apps?.length || 0} apps</span>${freshness(ch.appsAt)}</div>
    <div class="sp-card">${apps.length ? `<ul class="sp-list">${apps.map((a) => {
      const lim = limits[a.pkg];
      return `<li>${appIcon(a)}<div class="grow"><div class="title">${esc(a.label)}</div>
        <div class="meta text-truncate">${esc(a.pkg)}</div>
        <div class="meta">${a.todayMs ? fmtDuration(a.todayMs) + ' today' : 'Not used today'}${a.launches ? ` · ${a.launches} opens` : ''}${a.lastUsed ? ` · ${fmtAgo(a.lastUsed)}` : ''}</div></div>
        <button class="btn btn-sm ${lim === undefined ? 'btn-light' : lim === 0 ? 'btn-outline-danger' : 'btn-outline-primary'}" data-limit="${esc(a.pkg)}">${lim === undefined ? 'Limit' : lim === 0 ? 'Paused' : fmtDuration(lim * 60000)}</button></li>`;
    }).join('')}</ul>` : empty('bi-search', 'No apps match.')}</div>
    <p class="sub small mt-2">“Paused” blocks the app all day; a time limit blocks it once today's use reaches the limit. Calls, Settings and the keyboard are never blocked. Requires the limits service on the child phone.</p>`;
  el.querySelector('#apps').value = sort;
  el.querySelector('#apps').addEventListener('change', (e) => { sort = e.target.value; draw(el); });
  const q = el.querySelector('#appq');
  q.addEventListener('input', () => { query = q.value.trim().toLowerCase(); const pos = q.selectionStart; draw(el); const nq = el.querySelector('#appq'); nq.focus(); nq.setSelectionRange(pos, pos); });
  el.querySelectorAll('[data-limit]').forEach((b) => b.addEventListener('click', () => editLimit(el, b.dataset.limit)));
}

async function editLimit(el, pkg) {
  const ch = devices.cache();
  const app = ch.apps.find((a) => a.pkg === pkg);
  const settings = structuredClone(ch.pendingSettings || ch.settings || defaultSettings());
  delete settings.unpairPinSet;
  const cur = settings.appLimits[pkg];
  const { confirmModal } = await import('./common/sp-ui.js');
  const m = await confirmModal({
    title: `Limit for ${app?.label || pkg}`,
    body: `<div class="vstack gap-2">
      <label class="form-check"><input class="form-check-input" type="radio" name="lm" value="none" ${cur === undefined ? 'checked' : ''}> <span class="form-check-label">No limit</span></label>
      <label class="form-check"><input class="form-check-input" type="radio" name="lm" value="time" ${cur > 0 ? 'checked' : ''}> <span class="form-check-label">Daily limit</span></label>
      <div class="input-group"><input id="lmmin" type="number" min="5" max="1440" step="5" class="form-control" value="${cur > 0 ? cur : 60}"><span class="input-group-text">minutes / day</span></div>
      <label class="form-check"><input class="form-check-input" type="radio" name="lm" value="pause" ${cur === 0 ? 'checked' : ''}> <span class="form-check-label">Pause this app</span></label></div>`,
    ok: 'Save',
  });
  if (!m) return;
  const mode = m.querySelector('input[name=lm]:checked').value;
  if (mode === 'none') delete settings.appLimits[pkg];
  else if (mode === 'pause') settings.appLimits[pkg] = 0;
  else settings.appLimits[pkg] = Math.max(5, Math.min(1440, parseInt(m.querySelector('#lmmin').value, 10) || 60));
  try {
    const r = await devices.saveSettings(settings);
    toast(r.queued ? 'Saved. It will apply when the child phone connects.' : 'Limit applied on the child phone');
  } catch (e) { toast(e.message); }
  draw(el);
}
