// Smart Parent – parent app shell: router, child switcher, connection pill, lifecycle.
import { $, $$, esc, applyTheme, toast } from './common/sp-ui.js';
import * as devices from './device-service.js';
import * as charts from './chart-service.js';
import * as lock from './app-lock.js';
import { STATE_TEXT } from './ui-common.js';
import * as dashboard from './dashboard.js';
import * as screenTime from './screen-time.js';
import * as applications from './applications.js';
import * as location from './location-service.js';
import * as deviceInfo from './device-info.js';
import * as controls from './parental-controls.js';
import * as reports from './reports.js';
import * as settings from './settings.js';
import * as addChild from './add-child.js';

applyTheme();

const ROUTES = {
  dashboard: ['Dashboard', dashboard],
  screentime: ['Screen time', screenTime],
  apps: ['Applications', applications],
  location: ['Location', location],
  device: ['Device information', deviceInfo],
  controls: ['Parental controls', controls],
  reports: ['Reports', reports],
  settings: ['Settings', settings],
  pair: ['Add child', addChild],
};
// Views that re-render when new data arrives (others are forms or have their own refresh).
const LIVE_VIEWS = { dashboard: ['all', 'status', 'alerts', 'settings'], screentime: ['all', 'screen'], device: ['all', 'status'], reports: ['all', 'alerts', 'screen'] };

let current = null;
let renderSeq = 0;

async function route() {
  const name = (window.location.hash || '#dashboard').slice(1);
  const key = ROUTES[name] ? name : 'dashboard';
  if (current === 'location' && key !== 'location') location.teardown();
  current = key;
  const [title, view] = ROUTES[key];
  $('#page-title').textContent = title;
  $$('.sp-bottomnav a, #drawer a[data-route]').forEach((a) => a.classList.toggle('active', a.dataset.route === key));
  window.bootstrap.Offcanvas.getInstance($('#drawer'))?.hide();
  charts.destroyAll();
  const el = $('#view');
  const seq = ++renderSeq;
  el.innerHTML = '';
  window.scrollTo(0, 0);
  try { await view.render(el); } catch (e) { if (seq === renderSeq) el.innerHTML = `<div class="sp-banner banner-bad"><i class="bi bi-x-circle"></i><div>${esc(e.message)}</div></div>`; }
}

function header() {
  const child = devices.active();
  $('#child-name').textContent = child ? child.nickname : 'No child';
  const [label] = STATE_TEXT[devices.linkState()] || STATE_TEXT.idle;
  $('#conn-pill').innerHTML = `<span class="dot"></span>${esc(child ? label : 'Not paired')}`;
  $('#conn-pill').className = `sp-pill pill-on-hero state-${devices.linkState()}`;
  $('#child-menu').innerHTML = devices.list().map((k) => `<li><button class="dropdown-item ${k.id === child?.id ? 'active' : ''}" data-child="${esc(k.id)}">${esc(k.nickname)}</button></li>`).join('')
    + '<li><hr class="dropdown-divider"></li><li><a class="dropdown-item" href="#pair"><i class="bi bi-plus-lg me-1"></i>Add child</a></li>';
  $$('#child-menu [data-child]').forEach((b) => b.addEventListener('click', () => devices.switchChild(b.dataset.child)));
}

let rerenderTimer = null;
function scheduleRerender(what) {
  const watch = LIVE_VIEWS[current];
  if (!watch || !watch.includes(what)) return;
  if (document.querySelector('.modal.show')) return;
  clearTimeout(rerenderTimer);
  rerenderTimer = setTimeout(() => { charts.destroyAll(); ROUTES[current][1].render($('#view')); }, 150);
}

async function boot() {
  await lock.requireUnlock();
  await devices.init();
  header();
  devices.on('state', (s) => { header(); if (s === 'connected' || s === 'child-offline') scheduleRerender('status'); });
  devices.on('child', () => { header(); route(); });
  devices.on('update', ({ what }) => scheduleRerender(what));
  window.addEventListener('hashchange', route);
  $('#refresh').addEventListener('click', async () => {
    if (!devices.active()) return;
    if (!devices.isLive()) { devices.reconnect(); toast('Trying to reach the child phone…'); return; }
    try { await devices.fullSync(); toast('Updated'); route(); } catch (e) { toast(e.message); }
  });
  lock.watchBackground(() => lock.requireUnlock());
  window.addEventListener('online', () => devices.reconnect());
  document.addEventListener('visibilitychange', () => { if (!document.hidden) devices.resume(); });
  const App = window.Capacitor?.Plugins?.App;
  App?.addListener('backButton', ({ canGoBack }) => {
    if ((window.location.hash || '#dashboard') !== '#dashboard') window.location.hash = '#dashboard';
    else if (!canGoBack) App.minimizeApp?.();
  });
  window.Capacitor?.Plugins?.LocalNotifications?.addListener('localNotificationActionPerformed', (a) => {
    window.location.hash = '#' + (a.notification?.extra?.route || 'dashboard');
  });
  route();
}

boot();
