// Contacts saved on the child's phone (names + numbers). Read-only; refreshed over the live link.
import { esc, fmtAgo, toast } from './common/sp-ui.js';
import * as devices from './device-service.js';
import { freshness, empty, loading, errorBanner } from './ui-common.js';

let query = '';

export async function render(el) {
  if (!devices.active()) { el.innerHTML = empty('bi-phone', 'Add a child phone first.'); return; }
  const ch = devices.cache();
  if (!ch.contacts) el.innerHTML = devices.isLive() ? loading() : empty('bi-wifi-off', 'Contacts load the first time the child phone is online.');
  else draw(el);
  if (devices.isLive() && Date.now() - ch.contactsAt > 60_000) {
    try { await devices.refreshContacts(); draw(el); }
    catch (e) {
      if (!ch.contacts) {
        el.innerHTML = e?.code === 'PERMISSION_CONTACTS'
          ? `<div class="sp-banner banner-warn"><i class="bi bi-person-lines-fill"></i><div>The child phone hasn't granted the Contacts permission yet. Ask them to open Smart Parent Child and tap <strong>Grant access</strong>.</div></div>`
          : errorBanner(e);
      } else { draw(el); toast(e?.code === 'PERMISSION_CONTACTS' ? 'Contacts permission is off on the child phone' : (e.message || 'Could not refresh')); }
    }
  }
}

function draw(el) {
  const ch = devices.cache();
  let list = (ch.contacts || []).slice();
  if (query) list = list.filter((c) => (c.name + ' ' + (c.numbers || []).join(' ')).toLowerCase().includes(query));
  el.innerHTML = `
    <div class="d-flex gap-2 mb-2 align-items-center">
      <input id="cq" class="form-control" type="search" placeholder="Search contacts" value="${esc(query)}">
    </div>
    <div class="d-flex justify-content-between align-items-center mb-2"><span class="sub">${(ch.contacts || []).length} contacts</span>${freshness(ch.contactsAt)}</div>
    <div class="sp-card">${list.length ? `<ul class="sp-list">${list.map((c) => `<li>
      <div class="sp-app-icon"><i class="bi bi-person"></i></div>
      <div class="grow"><div class="title">${esc(c.name || '(no name)')}</div>
      <div class="meta">${(c.numbers || []).map((n) => esc(n)).join(' · ') || 'No number'}</div></div></li>`).join('')}</ul>`
      : empty('bi-search', query ? 'No contacts match.' : 'No contacts on the phone.')}</div>`;
  const q = el.querySelector('#cq');
  q.addEventListener('input', () => { query = q.value.trim().toLowerCase(); const pos = q.selectionStart; draw(el); const nq = el.querySelector('#cq'); nq.focus(); nq.setSelectionRange(pos, pos); });
}
