// Parent settings: children (rename / switch / unpair), app lock PIN, theme, data, about.
import { esc, toast, setTheme, getTheme, fmtTime, confirmModal } from './common/sp-ui.js';
import * as devices from './device-service.js';
import * as lock from './app-lock.js';
import * as store from './store.js';

export function render(el) {
  const kids = devices.list();
  const act = devices.active();
  const theme = getTheme();
  el.innerHTML = `
    <div class="sp-section-title">Children</div>
    <div class="sp-card">${kids.length ? `<ul class="sp-list">${kids.map((k) => `<li><i class="bi bi-person-circle fs-4 text-primary"></i><div class="grow">
        <div class="title">${esc(k.nickname)} ${k.id === act?.id ? '<span class="badge text-bg-primary ms-1">Active</span>' : ''}</div>
        <div class="meta">${esc(k.deviceName)} · paired ${fmtTime(k.pairing.pairedAt)}</div></div>
        <div class="dropdown"><button class="btn-icon" data-bs-toggle="dropdown" aria-label="Options"><i class="bi bi-three-dots-vertical"></i></button>
          <ul class="dropdown-menu dropdown-menu-end">
            ${k.id !== act?.id ? `<li><button class="dropdown-item" data-act="switch" data-id="${esc(k.id)}">Show this child</button></li>` : ''}
            <li><button class="dropdown-item" data-act="rename" data-id="${esc(k.id)}">Rename</button></li>
            <li><button class="dropdown-item text-danger" data-act="remove" data-id="${esc(k.id)}">Unpair</button></li></ul></div></li>`).join('')}</ul>` : '<p class="sub mb-0">No child phones paired.</p>'}
      <a href="#pair" class="btn btn-light w-100 mt-2"><i class="bi bi-plus-lg me-1"></i>Add child</a></div>

    <div class="sp-section-title">Security</div>
    <div class="sp-card">
      <div class="d-flex align-items-center gap-3"><div class="flex-grow-1"><h2 class="mb-0">App lock</h2><div class="sub">${lock.enabled() ? 'PIN required on open and after 5 minutes in the background.' : 'Protect this app with a PIN.'}</div></div>
        <button id="lockbtn" class="btn btn-sm ${lock.enabled() ? 'btn-outline-danger' : 'btn-primary'}">${lock.enabled() ? 'Turn off' : 'Set PIN'}</button></div>
      <hr><div class="sub small"><i class="bi bi-lock me-1"></i>Pairing keys and cached child data are encrypted on this phone (AES-256-GCM, non-exportable key). Nothing is uploaded to any server.</div></div>

    <div class="sp-section-title">Appearance</div>
    <div class="sp-card"><div class="btn-group w-100" role="group">${['system', 'light', 'dark'].map((t) => `<input type="radio" class="btn-check" name="theme" id="th-${t}" value="${t}" ${t === theme ? 'checked' : ''}><label class="btn btn-outline-primary" for="th-${t}">${t[0].toUpperCase() + t.slice(1)}</label>`).join('')}</div></div>

    <div class="sp-section-title">Data</div>
    <div class="sp-card"><button id="wipe" class="btn btn-outline-danger w-100">Delete all data on this phone</button>
      <div class="sub small mt-2">Removes every pairing and all cached reports from this phone. Child phones stop being reachable until paired again.</div></div>

    <div class="sp-section-title">About</div>
    <div class="sp-card"><ul class="sp-list"><li><div class="grow">Version</div><strong>1.0.0</strong></li>
      <li><div class="grow">Relay</div><strong class="text-truncate" style="max-width:60%">${esc(act?.pairing.signalUrl || '—')}</strong></li></ul></div>`;

  el.querySelectorAll('input[name=theme]').forEach((r) => r.addEventListener('change', () => { setTheme(r.value); location.reload(); }));
  el.querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', async () => {
    const id = b.dataset.id; const kid = kids.find((k) => k.id === id);
    if (b.dataset.act === 'switch') { await devices.switchChild(id); location.hash = '#dashboard'; }
    if (b.dataset.act === 'rename') {
      const m = await confirmModal({ title: 'Rename', body: `<input id="nn" class="form-control" maxlength="30" value="${esc(kid.nickname)}">`, ok: 'Save' });
      const v = m && m.querySelector('#nn').value.trim();
      if (v) { await devices.renameChild(id, v); render(el); }
    }
    if (b.dataset.act === 'remove') {
      if (!await confirmModal({ title: `Unpair ${esc(kid.nickname)}?`, body: '<p class="mb-0">The child phone is told to stop sharing (if it is online) and all its data is deleted from this phone.</p>', ok: 'Unpair', danger: true })) return;
      await devices.removeChild(id); toast('Unpaired'); render(el);
    }
  }));
  el.querySelector('#lockbtn').addEventListener('click', async () => {
    if (lock.enabled()) { lock.disable(); toast('App lock off'); render(el); return; }
    const m = await confirmModal({ title: 'Set app PIN', body: '<input id="p1" type="password" inputmode="numeric" class="form-control mb-2" placeholder="4–8 digits" maxlength="8"><input id="p2" type="password" inputmode="numeric" class="form-control" placeholder="Repeat PIN" maxlength="8">', ok: 'Set PIN' });
    if (!m) return;
    const p1 = m.querySelector('#p1').value; const p2 = m.querySelector('#p2').value;
    if (!/^\d{4,8}$/.test(p1) || p1 !== p2) { toast('PINs must match and be 4–8 digits'); return; }
    await lock.setPin(p1); toast('App lock on'); render(el);
  });
  el.querySelector('#wipe').addEventListener('click', async () => {
    if (!await confirmModal({ title: 'Delete everything?', body: '<p class="mb-0">This cannot be undone.</p>', ok: 'Delete', danger: true })) return;
    for (const k of devices.list().slice()) await devices.removeChild(k.id);
    await store.wipeAll(); lock.disable(); location.hash = '#dashboard'; location.reload();
  });
}
