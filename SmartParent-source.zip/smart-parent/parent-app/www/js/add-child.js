// "Add child" flow: scan the QR on the child phone (or paste the link), compare codes, done.
import { esc, toast } from './common/sp-ui.js';
import { scanQr, pair } from './pairing.js';
import * as devices from './device-service.js';
import { safeGet, safeSet } from './common/sp-ui.js';

export function render(el) {
  el.innerHTML = `
    <div class="sp-card">
      <h2>Add a child phone</h2>
      <ol class="sub ps-3"><li>Install <strong>Smart Parent Child</strong> on the child's phone and open it.</li>
        <li>On that phone tap <strong>Connection › Show pairing code</strong>.</li><li>Scan the code here.</li></ol>
      <label class="form-label small" for="pname">Your name (shown on the child phone)</label>
      <input id="pname" class="form-control mb-2" maxlength="30" value="${esc(safeGet('sp.parentName') || 'Parent')}">
      <label class="form-label small" for="kname">Child's name</label>
      <input id="kname" class="form-control mb-3" maxlength="30" placeholder="e.g. Anu">
      <button id="scan" class="btn btn-primary w-100 btn-lg"><i class="bi bi-qr-code-scan me-1"></i>Scan pairing code</button>
      <details class="mt-3"><summary class="sub">Can't scan? Paste the pairing link</summary>
        <textarea id="link" class="form-control mt-2" rows="3" placeholder="smartparent://pair?d=…" spellcheck="false"></textarea>
        <button id="usel" class="btn btn-light w-100 mt-2">Use link</button></details>
    </div>
    <div id="pair-progress"></div>`;
  el.querySelector('#scan').addEventListener('click', async () => {
    try { const raw = await scanQr(); if (raw) run(el, raw); } catch (e) { toast(e.message); }
  });
  el.querySelector('#usel').addEventListener('click', () => run(el, el.querySelector('#link').value.trim()));
}

async function run(el, uri) {
  const parentName = el.querySelector('#pname').value.trim() || 'Parent';
  const nickname = el.querySelector('#kname').value.trim();
  safeSet('sp.parentName', parentName);
  const box = el.querySelector('#pair-progress');
  box.innerHTML = '<div class="sp-card text-center"><div class="spinner-border text-primary"></div><div class="sub mt-2">Contacting the child phone…</div></div>';
  try {
    const rec = await pair(uri, parentName, {
      onCode: (code) => {
        box.innerHTML = `<div class="sp-card text-center"><div class="sub">Check that the child phone shows this code</div>
          <div class="code-digits my-3">${esc(code)}</div>
          <div class="sub">Then tap <strong>Allow</strong> on the child phone. If the codes differ, tap Deny there.</div>
          <div class="spinner-border spinner-border-sm text-primary mt-3"></div></div>`;
      },
    });
    await devices.addChild(rec, nickname || rec.deviceName);
    toast(`Paired with ${nickname || rec.deviceName}`);
    location.hash = '#dashboard';
  } catch (e) {
    box.innerHTML = `<div class="sp-banner banner-bad mt-3"><i class="bi bi-x-circle"></i><div>${esc(e.message)}</div></div>`;
  }
}
