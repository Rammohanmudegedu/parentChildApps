// Parent notifications: Android system notifications via @capacitor/local-notifications,
// filtered by the parent's notification preferences. Shown only while the parent app process
// is alive (there is deliberately no cloud push service – see docs/FEATURE_MATRIX.md).
import { safeGet, safeSet, toast } from './common/sp-ui.js';

const LN = () => window.Capacitor?.Plugins?.LocalNotifications;
const PREF_KEY = 'sp.notifyPrefs';

export const ALERT_LABELS = {
  DAILY_LIMIT_REACHED: 'Daily limit reached',
  APP_LIMIT_REACHED: 'App limit reached',
  BEDTIME_STARTED: 'Bedtime started',
  STUDY_TIME_STARTED: 'Study time started',
  BATTERY_LOW: 'Battery low',
  LOCATION_SHARING_DISABLED: 'Location sharing paused',
  LOCATION_PERMISSION_REVOKED: 'Location permission removed',
  ENFORCEMENT_DISABLED: 'Limits turned off',
  USAGE_ACCESS_REVOKED: 'Usage access turned off',
  DEVICE_DISCONNECTED: 'Child phone disconnected',
  DEVICE_RECONNECTED: 'Child phone reconnected',
};

export function prefs() {
  const def = Object.fromEntries(Object.keys(ALERT_LABELS).map((k) => [k, k !== 'DEVICE_RECONNECTED']));
  try { return { ...def, ...JSON.parse(safeGet(PREF_KEY) || '{}') }; } catch { return def; }
}
export function setPrefs(p) { safeSet(PREF_KEY, JSON.stringify(p)); }

let nextId = 1;
export async function ensurePermission() {
  const ln = LN();
  if (!ln) return false;
  try {
    let p = await ln.checkPermissions();
    if (p.display !== 'granted') p = await ln.requestPermissions();
    return p.display === 'granted';
  } catch { return false; }
}

export async function notifyAlert(a, childName) {
  if (!prefs()[a.kind]) return;
  const title = `${childName ? childName + ': ' : ''}${a.title}`;
  const ln = LN();
  if (ln && document.hidden) {
    try {
      await ln.schedule({ notifications: [{ id: nextId++ % 100000, title, body: a.detail || '', extra: { route: 'dashboard' } }] });
      return;
    } catch { /* fall back to toast */ }
  }
  toast(`${title}${a.detail ? ' – ' + a.detail : ''}`, 5000);
}
