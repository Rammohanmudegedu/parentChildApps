// Usage reports: weekly vs previous week, monthly view, top apps, alert history, CSV export.
import { esc, fmtDuration, fmtTime, toast, confirmModal } from './common/sp-ui.js';
import * as devices from './device-service.js';
import * as charts from './chart-service.js';
import { empty, freshness } from './ui-common.js';
import { ALERT_LABELS } from './notify.js';
import { alertIcon } from './dashboard.js';

export function render(el) {
  if (!devices.active()) { el.innerHTML = empty('bi-phone', 'Add a child phone first.'); return; }
  const ch = devices.cache();
  const days = ch.screen?.days || ch.days || [];
  const last7 = days.slice(-7); const prev7 = days.slice(-14, -7);
  const sum = (a) => a.reduce((s, d) => s + d.totalMs, 0);
  const w = sum(last7); const pw = sum(prev7);
  const change = pw ? Math.round(((w - pw) / pw) * 100) : null;
  const limit = (ch.settings?.dailyLimitMinutes || 0) * 60000;
  const overDays = limit ? days.slice(-30).filter((d) => d.totalMs > limit).length : 0;
  const apps = ch.screen?.apps || [];
  const alerts = ch.alerts.slice().reverse();

  el.innerHTML = `
    <div class="d-flex justify-content-between align-items-center mb-2"><span class="sub">${days.length} days of history</span>${freshness(ch.screenAt || ch.lastSync)}</div>
    <div class="sp-card">
      <h2>This week</h2>
      <div class="d-flex align-items-baseline gap-2"><span class="display-6 fw-bold tabular">${fmtDuration(w)}</span>
      ${change != null ? `<span class="sp-pill ${change > 0 ? 'pill-bad' : 'pill-live'}"><i class="bi bi-arrow-${change > 0 ? 'up' : 'down'}"></i>${Math.abs(change)}% vs last week</span>` : ''}</div>
      <div class="sub">Average ${fmtDuration(last7.length ? w / last7.length : 0)} per day${limit ? ` · over the limit on ${overDays} of the last ${Math.min(30, days.length)} days` : ''}</div>
    </div>
    <div class="sp-section-title">Last 30 days</div>
    <div class="sp-card">${days.length ? '<div class="chart-box"><canvas id="monthChart"></canvas></div>' : empty('bi-bar-chart', 'History builds up as the child phone syncs.')}</div>
    <div class="sp-section-title">Top apps · 30 days</div>
    <div class="sp-card">${apps.length ? `<ul class="sp-list">${apps.slice(0, 10).map((a, i) => `<li><span class="rank">${i + 1}</span><div class="grow"><div class="title">${esc(a.label)}</div><div class="meta">${a.launches} opens</div></div><span class="tabular">${fmtDuration(a.ms)}</span></li>`).join('')}</ul>` : empty('bi-grid', 'Open Screen time while the child phone is online to load app totals.')}</div>
    <div class="sp-section-title d-flex justify-content-between"><span>Alert history</span>${alerts.length ? '<button class="btn btn-link btn-sm p-0" id="clr">Clear</button>' : ''}</div>
    <div class="sp-card">${alerts.length ? `<ul class="sp-list">${alerts.slice(0, 100).map((a) => `<li><i class="bi ${alertIcon(a.kind)}"></i><div class="grow"><div class="title">${esc(a.title)}</div><div class="meta">${esc(a.detail || ALERT_LABELS[a.kind] || '')}</div></div><span class="meta text-end">${fmtTime(a.ts)}</span></li>`).join('')}</ul>` : empty('bi-bell', 'No alerts.')}</div>
    <div class="d-grid mt-3"><button id="csv" class="btn btn-light" ${days.length ? '' : 'disabled'}><i class="bi bi-download me-1"></i>Export daily usage (CSV)</button></div>`;

  if (days.length) charts.durationBars(el.querySelector('#monthChart'), days.slice(-30).map((d) => d.date.slice(5)), days.slice(-30).map((d) => d.totalMs), { limitMinutes: ch.settings?.dailyLimitMinutes || 0 });
  el.querySelector('#clr')?.addEventListener('click', async () => {
    if (await confirmModal({ title: 'Clear alert history?', body: '<p class="mb-0">Removes alerts from this phone only.</p>', ok: 'Clear', danger: true })) { await devices.clearAlerts(); render(el); }
  });
  el.querySelector('#csv')?.addEventListener('click', () => exportCsv(days));
}

async function exportCsv(days) {
  const rows = [['date', 'screen_time_minutes', 'top_apps']].concat(days.map((d) => [d.date, Math.round(d.totalMs / 60000), (d.top || []).map((t) => `${t.label} (${Math.round(t.ms / 60000)}m)`).join('; ')]));
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
  const name = `smart-parent-${devices.active().nickname.replace(/\W+/g, '-')}-${new Date().toISOString().slice(0, 10)}.csv`;
  const file = new File([csv], name, { type: 'text/csv' });
  try {
    if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: name }); return; }
  } catch { /* user cancelled */ return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(file); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast('CSV exported');
}
