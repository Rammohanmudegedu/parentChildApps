// Optional PIN lock for the parent app with automatic session expiry after 5 minutes in background.
import { pinHash, b64u, randomBytes } from './common/sp-crypto.js';
import { safeGet, safeSet } from './common/sp-ui.js';

const KEY = 'sp.lock';
const IDLE_MS = 5 * 60_000;
let hiddenAt = 0;
let failures = 0;
let lockedUntil = 0;

export function enabled() { return !!safeGet(KEY); }
export async function setPin(pin) {
  const salt = b64u(randomBytes(16));
  safeSet(KEY, JSON.stringify({ salt, hash: await pinHash(pin, salt) }));
}
export function disable() { try { localStorage.removeItem(KEY); } catch { /* ignore */ } }

async function verify(pin) {
  const rec = JSON.parse(safeGet(KEY) || 'null');
  if (!rec) return true;
  return (await pinHash(pin, rec.salt)) === rec.hash;
}

/** Shows the lock screen if enabled; resolves when unlocked. */
export function requireUnlock() {
  if (!enabled()) return Promise.resolve();
  return new Promise((resolve) => {
    const el = document.createElement('div');
    el.className = 'sp-lock';
    el.innerHTML = `<div class="text-center"><i class="bi bi-shield-lock display-4"></i><h2 class="mt-3 mb-1">Smart Parent</h2><p class="opacity-75">Enter your PIN</p>
      <form><input type="password" inputmode="numeric" autocomplete="off" maxlength="8" class="form-control form-control-lg text-center mb-3" aria-label="PIN" autofocus>
      <button class="btn btn-light btn-lg w-100">Unlock</button><div class="small mt-2 err"></div></form></div>`;
    document.body.appendChild(el);
    const input = el.querySelector('input'); const err = el.querySelector('.err');
    setTimeout(() => input.focus(), 50);
    el.querySelector('form').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (Date.now() < lockedUntil) { err.textContent = `Too many attempts. Wait ${Math.ceil((lockedUntil - Date.now()) / 1000)} s.`; return; }
      if (await verify(input.value)) { failures = 0; el.remove(); resolve(); return; }
      failures++; input.value = '';
      if (failures >= 5) { lockedUntil = Date.now() + 30_000 * (failures - 4); }
      err.textContent = 'Incorrect PIN';
    });
  });
}

export function watchBackground(onLockNeeded) {
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) hiddenAt = Date.now();
    else if (hiddenAt && Date.now() - hiddenAt > IDLE_MS && enabled() && !document.querySelector('.sp-lock')) onLockNeeded();
  });
}
