// Parent side of QR pairing.
//   scan smartparent://pair?d=...  ->  join the one-time room  ->  PAIR_REQ{pk,name,mac}
//   both phones show the same 6-digit code (derived from the ECDH secret, so a relay in the
//   middle would produce different codes)  ->  child taps Allow  ->  PAIR_OK{box}
import { generateKeyPair, ecdhSharedSecret, derivePairingKeys, pairRequestMac, signalChannel, b64u } from './common/sp-crypto.js';
import { parsePairingUri } from './common/sp-protocol.js';

const cap = window.Capacitor;

/** Scans a QR with ML Kit (Google code scanner UI). Returns the raw text, or null if cancelled. */
export async function scanQr() {
  const BS = cap?.Plugins?.BarcodeScanner;
  if (!cap?.isNativePlatform?.() || !BS) throw new Error('Scanning needs the Android app. Paste the pairing link instead.');
  const { supported } = await BS.isSupported();
  if (!supported) throw new Error('This phone has no supported camera scanner. Paste the pairing link instead.');
  try {
    const { available } = await BS.isGoogleBarcodeScannerModuleAvailable();
    if (!available) {
      await BS.installGoogleBarcodeScannerModule();
      throw new Error('Downloading the scanner module from Google Play… try again in a moment.');
    }
  } catch (e) { if (e.message?.startsWith('Downloading')) throw e; }
  const { barcodes } = await BS.scan({ formats: ['QR_CODE'] });
  return barcodes?.[0]?.rawValue || null;
}

/**
 * Runs the pairing exchange. Callbacks:
 *   onCode(code)   – show the 6-digit code; the child must see the same one
 * Resolves with the pairing record to store; rejects on deny/timeout/error.
 */
export function pair(uri, parentName, { onCode } = {}) {
  const info = parsePairingUri(uri);
  return new Promise((resolve, reject) => {
    let done = false;
    let ws;
    const finish = (err, val) => {
      if (done) return; done = true;
      clearTimeout(timer);
      try { ws?.close(1000); } catch { /* ignore */ }
      err ? reject(err) : resolve(val);
    };
    const timer = setTimeout(() => finish(new Error('No answer from the child phone. Make sure the pairing code is still on its screen.')), 3 * 60_000);

    (async () => {
      const kp = await generateKeyPair();
      const shared = await ecdhSharedSecret(kp.privateJwk, info.k);
      const keys = await derivePairingKeys(shared, info.k, kp.publicKey);
      const mac = await pairRequestMac(info.t, info.r, kp.publicKey, info.k);
      ws = new WebSocket(info.s);
      ws.onerror = () => finish(new Error('Could not reach the relay at ' + info.s));
      ws.onopen = () => ws.send(JSON.stringify({ t: 'join', room: info.r, role: 'parent' }));
      ws.onmessage = async (ev) => {
        let m; try { m = JSON.parse(ev.data); } catch { return; }
        if (m.t === 'joined') {
          if (!m.peer) return finish(new Error('The child phone is not showing a pairing code right now.'));
          ws.send(JSON.stringify({ t: 'relay', d: JSON.stringify({ k: 'PAIR_REQ', pk: kp.publicKey, name: parentName, mac }) }));
          onCode?.(keys.sas);
        } else if (m.t === 'relay') {
          let r; try { r = JSON.parse(m.d); } catch { return; }
          if (r.k === 'PAIR_DENY') {
            const why = { declined: 'The child phone declined.', expired: 'The code expired. Show a new one on the child phone.', 'bad-code': 'Pairing check failed. Show a new code on the child phone.' }[r.why] || 'Pairing was refused.';
            finish(new Error(why));
          } else if (r.k === 'PAIR_OK') {
            try {
              // Proves the child derived the same secret (it sealed with the derived signal key).
              const box = JSON.parse(await signalChannel(keys.signalKey, info.r, 'parent').open(r.box));
              finish(null, {
                id: box.deviceId,
                deviceName: box.deviceName || info.n,
                pairing: {
                  parentPriv: kp.privateJwk, parentPub: kp.publicKey, childPub: info.k,
                  shared: b64u(shared), signalKey: keys.signalKey, roomId: keys.roomId,
                  signalUrl: info.s, pairedAt: Date.now(),
                },
              });
            } catch { finish(new Error('Could not verify the child phone. Try pairing again.')); }
          }
        } else if (m.t === 'peer-left') {
          finish(new Error('The child phone closed the pairing screen.'));
        }
      };
    })().catch((e) => finish(e));
  });
}
