// Screen time: today / daily / weekly / monthly, per-app breakdown, averages.
import { esc, fmtDuration, fmtAgo, dayLabel } from './common/sp-ui.js';
import * as devices from './device-service.js';
import * as charts from './chart-service.js';
import { freshness, stat, tryLive, empty, loading } from './ui-common.js';

let span = 7;

export async function render(el) {
  if (!devices.active()) { el.innerHTML = empty('bi-phone', 'Add a child phone first.'); return; }
  const ch = devices.cache();
  if (!ch.screen && !ch.days?.length) el.innerHTML = loading(); else draw(el);
  if (devices.isLive() && Date.now() - ch.screenAt > 60_000) {
    const ok = await tryLive(() => devices.refreshScreen(30), null);
    if (ok) draw(el); else if (!ch.screen) draw(el);
  } else if (!devices.isLive()) draw(el);
}

function draw(el) {
  const ch = devices.cache();
  const daysAll = ch.screen?.days || ch.days || [];
  const days = daysAll.slice(-span);
  const totals = days.map((d) => d.totalMs);
  const today = daysAll.at(-1)?.date === new Date().toLocaleDateString('en-CA') ? daysAll.at(-1).totalMs : (ch.status?.screenTimeTodayMs || 0);
  const nonZero = totals.filter((t) => t > 0);
  const avg = nonZero.length ? nonZero.reduce((a, b) => a + b, 0) / nonZero.length : 0;
  const weekTotal = daysAll.slice(-7).reduce((a, d) => a + d.totalMs, 0);
  const monthTotal = daysAll.slice(-30).reduce((a, d) => a + d.totalMs, 0);
  const limitMin = ch.settings?.dailyLimitMinutes || 0;
  const appsSpan = span === 1 ? (ch.screen?.today || ch.status?.topApps || []) : (ch.screen?.apps || []);
  const appsTotal = appsSpan.reduce((a, b) => a + b.ms, 0);

  el.innerHTML = `
    <div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap">
      <div class="btn-group" role="group" aria-label="Range">${[[1, 'Today'], [7, 'Week'], [30, 'Month']].map(([n, l]) => `<input type="radio" class="btn-check" name="span" id="sp${n}" value="${n}" ${n === span ? 'checked' : ''}><label class="btn btn-sm btn-outline-primary" for="sp${n}">${l}</label>`).join('')}</div>
      ${freshness(ch.screenAt || ch.statusAt)}
    </div>
    <div class="row g-2">
      ${stat('bi-calendar-day', fmtDuration(today), 'Today')}
      ${stat('bi-graph-up', fmtDuration(avg), `Daily average (${span === 1 ? 7 : span} d)`)}
      ${stat('bi-calendar-week', fmtDuration(weekTotal), 'Last 7 days')}
      ${stat('bi-calendar-month', fmtDuration(monthTotal), 'Last 30 days')}
    </div>
    ${span > 1 ? `<div class="sp-section-title">Daily screen time</div><div class="sp-card">${days.length ? '<div class="chart-box"><canvas id="daysChart"></canvas></div>' : empty('bi-bar-chart', 'No history yet.')}</div>` : ''}
    <div class="sp-section-title">${span === 1 ? 'Apps today' : 'Apps · last 30 days'}</div>
    <div class="sp-card">${appsSpan.length ? `<div class="chart-box mb-2" style="height:${Math.min(10, appsSpan.length) * 30 + 30}px"><canvas id="appsChart"></canvas></div>
      <ul class="sp-list">${appsSpan.slice(0, 30).map((a) => `<li><div class="grow"><div class="title">${esc(a.label)}</div>
        <div class="meta">${a.launches != null ? `${a.launches} opens · ` : ''}last used ${fmtAgo(a.lastUsed)}</div>
        <div class="sp-bar"><span style="width:${appsTotal ? Math.round((a.ms / appsTotal) * 100) : 0}%"></span></div></div><span class="tabular">${fmtDuration(a.ms)}</span></li>`).join('')}</ul>` : empty('bi-grid', 'No app usage recorded for this range.')}</div>
`;

  el.querySelectorAll('input[name=span]').forEach((r) => r.addEventListener('change', () => { span = +r.value; charts.destroyAll(); draw(el); }));
  if (span > 1 && days.length) charts.durationBars(el.querySelector('#daysChart'), days.map((d) => (span === 30 ? d.date.slice(5) : dayLabel(d.date))), totals, { limitMinutes: limitMin });
  if (appsSpan.length) charts.appBars(el.querySelector('#appsChart'), appsSpan.slice(0, 10));
}
