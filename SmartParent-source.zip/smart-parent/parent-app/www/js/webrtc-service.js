// Parent side of the encrypted WebRTC link to one child phone.
//
//  1. WebSocket to the relay, join the long-term room (derived from the pairing secret) as "parent"
//  2. Sealed signaling (relay sees ciphertext): HELLO{pn} -> HELLO_ACK{pn,cn} -> OFFER/ANSWER/ICE
//  3. DataChannel "sp" carries SealedChannel envelopes keyed per session (fresh nonces each time)
//
// States: idle | connecting | child-offline | negotiating | connected | relay-unreachable
import { signalChannel, sessionChannel, deriveSessionKeys, unb64u, b64u, randomBytes } from './common/sp-crypto.js';
import { chunkPlaintext, ChunkAssembler, makeMessage } from './common/sp-protocol.js';

const REQUEST_TIMEOUT_MS = 25_000;
const SESSION_MAX_MS = 55 * 60_000; // child enforces 60 min; reconnect slightly earlier

export function iceUrl(signalUrl, room) {
  return signalUrl.replace(/^wss:/, 'https:').replace(/^ws:/, 'http:').replace(/\/$/, '') + '/ice?room=' + encodeURIComponent(room);
}

export async function fetchIceServers(signalUrl, room) {
  try {
    const r = await fetch(iceUrl(signalUrl, room), { cache: 'no-store' });
    if (r.ok) return (await r.json()).iceServers;
  } catch { /* fall through */ }
  return [{ urls: ['stun:stun.l.google.com:19302'] }];
}

export class ChildLink extends EventTarget {
  constructor(pairing) {
    super();
    this.p = pairing;
    this.state = 'idle';
    this.pending = new Map();
    this.assembler = new ChunkAssembler();
    this.backoff = 2000;
    this.wanted = false;
    this.everConnected = false;
  }

  _set(state, extra = {}) {
    if (this.state === state) return;
    const prev = this.state;
    this.state = state;
    this.dispatchEvent(new CustomEvent('state', { detail: { state, prev, ...extra } }));
  }

  start() {
    this.wanted = true;
    if (this.ws) return;
    this._connectWs();
  }

  stop() {
    this.wanted = false;
    clearTimeout(this.retryTimer);
    this._teardownPeer('stop');
    try { this.ws?.close(1000); } catch { /* ignore */ }
    this.ws = null;
    this._set('idle');
  }

  _connectWs() {
    this._set('connecting');
    let ws;
    try { ws = new WebSocket(this.p.signalUrl); } catch { return this._scheduleRetry(); }
    this.ws = ws;
    ws.onopen = () => {
      this.backoff = 2000;
      ws.send(JSON.stringify({ t: 'join', room: this.p.roomId, role: 'parent' }));
    };
    ws.onmessage = (ev) => {
      let m; try { m = JSON.parse(ev.data); } catch { return; }
      if (m.t === 'joined') { if (m.peer) this._hello(); else this._set('child-offline'); }
      else if (m.t === 'peer-joined') this._hello();
      else if (m.t === 'peer-left') { this._teardownPeer('peer-left'); this._set('child-offline'); }
      else if (m.t === 'relay') this._onSignal(m.d);
    };
    ws.onclose = () => {
      if (this.ws !== ws) return;
      this.ws = null;
      this._teardownPeer('ws-closed');
      if (this.wanted) { this._set('relay-unreachable'); this._scheduleRetry(); }
    };
    ws.onerror = () => { /* onclose follows */ };
  }

  _scheduleRetry() {
    clearTimeout(this.retryTimer);
    if (!this.wanted) return;
    this.retryTimer = setTimeout(() => this._connectWs(), this.backoff);
    this.backoff = Math.min(this.backoff * 2, 60_000);
  }

  /** Reconnect now (e.g. app resumed or network back). */
  nudge() {
    if (!this.wanted) return;
    this.backoff = 2000;
    if (!this.ws) { clearTimeout(this.retryTimer); this._connectWs(); }
    else if (this.state === 'child-offline') this._hello();
  }

  async _sendSignal(obj) {
    if (!this.ws || this.ws.readyState !== 1 || !this.sig) return;
    this.ws.send(JSON.stringify({ t: 'relay', d: await this.sig.seal(JSON.stringify(obj)) }));
  }

  async _hello() {
    this._teardownPeer('new-hello');
    this.sig = signalChannel(this.p.signalKey, this.p.roomId, 'parent');
    this.pn = b64u(randomBytes(16));
    this._set('negotiating');
    await this._sendSignal({ k: 'HELLO', pn: this.pn });
    clearTimeout(this.helloTimer);
    this.helloTimer = setTimeout(() => { if (this.state === 'negotiating') { this._teardownPeer('timeout'); this._set('child-offline'); } }, 30_000);
  }

  async _onSignal(data) {
    if (!this.sig) return;
    let m;
    try { m = JSON.parse(await this.sig.open(data)); } catch { return; } // forged / replayed / stale: drop
    if (m.k === 'HELLO_ACK' && m.pn === this.pn && typeof m.cn === 'string') {
      const keys = await deriveSessionKeys(unb64u(this.p.shared), this.pn, m.cn);
      this.session = sessionChannel(keys, 'parent');
      this.sessionStarted = Date.now();
      await this._createPeer();
    } else if (m.k === 'ANSWER' && this.pc) {
      await this.pc.setRemoteDescription({ type: 'answer', sdp: m.sdp });
      for (const c of this.iceQueue || []) await this.pc.addIceCandidate(c).catch(() => {});
      this.iceQueue = null;
    } else if (m.k === 'ICE' && this.pc) {
      const c = { candidate: m.c.candidate, sdpMid: m.c.sdpMid, sdpMLineIndex: m.c.sdpMLineIndex };
      if (this.pc.remoteDescription) await this.pc.addIceCandidate(c).catch(() => {});
      else (this.iceQueue ||= []).push(c);
    }
  }

  async _createPeer() {
    const iceServers = await fetchIceServers(this.p.signalUrl, this.p.roomId);
    const pc = new RTCPeerConnection({ iceServers, bundlePolicy: 'max-bundle' });
    this.pc = pc;
    const dc = pc.createDataChannel('sp', { ordered: true });
    this.dc = dc;
    pc.onicecandidate = (e) => {
      if (e.candidate) this._sendSignal({ k: 'ICE', c: { candidate: e.candidate.candidate, sdpMid: e.candidate.sdpMid, sdpMLineIndex: e.candidate.sdpMLineIndex } });
    };
    pc.onconnectionstatechange = () => {
      if (['failed', 'closed'].includes(pc.connectionState) && this.pc === pc) {
        this._teardownPeer(pc.connectionState);
        this._set('child-offline');
        setTimeout(() => this.nudge(), 3000);
      }
    };
    dc.onopen = () => {
      clearTimeout(this.helloTimer);
      const reconnect = this.everConnected;
      this.everConnected = true;
      this.transport = 'p2p';
      pc.getStats().then((stats) => {
        stats.forEach((r) => { if (r.type === 'candidate-pair' && r.state === 'succeeded' && r.nominated) {
          const local = stats.get(r.localCandidateId);
          if (local?.candidateType === 'relay') this.transport = 'turn';
        } });
      }).catch(() => {});
      this._set('connected', { reconnect });
    };
    dc.onclose = () => {
      if (this.dc !== dc) return;
      this._teardownPeer('dc-closed');
      if (this.wanted && this.ws) this._set('child-offline');
    };
    dc.onmessage = (e) => this._onData(e.data);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await this._sendSignal({ k: 'OFFER', sdp: offer.sdp });
  }

  _teardownPeer(reason) {
    clearTimeout(this.helloTimer);
    const wasConnected = this.state === 'connected';
    try { this.dc?.close(); } catch { /* ignore */ }
    try { this.pc?.close(); } catch { /* ignore */ }
    this.dc = null; this.pc = null; this.session = null; this.iceQueue = null;
    for (const [, p] of this.pending) p.reject(new Error('DISCONNECTED'));
    this.pending.clear();
    if (wasConnected) this.dispatchEvent(new CustomEvent('disconnected', { detail: { reason } }));
  }

  async _onData(wire) {
    if (!this.session) return;
    let plain;
    try { plain = await this.session.open(wire); } catch { return; }
    let full;
    try { full = this.assembler.push(plain); } catch { return; }
    if (full == null) return;
    let msg; try { msg = JSON.parse(full); } catch { return; }
    if (msg.type === 'ALERT') { this.dispatchEvent(new CustomEvent('alert', { detail: msg.alert })); return; }
    const p = this.pending.get(msg.requestId);
    if (p) {
      this.pending.delete(msg.requestId);
      clearTimeout(p.timer);
      if (msg.type === 'ERROR') p.reject(Object.assign(new Error('Child rejected request: ' + msg.code), { code: msg.code }));
      else p.resolve(msg);
    }
  }

  get connected() { return this.state === 'connected' && this.dc?.readyState === 'open'; }

  /** Sends a command and resolves with the child's response message. */
  async request(type, body = {}) {
    if (!this.connected) throw Object.assign(new Error('Child phone is not connected'), { code: 'OFFLINE' });
    if (Date.now() - this.sessionStarted > SESSION_MAX_MS) { this._hello(); throw Object.assign(new Error('Session renewed, try again'), { code: 'RENEW' }); }
    const msg = makeMessage(type, body);
    const promise = new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(msg.requestId); reject(Object.assign(new Error('Child phone did not answer'), { code: 'TIMEOUT' })); }, REQUEST_TIMEOUT_MS);
      this.pending.set(msg.requestId, { resolve, reject, timer });
    });
    for (const part of chunkPlaintext(JSON.stringify(msg))) this.dc.send(await this.session.seal(part));
    return promise;
  }
}
