// View helpers specific to the parent app.
import { esc, fmtAgo } from './common/sp-ui.js';
import * as devices from './device-service.js';

/** "Live" when the data was fetched over the current live connection within the last 2 min, else "Cached · 5 min ago". */
export function freshness(at, label = '') {
  if (!at) return '<span class="sp-pill pill-off"><span class="dot"></span>No data yet</span>';
  const live = devices.isLive() && Date.now() - at < 120_000;
  return live
    ? `<span class="sp-pill pill-live"><span class="dot"></span>Live${label ? ' · ' + esc(label) : ''}</span>`
    : `<span class="sp-pill pill-cached"><span class="dot"></span>Cached · ${fmtAgo(at)}</span>`;
}

export const STATE_TEXT = {
  idle: ['Not connected', 'pill-off'],
  connecting: ['Connecting…', 'pill-cached'],
  negotiating: ['Connecting…', 'pill-cached'],
  connected: ['Online', 'pill-live'],
  'child-offline': ['Child offline', 'pill-bad'],
  'relay-unreachable': ['No relay', 'pill-bad'],
};

export const loading = () => '<div class="sp-empty"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading</span></div></div>';
export const empty = (icon, text) => `<div class="sp-empty"><i class="bi ${icon}"></i>${text}</div>`;
export const errorBanner = (e) => `<div class="sp-banner ${e?.code === 'OFFLINE' ? 'banner-warn' : 'banner-bad'} mb-3"><i class="bi ${e?.code === 'OFFLINE' ? 'bi-wifi-off' : 'bi-x-circle'}"></i><div>${esc(e?.code === 'OFFLINE' ? 'Child phone is offline – showing the last saved data.' : e?.message || 'Request failed')}</div></div>`;

export function stat(icon, val, lbl, tone = '') {
  return `<div class="col-6 col-md-3"><div class="sp-stat"><div class="ico ${tone}"><i class="bi ${icon}"></i></div><div class="val tabular">${val}</div><div class="lbl">${esc(lbl)}</div></div></div>`;
}

export function appIcon(a) {
  return a?.icon ? `<img class="sp-app-icon" src="${esc(a.icon)}" alt="" loading="lazy">` : '<div class="sp-app-icon"><i class="bi bi-app"></i></div>';
}

/** Runs a live request; on failure shows a banner but leaves cached content visible. */
export async function tryLive(fn, bannerEl) {
  try { await fn(); if (bannerEl) bannerEl.innerHTML = ''; return true; }
  catch (e) { if (bannerEl) bannerEl.innerHTML = errorBanner(e); return false; }
}
