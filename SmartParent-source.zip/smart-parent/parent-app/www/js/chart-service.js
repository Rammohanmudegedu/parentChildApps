// Chart.js helpers with theme-aware styling. Every chart created here is tracked so views can
// destroy them on navigation (prevents leaks and "canvas already in use" errors).
import { chartColors, fmtDuration } from './common/sp-ui.js';

const live = new Set();
export function destroyAll() { live.forEach((c) => c.destroy()); live.clear(); }

function base(c) {
  return {
    maintainAspectRatio: false,
    animation: { duration: 300 },
    plugins: { legend: { display: false }, tooltip: { padding: 10, cornerRadius: 10 } },
    scales: {
      x: { ticks: { color: c.muted, maxRotation: 0, autoSkip: true }, grid: { display: false }, border: { display: false } },
      y: { ticks: { color: c.muted }, grid: { color: c.border }, border: { display: false }, beginAtZero: true },
    },
  };
}

/** Bar chart of durations in ms, displayed as hours. Optional limit line in minutes. */
export function durationBars(canvas, labels, valuesMs, { limitMinutes = 0, highlightLast = true } = {}) {
  const c = chartColors();
  const hours = valuesMs.map((v) => +(v / 3_600_000).toFixed(2));
  const datasets = [{
    type: 'bar', data: hours, borderRadius: 6, maxBarThickness: 26,
    backgroundColor: hours.map((_, i) => (highlightLast && i === hours.length - 1 ? c.primary : c.primary + '99')),
  }];
  if (limitMinutes) datasets.push({ type: 'line', data: hours.map(() => limitMinutes / 60), borderColor: c.danger, borderDash: [5, 4], borderWidth: 1.5, pointRadius: 0, label: 'Limit' });
  const opts = base(c);
  opts.scales.y.ticks.callback = (v) => v + 'h';
  opts.plugins.tooltip.callbacks = { label: (x) => (x.dataset.label === 'Limit' ? 'Limit ' : '') + fmtDuration(x.raw * 3_600_000) };
  const chart = new window.Chart(canvas, { data: { labels, datasets }, options: opts });
  live.add(chart);
  return chart;
}

/** Doughnut of top apps (≤6 + "Other"). */
export function appDoughnut(canvas, apps, key = 'ms') {
  const c = chartColors();
  const top = apps.slice(0, 6);
  const other = apps.slice(6).reduce((s, a) => s + a[key], 0);
  const labels = top.map((a) => a.label).concat(other ? ['Other'] : []);
  const data = top.map((a) => a[key]).concat(other ? [other] : []);
  const chart = new window.Chart(canvas, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: c.series.concat(['#94a3b8']), borderWidth: 0, hoverOffset: 6 }] },
    options: {
      maintainAspectRatio: false, cutout: '68%',
      plugins: { legend: { position: 'right', labels: { color: c.text, boxWidth: 10, boxHeight: 10, usePointStyle: true, font: { size: 11 } } },
        tooltip: { callbacks: { label: (x) => `${x.label}: ${fmtDuration(x.raw)}` } } },
    },
  });
  live.add(chart);
  return chart;
}

/** Horizontal bars for per-app comparison. */
export function appBars(canvas, apps, key = 'ms') {
  const c = chartColors();
  const opts = base(c);
  opts.indexAxis = 'y';
  opts.scales.x.ticks.callback = (v) => fmtDuration(v * 60000);
  opts.scales.x.grid = { color: c.border };
  opts.scales.y.grid = { display: false };
  opts.plugins.tooltip.callbacks = { label: (x) => fmtDuration(x.raw * 60000) };
  const chart = new window.Chart(canvas, {
    type: 'bar',
    data: { labels: apps.map((a) => a.label), datasets: [{ data: apps.map((a) => Math.round(a[key] / 60000)), backgroundColor: c.series[1], borderRadius: 6, maxBarThickness: 18 }] },
    options: opts,
  });
  live.add(chart);
  return chart;
}
