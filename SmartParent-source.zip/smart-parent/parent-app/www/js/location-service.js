// Location view (Leaflet + OpenStreetMap tiles). Only shows what the child phone shared under
// its own visible location-sharing switch; explains why when it isn't available.
import { esc, fmtTime, fmtAgo } from './common/sp-ui.js';
import * as devices from './device-service.js';
import { freshness, tryLive, empty } from './ui-common.js';

let map = null;

const REASONS = {
  disabled_by_parent: 'Location sharing is turned off in Parental controls.',
  paused_by_child: 'Location sharing was paused on the child phone.',
  permission_missing: 'The child phone has not granted the location permission.',
  unavailable: 'Location is not available right now.',
};

export function teardown() { if (map) { map.remove(); map = null; } }

export async function render(el) {
  teardown();
  if (!devices.active()) { el.innerHTML = empty('bi-phone', 'Add a child phone first.'); return; }
  draw(el);
  if (devices.isLive()) {
    el.querySelector('#loc-status').innerHTML = '<span class="spinner-border spinner-border-sm text-primary"></span> Asking the child phone for a fresh location…';
    await tryLive(() => devices.refreshLocation(), el.querySelector('#loc-banner'));
    if (document.body.contains(el)) { teardown(); draw(el); }
  }
}

function draw(el) {
  const ch = devices.cache();
  const loc = ch.location;
  const sharing = ch.locationSharing;
  const hist = ch.locations.filter((l) => Date.now() - l.ts < 86_400_000);
  el.innerHTML = `
    <div id="loc-banner"></div>
    ${sharing && !sharing.sharing ? `<div class="sp-banner banner-warn mb-3"><i class="bi bi-geo"></i><div>${esc(REASONS[sharing.reason] || REASONS.unavailable)}${loc ? ' Showing the last known location.' : ''}</div></div>` : ''}
    <div class="sp-card p-0 overflow-hidden"><div id="map" class="sp-map" role="region" aria-label="Map"></div></div>
    <div class="sp-card mt-3">
      <div class="d-flex justify-content-between align-items-center"><h2 class="mb-0">${loc ? 'Last known location' : 'No location yet'}</h2>${freshness(ch.locationAt)}</div>
      <div id="loc-status" class="sub mt-1"></div>
      ${loc ? `<ul class="sp-list mt-1">
        <li><i class="bi bi-clock"></i><div class="grow">Updated</div><span>${fmtTime(loc.ts)} (${fmtAgo(loc.ts)})</span></li>
        <li><i class="bi bi-bullseye"></i><div class="grow">Accuracy</div><span>±${Math.round(loc.acc)} m</span></li>
        <li><i class="bi bi-battery-half"></i><div class="grow">Battery then</div><span>${loc.bat ?? '—'}%</span></li>
        <li><i class="bi bi-pin-map"></i><div class="grow">Coordinates</div><span class="tabular">${loc.lat.toFixed(5)}, ${loc.lon.toFixed(5)}</span></li></ul>
        <a class="btn btn-light w-100 mt-2" href="geo:${loc.lat},${loc.lon}?q=${loc.lat},${loc.lon}"><i class="bi bi-sign-turn-right me-1"></i>Open in Maps</a>` : '<p class="sub mb-0">Location appears here when the child phone shares it.</p>'}
    </div>
    ${hist.length > 1 ? `<div class="sp-section-title">Last 24 hours · ${hist.length} points</div>` : ''}`;
  if (!loc || !window.L) return;
  map = window.L.map(el.querySelector('#map'), { zoomControl: true, attributionControl: true }).setView([loc.lat, loc.lon], 15);
  window.L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap contributors' }).addTo(map);
  if (hist.length > 1) window.L.polyline(hist.map((l) => [l.lat, l.lon]), { color: '#1a56db', weight: 3, opacity: .5 }).addTo(map);
  window.L.circle([loc.lat, loc.lon], { radius: loc.acc || 30, color: '#1a56db', fillOpacity: .12, weight: 1 }).addTo(map);
  window.L.circleMarker([loc.lat, loc.lon], { radius: 8, color: '#fff', weight: 3, fillColor: '#1a56db', fillOpacity: 1 })
    .addTo(map).bindPopup(`${esc(devices.active().nickname)}<br>${fmtTime(loc.ts)}`);
  setTimeout(() => map?.invalidateSize(), 50);
}
