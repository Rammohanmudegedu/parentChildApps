// Child registry, live link management, encrypted cache and alert handling on the parent phone.
// Data flow: child phone (source of truth) -> encrypted DataChannel -> this cache (IndexedDB, sealed)
// Every cached item carries the time it was received so the UI can label it "live" or "cached".
import * as store from './store.js';
import { ChildLink } from './webrtc-service.js';
import { notifyAlert } from './notify.js';

const bus = new EventTarget();
export const on = (ev, fn) => { const h = (e) => fn(e.detail); bus.addEventListener(ev, h); return () => bus.removeEventListener(ev, h); };
const emit = (ev, detail) => bus.dispatchEvent(new CustomEvent(ev, { detail }));

let children = [];        // [{ id, nickname, deviceName, pairing }]
let activeId = null;
let link = null;
const caches = new Map(); // id -> cache object

const emptyCache = () => ({
  status: null, statusAt: 0, screen: null, screenAt: 0, apps: null, appsAt: 0,
  location: null, locationAt: 0, locations: [], settings: null, settingsAt: 0,
  alerts: [], lastAlertId: 0, lastLocTs: 0, days: [], lastSync: 0, pendingSettings: null,
});

export async function init() {
  children = await store.get('children', []);
  activeId = await store.get('activeChild', children[0]?.id ?? null);
  if (activeId && !children.find((c) => c.id === activeId)) activeId = children[0]?.id ?? null;
  for (const c of children) caches.set(c.id, { ...emptyCache(), ...(await store.get('cache:' + c.id, {})) });
  if (activeId) connectActive();
}

export const list = () => children;
export const active = () => children.find((c) => c.id === activeId) || null;
export const cache = () => caches.get(activeId) || emptyCache();
export const linkState = () => link?.state || 'idle';
export const transport = () => link?.transport || null;
export const isLive = () => !!link?.connected;

async function saveCache(id = activeId) {
  const c = caches.get(id);
  if (!c) return;
  // keep the cache bounded
  c.alerts = c.alerts.slice(-300);
  c.locations = c.locations.slice(-500);
  await store.put('cache:' + id, c);
}

export async function addChild(rec, nickname) {
  children = children.filter((c) => c.id !== rec.id);
  children.push({ ...rec, nickname: nickname || rec.deviceName });
  await store.put('children', children);
  caches.set(rec.id, emptyCache());
  await switchChild(rec.id);
}

export async function switchChild(id) {
  activeId = id;
  await store.put('activeChild', id);
  connectActive();
  emit('child', active());
  emit('update', { what: 'all' });
}

export async function renameChild(id, nickname) {
  const c = children.find((x) => x.id === id);
  if (!c) return;
  c.nickname = nickname;
  await store.put('children', children);
  emit('child', active());
}

/** Unpair: tells the child (if reachable) and deletes all local secrets and cached data. */
export async function removeChild(id) {
  if (id === activeId && link?.connected) {
    try { await link.request('UNPAIR'); } catch { /* child will notice it can no longer decrypt */ }
  }
  if (id === activeId) { link?.stop(); link = null; }
  children = children.filter((c) => c.id !== id);
  caches.delete(id);
  await store.put('children', children);
  await store.del('cache:' + id);
  activeId = children[0]?.id ?? null;
  await store.put('activeChild', activeId);
  if (activeId) connectActive();
  emit('child', active());
  emit('update', { what: 'all' });
}

function connectActive() {
  link?.stop();
  const c = active();
  if (!c) { link = null; return; }
  link = new ChildLink(c.pairing);
  const id = c.id;
  link.addEventListener('state', async (e) => {
    const { state, reconnect } = e.detail;
    emit('state', state);
    if (state === 'connected') {
      if (reconnect) await localAlert(id, 'DEVICE_RECONNECTED', 'Child phone reconnected', `${c.nickname} is online again.`);
      await fullSync().catch(() => {});
      const ch = caches.get(id);
      if (ch?.pendingSettings) {
        try { await saveSettings(ch.pendingSettings); } catch { /* stays pending */ }
      }
    }
  });
  link.addEventListener('disconnected', async (e) => {
    if (e.detail.reason === 'stop' || e.detail.reason === 'new-hello') return;
    await localAlert(id, 'DEVICE_DISCONNECTED', 'Child phone disconnected', `${c.nickname} went offline or closed the connection.`);
  });
  link.addEventListener('alert', async (e) => {
    const a = e.detail;
    const ch = caches.get(id);
    if (!ch || ch.alerts.some((x) => x.id === a.id && !x.local)) return;
    ch.alerts.push(a);
    ch.lastAlertId = Math.max(ch.lastAlertId, a.id || 0);
    await saveCache(id);
    notifyAlert(a, c.nickname);
    emit('update', { what: 'alerts' });
  });
  link.start();
}

async function localAlert(id, kind, title, detail) {
  const ch = caches.get(id);
  if (!ch) return;
  const a = { id: `local-${Date.now()}`, local: true, ts: Date.now(), kind, title, detail };
  ch.alerts.push(a);
  await saveCache(id);
  notifyAlert(a, active()?.nickname);
  emit('update', { what: 'alerts' });
}

export function reconnect() { link?.nudge(); }
export function pause() { link?.stop(); }
export function resume() { if (active() && (!link || link.state === 'idle')) connectActive(); else link?.nudge(); }

// ------------------------------------------------------------ requests
async function req(type, body) {
  if (!link) throw Object.assign(new Error('No child paired'), { code: 'NO_CHILD' });
  return link.request(type, body);
}

export async function fullSync() {
  const ch = cache();
  const r = await req('SYNC_REQUEST', { sinceAlertId: ch.lastAlertId, sinceLocationTs: ch.lastLocTs });
  const now = Date.now();
  ch.status = r.device; ch.statusAt = now;
  ch.days = r.days || ch.days;
  ch.settings = r.settings; ch.settingsAt = now;
  for (const a of r.alerts || []) {
    if (!ch.alerts.some((x) => x.id === a.id && !x.local)) { ch.alerts.push(a); notifyAlert(a, active()?.nickname); }
    ch.lastAlertId = Math.max(ch.lastAlertId, a.id);
  }
  ch.alerts.sort((a, b) => a.ts - b.ts);
  const locs = (r.locations || []).slice().sort((a, b) => a.ts - b.ts);
  if (locs.length) { ch.locations.push(...locs); ch.lastLocTs = locs.at(-1).ts; ch.location = locs.at(-1); ch.locationAt = now; }
  ch.lastSync = now;
  await saveCache();
  emit('update', { what: 'all' });
  return ch;
}

export async function refreshStatus() {
  const r = await req('DEVICE_STATUS_REQUEST');
  const ch = cache(); ch.status = r.device; ch.statusAt = Date.now(); ch.lastSync = ch.statusAt;
  await saveCache(); emit('update', { what: 'status' });
  return ch.status;
}

export async function refreshScreen(days = 30) {
  const r = await req('SCREEN_TIME_REQUEST', { days });
  const ch = cache(); ch.screen = { days: r.days, apps: r.apps, today: r.today, span: days }; ch.screenAt = Date.now();
  ch.days = r.days; ch.lastSync = ch.screenAt;
  await saveCache(); emit('update', { what: 'screen' });
  return ch.screen;
}

export async function refreshApps() {
  const r = await req('APP_LIST_REQUEST');
  const ch = cache(); ch.apps = r.apps; ch.appsAt = Date.now(); ch.lastSync = ch.appsAt;
  await saveCache(); emit('update', { what: 'apps' });
  return ch.apps;
}

export async function refreshLocation() {
  const r = await req('LOCATION_REQUEST');
  const ch = cache();
  ch.locationSharing = { sharing: r.sharing, reason: r.reason || null, at: Date.now() };
  if (r.last) { ch.location = r.last; ch.locationAt = Date.now(); }
  if (r.history?.length) {
    const known = new Set(ch.locations.map((l) => l.ts));
    ch.locations.push(...r.history.filter((l) => !known.has(l.ts)));
    ch.locations.sort((a, b) => a.ts - b.ts);
    ch.lastLocTs = Math.max(ch.lastLocTs, ch.locations.at(-1)?.ts || 0);
  }
  await saveCache(); emit('update', { what: 'location' });
  return ch;
}

/** Sends settings now, or queues them until the child phone connects. */
export async function saveSettings(settings) {
  const ch = cache();
  if (!link?.connected) {
    ch.pendingSettings = settings;
    await saveCache(); emit('update', { what: 'settings' });
    return { queued: true };
  }
  const r = await req('SETTINGS_UPDATE', { settings });
  ch.settings = r.settings; ch.settingsAt = Date.now(); ch.pendingSettings = null;
  await saveCache(); emit('update', { what: 'settings' });
  return { applied: true };
}

export async function clearAlerts() { const ch = cache(); ch.alerts = []; await saveCache(); emit('update', { what: 'alerts' }); }
