// Device information + battery monitoring for the active child phone.
import { esc, fmtBytes, fmtTime } from './common/sp-ui.js';
import * as devices from './device-service.js';
import { freshness, tryLive, empty } from './ui-common.js';

export async function render(el) {
  if (!devices.active()) { el.innerHTML = empty('bi-phone', 'Add a child phone first.'); return; }
  draw(el);
  if (devices.isLive() && Date.now() - devices.cache().statusAt > 20_000) {
    if (await tryLive(() => devices.refreshStatus(), el.querySelector('#di-banner'))) draw(el);
  }
}

function draw(el) {
  const ch = devices.cache();
  const s = ch.status;
  if (!s) { el.innerHTML = '<div id="di-banner"></div>' + empty('bi-cpu', 'Device details appear after the first connection.'); return; }
  const b = s.battery || {};
  const ramUsed = s.ram ? s.ram.totalBytes - s.ram.availBytes : 0;
  const row = (icon, k, v) => `<li><i class="bi ${icon}"></i><div class="grow">${k}</div><span class="text-end">${v}</span></li>`;
  el.innerHTML = `
    <div id="di-banner"></div>
    <div class="d-flex justify-content-between align-items-center mb-2"><span class="sub">Updated ${fmtTime(ch.statusAt)}</span>${freshness(ch.statusAt)}</div>
    <div class="sp-section-title">Battery</div>
    <div class="sp-card">
      <div class="d-flex align-items-center gap-3 mb-2">
        <div class="battery-gauge ${b.percent <= 15 ? 'low' : ''}"><span style="height:${b.percent}%"></span></div>
        <div><div class="display-6 fw-bold tabular">${b.percent}%</div><div class="sub">${b.charging ? `Charging (${esc(b.plugged)})` : 'On battery'}</div></div>
      </div>
      <ul class="sp-list">
        ${row('bi-heart-pulse', 'Health', esc(cap(b.health)))}
        ${row('bi-thermometer-half', 'Temperature', b.temperatureC != null ? `${b.temperatureC.toFixed(1)} °C` : 'Not reported')}
        ${row('bi-lightning', 'Voltage', b.voltageMv ? `${(b.voltageMv / 1000).toFixed(2)} V` : 'Not reported')}
      </ul></div>
    <div class="sp-section-title">Device</div>
    <div class="sp-card"><ul class="sp-list">
      ${row('bi-phone', 'Name', esc(s.deviceName))}
      ${row('bi-building', 'Manufacturer', esc(cap(s.manufacturer)))}
      ${row('bi-cpu', 'Model', esc(s.model))}
      ${row('bi-android2', 'Android version', `${esc(s.androidVersion)} (API ${s.sdk})`)}
    </ul></div>
    <div class="sp-section-title">Storage & memory</div>
    <div class="sp-card"><ul class="sp-list">
      ${row('bi-hdd', 'Storage available', `${fmtBytes(s.storage.freeBytes)} of ${fmtBytes(s.storage.totalBytes)}`)}
      ${row('bi-memory', 'RAM in use', s.ram ? `${fmtBytes(ramUsed)} of ${fmtBytes(s.ram.totalBytes)}${s.ram.lowMemory ? ' (low)' : ''}` : 'Not available')}
    </ul></div>
    <div class="sp-section-title">Network & permissions</div>
    <div class="sp-card"><ul class="sp-list">
      ${row('bi-wifi', 'Connection type', esc(cap(s.network?.type)))}
      ${row('bi-globe', 'Internet', s.network?.internet ? 'Yes' : 'No')}
      ${row('bi-cash-coin', 'Metered', s.network?.metered ? 'Yes' : 'No')}
      ${row('bi-hourglass-split', 'Usage access', s.usageAccess ? 'Granted' : '<span class="text-danger">Off</span>')}
      ${row('bi-pause-circle', 'Limits service', s.accessibilityEnabled ? 'On' : '<span class="text-danger">Off</span>')}
      ${row('bi-geo-alt', 'Location sharing', s.locationSharing ? 'On' : s.locationPausedByChild ? 'Paused by child' : 'Off')}
    </ul></div>`;
}

const cap = (x) => (x ? String(x).charAt(0).toUpperCase() + String(x).slice(1).replace(/_/g, ' ') : '—');
