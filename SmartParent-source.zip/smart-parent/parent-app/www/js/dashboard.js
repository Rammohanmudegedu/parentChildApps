// Parent dashboard: one-glance status of the active child phone.
import { esc, fmtDuration, fmtBytes, fmtAgo, fmtTime, dayLabel } from './common/sp-ui.js';
import * as devices from './device-service.js';
import * as charts from './chart-service.js';
import { freshness, stat, appIcon, STATE_TEXT, tryLive, empty } from './ui-common.js';
import { ALERT_LABELS } from './notify.js';

export async function render(el) {
  const child = devices.active();
  if (!child) {
    el.innerHTML = `<div class="sp-card text-center py-5"><i class="bi bi-phone fs-1 text-primary"></i>
      <h2 class="mt-3">Add your child's phone</h2><p class="sub">Install <strong>Smart Parent Child</strong> on their phone, open it, and tap <em>Show pairing code</em>.</p>
      <a href="#pair" class="btn btn-primary mt-2"><i class="bi bi-qr-code-scan me-1"></i> Add child</a></div>`;
    return;
  }
  draw(el);
  if (devices.isLive() && Date.now() - devices.cache().statusAt > 60_000) {
    tryLive(() => devices.refreshStatus(), el.querySelector('#dash-banner'));
  }
}

function draw(el) {
  const child = devices.active();
  const ch = devices.cache();
  const s = ch.status;
  const st = ch.settings || {};
  const [stateLabel, statePill] = STATE_TEXT[devices.linkState()] || STATE_TEXT.idle;
  const used = s?.screenTimeTodayMs || 0;
  const limit = (st.dailyLimitMinutes || 0) * 60000;
  const pct = limit ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const store = s?.storage;
  const storePct = store ? Math.round(((store.totalBytes - store.freeBytes) / store.totalBytes) * 100) : 0;
  const top = s?.topApps || [];
  const appsUsedMs = top.reduce((a, b) => a + b.ms, 0);
  const days = (ch.days || []).slice(-7);
  const alerts = ch.alerts.slice(-5).reverse();

  el.innerHTML = `
    <div id="dash-banner"></div>
    ${ch.pendingSettings ? '<div class="sp-banner banner-warn mb-3"><i class="bi bi-hourglass"></i><div>New rules are waiting to be delivered when the child phone connects.</div></div>' : ''}
    ${s && !s.usageAccess ? '<div class="sp-banner banner-bad mb-3"><i class="bi bi-exclamation-octagon"></i><div>Usage access is off on the child phone, so screen time is not being measured.</div></div>' : ''}
    ${s && st.enforcementEnabled && !s.enforcementActive ? '<div class="sp-banner banner-warn mb-3"><i class="bi bi-pause-circle"></i><div>Limits are not enforced: the accessibility service is off on the child phone.</div></div>' : ''}
    <section class="sp-hero">
      <div class="d-flex justify-content-between align-items-start gap-2">
        <div class="min-w-0"><div class="label">${esc(child.nickname)} · ${esc(s?.deviceName || child.deviceName || '')}</div>
          <div class="big tabular">${s ? fmtDuration(used) : '—'}</div><div class="label">Screen time today</div></div>
        <span class="sp-pill pill-on-hero"><span class="dot"></span>${stateLabel}</span>
      </div>
      ${limit ? `<div class="mt-3"><div class="d-flex justify-content-between small"><span>${pct}% of ${fmtDuration(limit)}</span><span>${fmtDuration(Math.max(0, limit - used))} left</span></div>
        <div class="sp-bar hero-bar"><span style="width:${pct}%"></span></div></div>` : ''}
      <div class="mt-3 small d-flex flex-wrap gap-2 align-items-center">${freshness(ch.statusAt)} <span class="opacity-75">Last sync ${fmtAgo(ch.lastSync)}</span></div>
    </section>

    <div class="row g-2 mt-1">
      ${stat(s?.battery?.charging ? 'bi-battery-charging' : 'bi-battery-half', s ? `${s.battery.percent}%` : '—', s?.battery?.charging ? 'Charging' : 'Battery', s && s.battery.percent <= (st.lowBatteryPercent || 15) ? 'tone-bad' : '')}
      ${stat(netIcon(s), s ? netText(s) : '—', 'Internet')}
      ${stat('bi-grid', s ? String(top.length) : '—', `Apps used · ${fmtDuration(appsUsedMs)}`)}
      ${stat('bi-geo-alt', s ? (s.locationSharing ? 'On' : 'Off') : '—', s?.locationPausedByChild ? 'Location (paused by child)' : 'Location sharing')}
    </div>

    <div class="row g-3 mt-0">
      <div class="col-lg-7">
        <div class="sp-section-title">This week</div>
        <div class="sp-card">${days.length ? '<div class="chart-box"><canvas id="weekChart"></canvas></div>' : empty('bi-bar-chart', 'Weekly data appears after the first sync.')}</div>
      </div>
      <div class="col-lg-5">
        <div class="sp-section-title">Most used today</div>
        <div class="sp-card">${top.length ? '<div class="chart-box sm"><canvas id="topChart"></canvas></div>' : empty('bi-pie-chart', 'No app usage yet today.')}</div>
      </div>
    </div>

    <div class="row g-3 mt-0">
      <div class="col-lg-6">
        <div class="sp-section-title">Device</div>
        <div class="sp-card"><ul class="sp-list">
          <li><i class="bi bi-hdd"></i><div class="grow"><div class="title">Storage</div>${store ? `<div class="sp-bar"><span style="width:${storePct}%"></span></div>` : ''}</div><span class="tabular">${store ? `${fmtBytes(store.totalBytes - store.freeBytes)} / ${fmtBytes(store.totalBytes)}` : '—'}</span></li>
          <li><i class="bi bi-android2"></i><div class="grow">Android</div><span>${esc(s?.androidVersion || '—')}</span></li>
          <li><i class="bi bi-shield-check"></i><div class="grow">Limits enforced</div><span>${s ? (s.enforcementActive ? 'Yes' : 'No') : '—'}</span></li>
          <li><i class="bi bi-arrow-left-right"></i><div class="grow">Connection</div><span class="sp-pill ${statePill}">${stateLabel}${devices.transport() === 'turn' ? ' · relay' : ''}</span></li>
        </ul></div>
      </div>
      <div class="col-lg-6">
        <div class="sp-section-title d-flex justify-content-between"><span>Recent alerts</span><a href="#reports" class="text-decoration-none small">All</a></div>
        <div class="sp-card">${alerts.length ? `<ul class="sp-list">${alerts.map((a) => `<li><i class="bi ${alertIcon(a.kind)}"></i><div class="grow"><div class="title">${esc(a.title)}</div><div class="meta">${esc(a.detail || ALERT_LABELS[a.kind] || '')} · ${fmtTime(a.ts)}</div></div></li>`).join('')}</ul>` : empty('bi-bell', 'No alerts yet.')}</div>
      </div>
    </div>`;

  if (days.length) charts.durationBars(el.querySelector('#weekChart'), days.map((d) => dayLabel(d.date)), days.map((d) => d.totalMs), { limitMinutes: st.dailyLimitMinutes || 0 });
  if (top.length) charts.appDoughnut(el.querySelector('#topChart'), top);
}

const netIcon = (s) => (!s ? 'bi-wifi' : s.network?.type === 'wifi' ? 'bi-wifi' : s.network?.type === 'cellular' ? 'bi-reception-4' : 'bi-wifi-off');
const netText = (s) => (s.network?.type === 'none' ? 'Offline' : `${s.network?.type === 'cellular' ? 'Mobile' : s.network?.type === 'wifi' ? 'Wi-Fi' : s.network?.type}${s.network?.internet ? '' : ' (no internet)'}`);

export function alertIcon(kind) {
  return {
    DAILY_LIMIT_REACHED: 'bi-hourglass-bottom', APP_LIMIT_REACHED: 'bi-app-indicator', BEDTIME_STARTED: 'bi-moon-stars',
    STUDY_TIME_STARTED: 'bi-book', BATTERY_LOW: 'bi-battery', LOCATION_SHARING_DISABLED: 'bi-geo', LOCATION_PERMISSION_REVOKED: 'bi-geo',
    ENFORCEMENT_DISABLED: 'bi-pause-circle', USAGE_ACCESS_REVOKED: 'bi-eye-slash', DEVICE_DISCONNECTED: 'bi-wifi-off', DEVICE_RECONNECTED: 'bi-wifi',
  }[kind] || 'bi-bell';
}
