// Parental controls: daily limit, bedtime, study time (+ allowed apps), location sharing request,
// alert thresholds, enforcement switch, child-side unpair PIN, and parent notification preferences.
import { esc, toast, fmtDuration } from './common/sp-ui.js';
import { defaultSettings, validateSettings } from './common/sp-protocol.js';
import { pinHash, b64u, randomBytes } from './common/sp-crypto.js';
import * as devices from './device-service.js';
import { prefs as notifyPrefs, setPrefs as setNotifyPrefs, ALERT_LABELS, ensurePermission } from './notify.js';
import { empty } from './ui-common.js';

const DAYS = [[1, 'M'], [2, 'T'], [3, 'W'], [4, 'T'], [5, 'F'], [6, 'S'], [7, 'S']];

export function render(el) {
  if (!devices.active()) { el.innerHTML = empty('bi-phone', 'Add a child phone first.'); return; }
  const ch = devices.cache();
  const s = structuredClone(ch.pendingSettings || ch.settings || defaultSettings());
  delete s.unpairPinSet;
  const pinSet = !!(ch.settings?.unpairPinSet || ch.pendingSettings?.unpairPinHash);
  const apps = ch.apps || [];
  const np = notifyPrefs();

  const schedule = (key, label, icon, sub) => `
    <div class="sp-card">
      <div class="d-flex align-items-center gap-3"><i class="bi ${icon} fs-4 text-primary"></i>
        <div class="flex-grow-1"><h2 class="mb-0">${label}</h2><div class="sub">${sub}</div></div>
        <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" role="switch" id="${key}-on" ${s[key].enabled ? 'checked' : ''}></div></div>
      <div class="row g-2 mt-2">
        <div class="col-6"><label class="form-label small" for="${key}-start">Starts</label><input type="time" class="form-control" id="${key}-start" value="${s[key].start}"></div>
        <div class="col-6"><label class="form-label small" for="${key}-end">Ends</label><input type="time" class="form-control" id="${key}-end" value="${s[key].end}"></div>
      </div>
      <div class="d-flex gap-1 mt-2 day-picker" data-key="${key}">${DAYS.map(([n, l]) => `<input type="checkbox" class="btn-check" id="${key}-d${n}" value="${n}" ${s[key].days.includes(n) ? 'checked' : ''}><label class="btn btn-sm btn-outline-primary flex-fill" for="${key}-d${n}" title="${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][n - 1]}">${l}</label>`).join('')}</div>
    </div>`;

  el.innerHTML = `
    ${ch.pendingSettings ? '<div class="sp-banner banner-warn mb-3"><i class="bi bi-hourglass"></i><div>These rules are saved here and will be sent when the child phone connects.</div></div>' : ''}
    ${!devices.isLive() ? '<div class="sp-banner banner-info mb-3"><i class="bi bi-info-circle"></i><div>The child phone is offline. Changes are queued and applied on its next connection.</div></div>' : ''}
    <form id="ctl" novalidate>
    <div class="sp-section-title">Screen time</div>
    <div class="sp-card">
      <div class="d-flex justify-content-between align-items-center"><h2 class="mb-0">Daily limit</h2><strong id="dl-val" class="tabular">${s.dailyLimitMinutes ? fmtDuration(s.dailyLimitMinutes * 60000) : 'Off'}</strong></div>
      <input type="range" class="form-range mt-2" id="dl" min="0" max="720" step="15" value="${s.dailyLimitMinutes}" aria-label="Daily limit in minutes">
      <div class="d-flex justify-content-between sub small"><span>Off</span><span>12h</span></div>
    </div>
    ${schedule('bedtime', 'Bedtime', 'bi-moon-stars', 'Apps pause overnight. Calls always work.')}
    ${schedule('studyTime', 'Study time', 'bi-book', 'Only the apps you allow below can be used.')}
    <div class="sp-card"><h2>Apps allowed during study time</h2>
      ${apps.length ? `<div class="allowed-list">${apps.map((a) => `<label class="form-check d-flex align-items-center gap-2 py-1"><input class="form-check-input mt-0" type="checkbox" name="study" value="${esc(a.pkg)}" ${s.studyAllowedPackages.includes(a.pkg) ? 'checked' : ''}><span class="text-truncate">${esc(a.label)}</span></label>`).join('')}</div>`
        : '<p class="sub mb-0">Open <a href="#apps">Applications</a> once while the child phone is online to load its apps.</p>'}
    </div>

    <div class="sp-section-title">Enforcement</div>
    <div class="sp-card"><div class="d-flex align-items-center gap-3"><div class="flex-grow-1"><h2 class="mb-0">Block apps when limits apply</h2>
      <div class="sub">Uses the limits service on the child phone. Off = track and alert only.</div></div>
      <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" role="switch" id="enf" ${s.enforcementEnabled ? 'checked' : ''}></div></div></div>

    <div class="sp-section-title">Location</div>
    <div class="sp-card"><div class="d-flex align-items-center gap-3"><div class="flex-grow-1"><h2 class="mb-0">Request location sharing</h2>
      <div class="sub">The child phone shows when location is shared and the child can pause it (you'll be alerted).</div></div>
      <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" role="switch" id="loc" ${s.locationSharingRequested ? 'checked' : ''}></div></div>
      <label class="form-label small mt-3" for="locint">Update every</label>
      <select id="locint" class="form-select">${[5, 10, 15, 30, 60, 120].map((m) => `<option value="${m}" ${m === s.locationIntervalMinutes ? 'selected' : ''}>${fmtDuration(m * 60000)}</option>`).join('')}</select></div>

    <div class="sp-section-title">Alerts</div>
    <div class="sp-card">
      <label class="form-label" for="lowbat">Low battery alert at</label>
      <div class="input-group"><input id="lowbat" type="number" class="form-control" min="5" max="50" value="${s.lowBatteryPercent}"><span class="input-group-text">%</span></div>
      <h2 class="mt-3">Notify me about</h2>
      ${Object.entries(ALERT_LABELS).map(([k, l]) => `<div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="np-${k}" data-np="${k}" ${np[k] ? 'checked' : ''}><label class="form-check-label" for="np-${k}">${l}</label></div>`).join('')}
      <p class="sub small mt-2 mb-0">Notifications arrive while this app is running (open or recently used). There is no cloud push service by design.</p>
    </div>

    <div class="sp-section-title">Unpair protection</div>
    <div class="sp-card"><h2>PIN to unpair on the child phone</h2>
      <div class="sub mb-2">${pinSet ? 'A PIN is set.' : 'No PIN set: the child can unpair (you will see the phone go offline).'} Leave blank to keep the current setting.</div>
      <input id="upin" type="password" inputmode="numeric" pattern="[0-9]*" minlength="4" maxlength="8" class="form-control" placeholder="New 4–8 digit PIN" autocomplete="new-password"></div>

    <div class="d-grid mt-3 mb-4 sticky-save"><button class="btn btn-primary btn-lg" type="submit"><i class="bi bi-send-check me-1"></i>${devices.isLive() ? 'Apply to child phone' : 'Save (send when online)'}</button></div>
    </form>`;

  const dl = el.querySelector('#dl');
  dl.addEventListener('input', () => { el.querySelector('#dl-val').textContent = +dl.value ? fmtDuration(dl.value * 60000) : 'Off'; });
  el.querySelectorAll('[data-np]').forEach((c) => c.addEventListener('change', async () => {
    const p = notifyPrefs(); p[c.dataset.np] = c.checked; setNotifyPrefs(p);
    if (c.checked) ensurePermission();
  }));

  el.querySelector('#ctl').addEventListener('submit', async (e) => {
    e.preventDefault();
    const readSched = (key) => ({
      enabled: el.querySelector(`#${key}-on`).checked,
      start: el.querySelector(`#${key}-start`).value || s[key].start,
      end: el.querySelector(`#${key}-end`).value || s[key].end,
      days: [...el.querySelectorAll(`.day-picker[data-key=${key}] input:checked`)].map((i) => +i.value),
    });
    const next = {
      ...s,
      dailyLimitMinutes: +dl.value,
      bedtime: readSched('bedtime'),
      studyTime: readSched('studyTime'),
      studyAllowedPackages: apps.length ? [...el.querySelectorAll('input[name=study]:checked')].map((i) => i.value) : s.studyAllowedPackages,
      enforcementEnabled: el.querySelector('#enf').checked,
      locationSharingRequested: el.querySelector('#loc').checked,
      locationIntervalMinutes: +el.querySelector('#locint').value,
      lowBatteryPercent: Math.max(5, Math.min(50, parseInt(el.querySelector('#lowbat').value, 10) || 15)),
    };
    // Never send a stale hash back; only include the PIN fields when a new PIN is typed.
    delete next.unpairPinHash; delete next.unpairPinSalt;
    const pin = el.querySelector('#upin').value.trim();
    if (pin) {
      if (!/^\d{4,8}$/.test(pin)) { toast('PIN must be 4–8 digits'); return; }
      next.unpairPinSalt = b64u(randomBytes(16));
      next.unpairPinHash = await pinHash(pin, next.unpairPinSalt);
    } else { next.unpairPinHash = null; next.unpairPinSalt = null; }
    const err = validateSettings(next);
    if (err) { toast('Please check: ' + err.toLowerCase().replace(/_/g, ' ')); return; }
    const btn = e.submitter; btn.disabled = true;
    try {
      const r = await devices.saveSettings(next);
      toast(r.queued ? 'Saved – will apply when the child phone connects' : 'Rules applied on the child phone');
      render(el);
    } catch (ex) { toast(ex.message); btn.disabled = false; }
  });
}
