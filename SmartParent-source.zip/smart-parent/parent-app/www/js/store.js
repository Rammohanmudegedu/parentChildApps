// Encrypted local storage for the parent phone (IndexedDB).
// Every record is AES-256-GCM sealed with a NON-EXTRACTABLE WebCrypto key that itself lives in
// IndexedDB. Pairing secrets and cached child data therefore never sit in plain text on disk,
// and nothing is uploaded anywhere.
import { newStorageKey, sealForStorage, openFromStorage } from './common/sp-crypto.js';

const DB = 'smartparent-parent';
const VER = 1;
let dbp = null;
let keyp = null;

function open() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const r = indexedDB.open(DB, VER);
    r.onupgradeneeded = () => {
      const db = r.result;
      db.createObjectStore('keys');
      db.createObjectStore('records');
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  return dbp;
}

function tx(store, mode, fn) {
  return open().then((db) => new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const s = t.objectStore(store);
    const req = fn(s);
    t.oncomplete = () => resolve(req?.result);
    t.onerror = () => reject(t.error);
  }));
}

async function key() {
  if (keyp) return keyp;
  keyp = (async () => {
    let k = await tx('keys', 'readonly', (s) => s.get('master'));
    if (!k) { k = await newStorageKey(); await tx('keys', 'readwrite', (s) => s.put(k, 'master')); }
    return k;
  })();
  return keyp;
}

export async function put(name, value) {
  const rec = await sealForStorage(await key(), value);
  await tx('records', 'readwrite', (s) => s.put(rec, name));
}

export async function get(name, fallback = null) {
  const rec = await tx('records', 'readonly', (s) => s.get(name));
  if (!rec) return fallback;
  try { return await openFromStorage(await key(), rec); } catch { return fallback; }
}

export async function del(name) { await tx('records', 'readwrite', (s) => s.delete(name)); }

export async function wipeAll() {
  await tx('records', 'readwrite', (s) => s.clear());
}
