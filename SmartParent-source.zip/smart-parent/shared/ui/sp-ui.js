// Small UI helpers shared by both apps.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function fmtDuration(ms) {
  const m = Math.round((ms || 0) / 60000);
  if (m < 1) return ms > 0 ? '<1m' : '0m';
  const h = Math.floor(m / 60);
  return h ? `${h}h ${m % 60}m` : `${m}m`;
}

export function fmtBytes(b) {
  if (!b && b !== 0) return '—';
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; let n = b;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(n >= 100 || i === 0 ? 0 : 1)} ${u[i]}`;
}

export function fmtAgo(ts) {
  if (!ts) return 'never';
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 45) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return new Date(ts).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export function fmtTime(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export function toast(msg, ms = 3200) {
  let wrap = $('.sp-toast-wrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.className = 'sp-toast-wrap'; document.body.appendChild(wrap); }
  const t = document.createElement('div');
  t.className = 'sp-toast'; t.textContent = msg; t.setAttribute('role', 'status');
  wrap.appendChild(t);
  setTimeout(() => t.remove(), ms);
}

const THEME_KEY = 'sp.theme';
export function applyTheme(pref) {
  const p = pref || safeGet(THEME_KEY) || 'system';
  const dark = p === 'dark' || (p === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-bs-theme', dark ? 'dark' : 'light');
  return p;
}
export function setTheme(p) { safeSet(THEME_KEY, p); applyTheme(p); }
export function getTheme() { return safeGet(THEME_KEY) || 'system'; }

export function safeGet(k) { try { return localStorage.getItem(k); } catch { return null; } }
export function safeSet(k, v) { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } }

export function chartColors() {
  const cs = getComputedStyle(document.documentElement);
  return {
    primary: cs.getPropertyValue('--sp-primary').trim(),
    accent: cs.getPropertyValue('--sp-accent').trim(),
    muted: cs.getPropertyValue('--sp-muted').trim(),
    border: cs.getPropertyValue('--sp-border').trim(),
    text: cs.getPropertyValue('--sp-text').trim(),
    danger: cs.getPropertyValue('--sp-danger').trim(),
    // categorical series (distinguishable in both themes)
    series: ['#1a56db', '#0ea5e9', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#64748b'],
  };
}

export function dayLabel(iso) {
  return new Date(iso + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'short', day: 'numeric' });
}

export function confirmModal({ title, body, ok = 'OK', cancel = 'Cancel', danger = false }) {
  return new Promise((resolve) => {
    const el = document.createElement('div');
    el.className = 'modal fade'; el.tabIndex = -1;
    el.innerHTML = `<div class="modal-dialog modal-dialog-centered"><div class="modal-content p-2">
      <div class="modal-header border-0"><h5 class="modal-title">${esc(title)}</h5></div>
      <div class="modal-body pt-0">${body}</div>
      <div class="modal-footer border-0">
        ${cancel ? `<button class="btn btn-light" data-r="0">${esc(cancel)}</button>` : ''}
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-r="1">${esc(ok)}</button>
      </div></div></div>`;
    document.body.appendChild(el);
    const m = new window.bootstrap.Modal(el, { backdrop: 'static' });
    let result = false;
    el.addEventListener('click', (e) => {
      const b = e.target.closest('[data-r]');
      if (b) { result = b.dataset.r === '1'; m.hide(); }
    });
    el.addEventListener('hidden.bs.modal', () => { el.remove(); resolve(result ? el : false); });
    m.show();
  });
}
