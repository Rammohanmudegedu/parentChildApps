// Smart Parent – shared cryptography (browser WebView + Node 20+).
// Source of truth. Copied into parent-app/www/js/common by scripts/sync-shared.mjs.
// The Kotlin twin lives in child-app/android/.../core/CryptoBox.kt and MUST stay byte-compatible.
//
// Primitives
//   ECDH P-256 (raw uncompressed 65-byte public keys), shared secret = 32-byte X coordinate
//   HKDF-SHA256, AES-256-GCM (12-byte IV, 128-bit tag appended), HMAC-SHA256
//   base64url without padding for every binary value on the wire

const subtle = globalThis.crypto.subtle;
const enc = new TextEncoder();
const dec = new TextDecoder();

export const PROTOCOL_VERSION = 1;
export const MAX_CLOCK_SKEW_MS = 120_000;

// ---------- encoding ----------
export function b64u(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let s = '';
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function unb64u(str) {
  if (typeof str !== 'string' || !/^[A-Za-z0-9_-]*$/.test(str)) throw new Error('BAD_B64');
  const s = str.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((str.length + 3) % 4);
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
export const utf8 = (s) => enc.encode(s);
export const fromUtf8 = (b) => dec.decode(b);
export function randomBytes(n) { return globalThis.crypto.getRandomValues(new Uint8Array(n)); }
export function concat(...parts) {
  const len = parts.reduce((a, p) => a + p.length, 0);
  const out = new Uint8Array(len); let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}
export function constantTimeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a[i] ^ b[i];
  return r === 0;
}

// ---------- ECDH ----------
export async function generateKeyPair() {
  const kp = await subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const pub = new Uint8Array(await subtle.exportKey('raw', kp.publicKey));
  const privJwk = await subtle.exportKey('jwk', kp.privateKey);
  return { publicKey: b64u(pub), privateJwk: privJwk };
}
export async function importPrivate(jwk) {
  return subtle.importKey('jwk', jwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
}
export async function ecdhSharedSecret(privateJwk, peerPublicB64u) {
  const raw = unb64u(peerPublicB64u);
  if (raw.length !== 65 || raw[0] !== 0x04) throw new Error('BAD_PUBLIC_KEY');
  const peer = await subtle.importKey('raw', raw, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const priv = await importPrivate(privateJwk);
  return new Uint8Array(await subtle.deriveBits({ name: 'ECDH', public: peer }, priv, 256));
}

// ---------- HKDF / HMAC ----------
export async function hkdf(ikm, salt, info, length) {
  const key = await subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
  const bits = await subtle.deriveBits(
    { name: 'HKDF', hash: 'SHA-256', salt: typeof salt === 'string' ? utf8(salt) : salt, info: utf8(info) },
    key, length * 8);
  return new Uint8Array(bits);
}
export async function hmacSha256(keyBytes, data) {
  const key = await subtle.importKey('raw', keyBytes, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return new Uint8Array(await subtle.sign('HMAC', key, typeof data === 'string' ? utf8(data) : data));
}
export async function sha256(data) {
  return new Uint8Array(await subtle.digest('SHA-256', typeof data === 'string' ? utf8(data) : data));
}

// ---------- AES-GCM ----------
export async function aesKey(raw) {
  return subtle.importKey('raw', raw, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}
export async function aesSeal(key, plaintextBytes, aadBytes, iv = randomBytes(12)) {
  const ct = await subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aadBytes, tagLength: 128 }, key, plaintextBytes);
  return { iv, ct: new Uint8Array(ct) };
}
export async function aesOpen(key, iv, ct, aadBytes) {
  try {
    return new Uint8Array(await subtle.decrypt({ name: 'AES-GCM', iv, additionalData: aadBytes, tagLength: 128 }, key, ct));
  } catch { throw new Error('DECRYPT_FAILED'); }
}

// ---------- Key schedule ----------
// Long-term pairing keys, derived once at pairing on both phones.
export function pairingSalt(childPub, parentPub) { return `SmartParent/v1|${childPub}|${parentPub}`; }

export async function derivePairingKeys(shared, childPub, parentPub) {
  const salt = pairingSalt(childPub, parentPub);
  const sig = await hkdf(shared, salt, 'signal', 32);
  const room = await hkdf(shared, salt, 'room', 16);
  const sasRaw = await hkdf(shared, salt, 'sas', 4);
  const sasNum = ((sasRaw[0] << 24) >>> 0) + (sasRaw[1] << 16) + (sasRaw[2] << 8) + sasRaw[3];
  return {
    signalKey: b64u(sig),
    roomId: b64u(room),
    sas: String(sasNum % 1_000_000).padStart(6, '0'),
  };
}

// Per-session directional keys (rotate every connection, bound to fresh nonces from both sides).
export async function deriveSessionKeys(shared, parentNonce, childNonce) {
  const salt = `SmartParent/session|${parentNonce}|${childNonce}`;
  const p2c = await hkdf(shared, salt, 'p2c', 32);
  const c2p = await hkdf(shared, salt, 'c2p', 32);
  const sid = await hkdf(shared, salt, 'sid', 12);
  return { p2c: b64u(p2c), c2p: b64u(c2p), sessionId: b64u(sid) };
}

export async function pairRequestMac(otpB64u, room, parentPub, childPub) {
  return b64u(await hmacSha256(unb64u(otpB64u), `pair-req|${room}|${parentPub}|${childPub}`));
}

// ---------- Sealed envelope with replay protection ----------
// Wire: {"v":1,"s":seq,"ts":epochMs,"iv":b64u,"c":b64u}
// AAD : "SP1|<label>|<context>|<seq>|<ts>"   label = p2c|c2p|sig-p|sig-c, context = sessionId or roomId
export class SealedChannel {
  constructor(sendKeyB64u, recvKeyB64u, sendLabel, recvLabel, context, opts = {}) {
    this._sendRaw = unb64u(sendKeyB64u); this._recvRaw = unb64u(recvKeyB64u);
    this.sendLabel = sendLabel; this.recvLabel = recvLabel; this.context = context;
    this.seq = 0; this.lastRecvSeq = -1;
    this.now = opts.now || (() => Date.now());
    this.maxSkew = opts.maxSkew ?? MAX_CLOCK_SKEW_MS;
  }
  async _keys() {
    if (!this._send) { this._send = await aesKey(this._sendRaw); this._recv = await aesKey(this._recvRaw); }
  }
  async seal(plaintext) {
    await this._keys();
    const s = this.seq++; const ts = this.now();
    const aad = utf8(`SP1|${this.sendLabel}|${this.context}|${s}|${ts}`);
    const { iv, ct } = await aesSeal(this._send, utf8(plaintext), aad);
    return JSON.stringify({ v: PROTOCOL_VERSION, s, ts, iv: b64u(iv), c: b64u(ct) });
  }
  async open(wire) {
    await this._keys();
    let env;
    try { env = typeof wire === 'string' ? JSON.parse(wire) : wire; } catch { throw new Error('BAD_ENVELOPE'); }
    if (!env || env.v !== PROTOCOL_VERSION || !Number.isInteger(env.s) || !Number.isInteger(env.ts)
      || typeof env.iv !== 'string' || typeof env.c !== 'string') throw new Error('BAD_ENVELOPE');
    if (Math.abs(this.now() - env.ts) > this.maxSkew) throw new Error('STALE_MESSAGE');
    if (env.s <= this.lastRecvSeq) throw new Error('REPLAY');
    const aad = utf8(`SP1|${this.recvLabel}|${this.context}|${env.s}|${env.ts}`);
    const pt = await aesOpen(this._recv, unb64u(env.iv), unb64u(env.c), aad);
    this.lastRecvSeq = env.s;
    return fromUtf8(pt);
  }
}

// Signaling channel uses one key in both directions, separated by label.
export function signalChannel(signalKey, roomId, role) {
  const me = role === 'parent' ? 'sig-p' : 'sig-c';
  const them = role === 'parent' ? 'sig-c' : 'sig-p';
  return new SealedChannel(signalKey, signalKey, me, them, roomId);
}
export function sessionChannel(keys, role) {
  return role === 'parent'
    ? new SealedChannel(keys.p2c, keys.c2p, 'p2c', 'c2p', keys.sessionId)
    : new SealedChannel(keys.c2p, keys.p2c, 'c2p', 'p2c', keys.sessionId);
}

// ---------- Local-at-rest encryption (parent IndexedDB) ----------
export async function newStorageKey() {
  return subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
export async function sealForStorage(key, obj) {
  const { iv, ct } = await aesSeal(key, utf8(JSON.stringify(obj)), utf8('SP-store'));
  return { iv: b64u(iv), c: b64u(ct) };
}
export async function openFromStorage(key, rec) {
  return JSON.parse(fromUtf8(await aesOpen(key, unb64u(rec.iv), unb64u(rec.c), utf8('SP-store'))));
}

// PIN hashing (parent app lock, child unpair PIN)
export async function pinHash(pin, saltB64u, iterations = 150_000) {
  const k = await subtle.importKey('raw', utf8(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: unb64u(saltB64u), iterations }, k, 256);
  return b64u(new Uint8Array(bits));
}
