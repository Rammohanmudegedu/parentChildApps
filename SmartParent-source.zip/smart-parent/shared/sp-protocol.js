// Smart Parent – application protocol (message catalogue, validation, chunking).
// Messages travel inside SealedChannel envelopes over the WebRTC DataChannel.
// Kotlin twin: child-app/android/.../net/ProtocolRules.kt (validation of inbound commands).

export const MsgType = Object.freeze({
  // parent -> child
  DEVICE_STATUS_REQUEST: 'DEVICE_STATUS_REQUEST',
  SCREEN_TIME_REQUEST: 'SCREEN_TIME_REQUEST',
  APP_LIST_REQUEST: 'APP_LIST_REQUEST',
  LOCATION_REQUEST: 'LOCATION_REQUEST',
  SYNC_REQUEST: 'SYNC_REQUEST',
  SETTINGS_GET: 'SETTINGS_GET',
  SETTINGS_UPDATE: 'SETTINGS_UPDATE',
  UNPAIR: 'UNPAIR',
  PING: 'PING',
  // child -> parent
  DEVICE_STATUS_RESPONSE: 'DEVICE_STATUS_RESPONSE',
  SCREEN_TIME_RESPONSE: 'SCREEN_TIME_RESPONSE',
  APP_LIST_RESPONSE: 'APP_LIST_RESPONSE',
  LOCATION_RESPONSE: 'LOCATION_RESPONSE',
  SYNC_RESPONSE: 'SYNC_RESPONSE',
  SETTINGS_RESPONSE: 'SETTINGS_RESPONSE',
  ALERT: 'ALERT',
  PONG: 'PONG',
  ERROR: 'ERROR',
  // framing
  CHUNK: 'CHUNK',
});

export const ParentCommands = new Set([
  'DEVICE_STATUS_REQUEST', 'SCREEN_TIME_REQUEST', 'APP_LIST_REQUEST', 'LOCATION_REQUEST',
  'SYNC_REQUEST', 'SETTINGS_GET', 'SETTINGS_UPDATE', 'UNPAIR', 'PING',
]);

export const AlertKind = Object.freeze({
  DAILY_LIMIT_REACHED: 'DAILY_LIMIT_REACHED',
  APP_LIMIT_REACHED: 'APP_LIMIT_REACHED',
  BEDTIME_STARTED: 'BEDTIME_STARTED',
  STUDY_TIME_STARTED: 'STUDY_TIME_STARTED',
  BATTERY_LOW: 'BATTERY_LOW',
  LOCATION_SHARING_DISABLED: 'LOCATION_SHARING_DISABLED',
  LOCATION_PERMISSION_REVOKED: 'LOCATION_PERMISSION_REVOKED',
  ENFORCEMENT_DISABLED: 'ENFORCEMENT_DISABLED',
  USAGE_ACCESS_REVOKED: 'USAGE_ACCESS_REVOKED',
  // generated on the parent itself
  DEVICE_DISCONNECTED: 'DEVICE_DISCONNECTED',
  DEVICE_RECONNECTED: 'DEVICE_RECONNECTED',
});

export function newRequestId() {
  const b = globalThis.crypto.getRandomValues(new Uint8Array(12));
  return Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
}

export function makeMessage(type, body = {}) {
  return { type, requestId: newRequestId(), timestamp: new Date().toISOString(), ...body };
}

const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;
const PKG = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+$/;
const isInt = (v, min, max) => Number.isInteger(v) && v >= min && v <= max;
const isSchedule = (s) => s && typeof s.enabled === 'boolean' && HHMM.test(s.start) && HHMM.test(s.end)
  && Array.isArray(s.days) && s.days.every((d) => isInt(d, 1, 7));

// Returns null when valid, otherwise an error code string.
export function validateSettings(st) {
  if (!st || typeof st !== 'object') return 'SETTINGS_OBJECT';
  if (!isInt(st.dailyLimitMinutes, 0, 1440)) return 'DAILY_LIMIT';
  if (!isSchedule(st.bedtime)) return 'BEDTIME';
  if (!isSchedule(st.studyTime)) return 'STUDY_TIME';
  if (!Array.isArray(st.studyAllowedPackages) || st.studyAllowedPackages.length > 200
    || !st.studyAllowedPackages.every((p) => typeof p === 'string' && PKG.test(p))) return 'STUDY_ALLOWED';
  if (typeof st.locationSharingRequested !== 'boolean') return 'LOCATION_SHARING';
  if (!isInt(st.locationIntervalMinutes, 5, 240)) return 'LOCATION_INTERVAL';
  if (!st.appLimits || typeof st.appLimits !== 'object') return 'APP_LIMITS';
  const keys = Object.keys(st.appLimits);
  if (keys.length > 300) return 'APP_LIMITS';
  for (const k of keys) if (!PKG.test(k) || !isInt(st.appLimits[k], 0, 1440)) return 'APP_LIMIT_ENTRY';
  if (!isInt(st.lowBatteryPercent, 5, 50)) return 'LOW_BATTERY';
  if (typeof st.enforcementEnabled !== 'boolean') return 'ENFORCEMENT';
  if (st.unpairPinHash != null && typeof st.unpairPinHash !== 'string') return 'UNPAIR_PIN';
  if (st.unpairPinSalt != null && typeof st.unpairPinSalt !== 'string') return 'UNPAIR_PIN';
  return null;
}

export function defaultSettings() {
  return {
    dailyLimitMinutes: 180,
    bedtime: { enabled: true, start: '21:30', end: '06:30', days: [1, 2, 3, 4, 5, 6, 7] },
    // days use ISO numbering: 1 = Monday … 7 = Sunday
    studyTime: { enabled: false, start: '17:00', end: '19:00', days: [1, 2, 3, 4, 5] },
    studyAllowedPackages: [],
    locationSharingRequested: true,
    locationIntervalMinutes: 15,
    appLimits: {},
    lowBatteryPercent: 15,
    enforcementEnabled: true,
    unpairPinHash: null,
    unpairPinSalt: null,
  };
}

// Validate an inbound parent command. Returns null when valid, otherwise error code.
export function validateCommand(msg) {
  if (!msg || typeof msg !== 'object') return 'NOT_OBJECT';
  if (!ParentCommands.has(msg.type)) return 'UNKNOWN_TYPE';
  if (typeof msg.requestId !== 'string' || !/^[a-f0-9]{8,64}$/.test(msg.requestId)) return 'REQUEST_ID';
  if (typeof msg.timestamp !== 'string' || Number.isNaN(Date.parse(msg.timestamp))) return 'TIMESTAMP';
  switch (msg.type) {
    case 'SCREEN_TIME_REQUEST':
      if (!isInt(msg.days, 1, 31)) return 'DAYS';
      break;
    case 'SYNC_REQUEST':
      if (!isInt(msg.sinceAlertId ?? 0, 0, Number.MAX_SAFE_INTEGER)) return 'SINCE_ALERT';
      if (!isInt(msg.sinceLocationTs ?? 0, 0, Number.MAX_SAFE_INTEGER)) return 'SINCE_LOCATION';
      break;
    case 'SETTINGS_UPDATE': {
      const e = validateSettings(msg.settings);
      if (e) return 'SETTINGS_' + e;
      break;
    }
    default: break;
  }
  return null;
}

// ---------- chunking ----------
// DataChannel messages above ~64 KiB are unreliable across implementations,
// so large plaintexts are split before sealing; each chunk is sealed separately.
export const CHUNK_SIZE = 48 * 1024;

export function chunkPlaintext(text, chunkSize = CHUNK_SIZE) {
  if (text.length <= chunkSize) return [text];
  const id = newRequestId();
  const n = Math.ceil(text.length / chunkSize);
  const out = [];
  for (let i = 0; i < n; i++) {
    out.push(JSON.stringify({ type: 'CHUNK', id, i, n, d: text.slice(i * chunkSize, (i + 1) * chunkSize) }));
  }
  return out;
}

export class ChunkAssembler {
  constructor(maxParts = 512, ttlMs = 60_000) { this.buf = new Map(); this.maxParts = maxParts; this.ttl = ttlMs; }
  // Returns the complete plaintext string when a message is complete, otherwise null.
  push(text) {
    let m; try { m = JSON.parse(text); } catch { return text; }
    if (!m || m.type !== 'CHUNK') return text;
    if (typeof m.id !== 'string' || !isInt(m.i, 0, this.maxParts) || !isInt(m.n, 1, this.maxParts)
      || m.i >= m.n || typeof m.d !== 'string') throw new Error('BAD_CHUNK');
    const now = Date.now();
    for (const [k, v] of this.buf) if (now - v.t > this.ttl) this.buf.delete(k);
    let e = this.buf.get(m.id);
    if (!e) { e = { n: m.n, parts: new Array(m.n), got: 0, t: now }; this.buf.set(m.id, e); }
    if (e.n !== m.n) throw new Error('BAD_CHUNK');
    if (e.parts[m.i] === undefined) { e.parts[m.i] = m.d; e.got++; }
    if (e.got === e.n) { this.buf.delete(m.id); return e.parts.join(''); }
    return null;
  }
}

// ---------- pairing QR payload ----------
// smartparent://pair?d=<base64url(JSON)>
export function parsePairingUri(uri) {
  const m = /^smartparent:\/\/pair\?d=([A-Za-z0-9_-]+)$/.exec(String(uri).trim());
  if (!m) throw new Error('NOT_A_PAIRING_CODE');
  const s = m[1].replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((m[1].length + 3) % 4);
  const p = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(s), (c) => c.charCodeAt(0))));
  if (p.v !== 1 || typeof p.s !== 'string' || !/^wss?:\/\//.test(p.s) || typeof p.r !== 'string'
    || typeof p.k !== 'string' || typeof p.t !== 'string' || !Number.isInteger(p.e) || typeof p.n !== 'string') {
    throw new Error('BAD_PAIRING_CODE');
  }
  if (Date.now() > p.e) throw new Error('PAIRING_CODE_EXPIRED');
  return p;
}
