// Generates cross-language test vectors consumed by the Kotlin CryptoBox interop test.
// Usage: node test/gen-vectors.mjs > test/vectors.json
import * as C from '../sp-crypto.js';

const child = await C.generateKeyPair();
const parent = await C.generateKeyPair();
const shared = await C.ecdhSharedSecret(child.privateJwk, parent.publicKey);
const pairing = await C.derivePairingKeys(shared, child.publicKey, parent.publicKey);
const session = await C.deriveSessionKeys(shared, 'parentNonceABC', 'childNonceXYZ');
const otp = C.b64u(C.randomBytes(16));
const mac = await C.pairRequestMac(otp, 'pairRoom1', parent.publicKey, child.publicKey);

// A parent->child envelope the Kotlin side must open
const p = C.sessionChannel(session, 'parent');
p.seq = 7;
const envelope = await p.seal('{"type":"PING","requestId":"abcdef0123456789"}');

// Deterministic AES-GCM vector (fixed IV) the Kotlin side must reproduce byte-for-byte
const iv = C.randomBytes(12);
const aad = 'SP1|c2p|' + session.sessionId + '|3|1700000000000';
const { ct } = await C.aesSeal(await C.aesKey(C.unb64u(session.c2p)), C.utf8('hello from child'), C.utf8(aad), iv);

console.log(JSON.stringify({
  childPrivD: child.privateJwk.d, childPub: child.publicKey,
  parentPrivD: parent.privateJwk.d, parentPub: parent.publicKey,
  shared: C.b64u(shared), pairing, session, otp, mac,
  envelope, envelopePlain: '{"type":"PING","requestId":"abcdef0123456789"}',
  fixed: { key: session.c2p, iv: C.b64u(iv), aad, plain: 'hello from child', ct: C.b64u(ct) },
}, null, 2));
