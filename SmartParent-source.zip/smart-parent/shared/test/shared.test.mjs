import test from 'node:test';
import assert from 'node:assert/strict';
import * as C from '../sp-crypto.js';
import * as P from '../sp-protocol.js';

async function pairPair() {
  const child = await C.generateKeyPair();
  const parent = await C.generateKeyPair();
  const s1 = await C.ecdhSharedSecret(child.privateJwk, parent.publicKey);
  const s2 = await C.ecdhSharedSecret(parent.privateJwk, child.publicKey);
  return { child, parent, s1, s2 };
}

test('ECDH agrees and pairing keys + SAS match on both sides', async () => {
  const { child, parent, s1, s2 } = await pairPair();
  assert.deepEqual(s1, s2);
  const a = await C.derivePairingKeys(s1, child.publicKey, parent.publicKey);
  const b = await C.derivePairingKeys(s2, child.publicKey, parent.publicKey);
  assert.deepEqual(a, b);
  assert.match(a.sas, /^\d{6}$/);
});

test('pair request MAC verifies only with the right OTP', async () => {
  const otp = C.b64u(C.randomBytes(16));
  const mac = await C.pairRequestMac(otp, 'room', 'P', 'C');
  assert.equal(mac, await C.pairRequestMac(otp, 'room', 'P', 'C'));
  assert.notEqual(mac, await C.pairRequestMac(C.b64u(C.randomBytes(16)), 'room', 'P', 'C'));
  assert.notEqual(mac, await C.pairRequestMac(otp, 'room', 'MITM', 'C'));
});

test('session channel: seal/open both directions', async () => {
  const { s1 } = await pairPair();
  const keys = await C.deriveSessionKeys(s1, 'pn', 'cn');
  const p = C.sessionChannel(keys, 'parent');
  const c = C.sessionChannel(keys, 'child');
  assert.equal(await c.open(await p.seal('hello child')), 'hello child');
  assert.equal(await p.open(await c.seal('hello parent')), 'hello parent');
});

test('replay, reflection, tamper and stale messages are rejected', async () => {
  const { s1 } = await pairPair();
  const keys = await C.deriveSessionKeys(s1, 'pn', 'cn');
  const p = C.sessionChannel(keys, 'parent');
  const c = C.sessionChannel(keys, 'child');
  const w1 = await p.seal('one');
  await c.open(w1);
  await assert.rejects(c.open(w1), /REPLAY/);
  // reflection: a parent message fed back to the parent
  await assert.rejects(p.open(await p.seal('x')), /DECRYPT_FAILED/);
  const env = JSON.parse(await p.seal('two'));
  env.ts += 1; // AAD mismatch
  await assert.rejects(c.open(JSON.stringify(env)), /DECRYPT_FAILED/);
  const old = new C.SealedChannel(keys.p2c, keys.c2p, 'p2c', 'c2p', keys.sessionId, { now: () => Date.now() - 600_000 });
  old.seq = 99;
  await assert.rejects(c.open(await old.seal('late')), /STALE_MESSAGE/);
});

test('messages from another session cannot be replayed', async () => {
  const { s1 } = await pairPair();
  const k1 = await C.deriveSessionKeys(s1, 'pn1', 'cn1');
  const k2 = await C.deriveSessionKeys(s1, 'pn2', 'cn2');
  const w = await C.sessionChannel(k1, 'parent').seal('old');
  await assert.rejects(C.sessionChannel(k2, 'child').open(w), /DECRYPT_FAILED/);
});

test('signal channel separates directions', async () => {
  const key = C.b64u(C.randomBytes(32));
  const p = C.signalChannel(key, 'room', 'parent');
  const c = C.signalChannel(key, 'room', 'child');
  assert.equal(await c.open(await p.seal('offer')), 'offer');
  await assert.rejects(p.open(await p.seal('offer')), /DECRYPT_FAILED/);
});

test('storage sealing round-trips', async () => {
  const k = await C.newStorageKey();
  const rec = await C.sealForStorage(k, { a: 1, b: [2] });
  assert.deepEqual(await C.openFromStorage(k, rec), { a: 1, b: [2] });
});

test('command validation', () => {
  assert.equal(P.validateCommand(P.makeMessage('PING')), null);
  assert.equal(P.validateCommand(P.makeMessage('DELETE_EVERYTHING')), 'UNKNOWN_TYPE');
  assert.equal(P.validateCommand(P.makeMessage('SCREEN_TIME_REQUEST', { days: 7 })), null);
  assert.equal(P.validateCommand(P.makeMessage('SCREEN_TIME_REQUEST', { days: 400 })), 'DAYS');
  const st = P.defaultSettings();
  assert.equal(P.validateCommand(P.makeMessage('SETTINGS_UPDATE', { settings: st })), null);
  assert.match(P.validateCommand(P.makeMessage('SETTINGS_UPDATE', { settings: { ...st, appLimits: { 'bad pkg': 5 } } })), /^SETTINGS_/);
  assert.match(P.validateCommand(P.makeMessage('SETTINGS_UPDATE', { settings: { ...st, bedtime: { ...st.bedtime, start: '25:00' } } })), /BEDTIME/);
});

test('chunking reassembles large payloads in any order', () => {
  const big = 'x'.repeat(130_000) + 'END';
  const parts = P.chunkPlaintext(big);
  assert.equal(parts.length, 3);
  const a = new P.ChunkAssembler();
  assert.equal(a.push(parts[2]), null);
  assert.equal(a.push(parts[0]), null);
  assert.equal(a.push(parts[1]), big);
  assert.equal(a.push('{"type":"PING"}'), '{"type":"PING"}');
});

test('pairing URI parsing', () => {
  const p = { v: 1, s: 'wss://sig.example.com', r: 'room', k: 'pub', t: 'otp', e: Date.now() + 60_000, n: 'Phone' };
  const uri = 'smartparent://pair?d=' + C.b64u(C.utf8(JSON.stringify(p)));
  assert.deepEqual(P.parsePairingUri(uri), p);
  const expired = 'smartparent://pair?d=' + C.b64u(C.utf8(JSON.stringify({ ...p, e: 1 })));
  assert.throws(() => P.parsePairingUri(expired), /EXPIRED/);
  assert.throws(() => P.parsePairingUri('https://evil'), /NOT_A_PAIRING/);
});
